# 2.4.4 视频纹理隔离与 ABXY 解绑

## 问题及处理

用户报告 Quest 解码视频时，随头部移动的下方按钮栏闪烁、出现紫色马赛克。此前视频的外部 OES 纹理直接参与双眼场景绘制，并与 HUD、玻璃模糊共用同一 GL 上下文和纹理单元切换路径。本版针对这条共享绘制路径进行隔离；尚未抓到故障 Quest 画面或驱动日志，因此不能将这一风险点表述成已实机确认的唯一根因。

- `SurfaceTexture.updateTexImage()` 和 OES 采样固定使用纹理单元 2。UI 图像使用单元 0，玻璃背景使用单元 1；外部采样结束显式解绑，并恢复单元 0。
- 每收到一帧新解码输出，在 GPU 上将外部纹理及其 SurfaceTexture 变换转换到独立 RGBA8 二维纹理。随后双眼均读取这份二维画面，HUD、玻璃模糊不读取解码器的外部存储。
- 没有新视频时复用上次转换结果，不按 XR 刷新率重复转换。接收、解码及控制发送仍各自独立；不增加 CPU 视频读回或转码。
- 转换尺寸按解码尺寸分配，仅受设备最大纹理尺寸限制。源切换/断线清空有效状态，首个新帧才重新显示；转换 framebuffer 不完整时明确报错，不拿无效画面继续合成。
- HUD 上传显式选择纹理单元及像素对齐，新增转换尺寸和分阶段 GL 错误日志。保留清晰视频窗口、关闭视频隐藏窗口及车上初始视点。

Android 的外部视频纹理语义见 [SurfaceTexture API](https://developer.android.com/reference/android/graphics/SurfaceTexture) 和 [AOSP SurfaceTexture](https://source.android.com/docs/core/graphics/arch-st)。独立 RGBA 转换额外占用一张视频尺寸纹理，并增加每个新视频帧的一次 GPU 绘制；Quest 上的 FPS 和观感需要实机验证。

## ABXY 只上报 AIPC

解除 A 确认、B 返回、X 视频切换、Y 菜单，以及 B+Y 长按退出；ABXY 不再触发本地界面反馈震动。16 种按键组合均不能独立触发本地动作。

key13 的有效位、按下位、失焦处理和 opbin1/CBOR 编码不变，持续上报 AIPC。服务端不需要因本次修改变更协议。

本地界面继续使用射线配合食指扳机选择。左菜单键打开菜单，或从当前页面返回；底部退出按钮继续有效。左右摇杆按下的既有视频/地图快捷操作保留。界面说明同步移除 A/B/X/Y 的本地快捷键提示。

## 验证与限制

- Java 契约 524 项断言通过，包含全部 ABXY 组合无本地动作、专用菜单键仍可用、face_buttons 编码保持等检查。
- 使用桌面 ANGLE 的真实 EGLImage/OES 外部纹理连续变换 24 帧，经转换后执行 48 次双眼像素检查及 48 次独立 UI 像素检查。
- 生产 HUD/玻璃/视频着色器离线检查通过，包括视频关闭透明范围和开启时不被 UI 覆盖。该测试不是 Android MediaCodec/Quest 驱动测试，也不代表实机闪烁已经验收。
- APK 与测试 APK 编译成功；版本 `2.4.4-development` / code `11`，包名 `com.tanluzhe.controlterminal.vr`，可覆盖更新 2.4.x。
- 本轮 ADB 只有手机，未连接 Quest；不安装到手机或模拟器，交付 APK 供 Quest 验证。

## ADB 日志

```powershell
adb -s QUEST_SERIAL logcat -d -v threadtime 'TLZ.XR:I' 'TLZ.VIDEO:I' 'TLZ.UI:I' '*:S'
```

重点查看 `VIDEO_RESOLVE_SIZE`、`GL_ERROR stage=before_video_resolve/video_resolve/eye_hud` 和 `VIDEO/LATCH`。GL 错误最多记录前 12 条，避免逐帧刷屏。完整收集仍可使用同目录 `vr_adb_debug.ps1 -Serial QUEST_SERIAL -Action collect`。

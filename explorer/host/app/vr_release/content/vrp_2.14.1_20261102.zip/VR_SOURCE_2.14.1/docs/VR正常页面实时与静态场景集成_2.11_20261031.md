# VR 2.11：正常页面内的实时／静态场景接入与扩展交接

日期：2026-10-31。依据 `D:\2026FPGArace\VR_SCENE_STREAMING_HANDOFF_20261031\README.md` 及同包服务端源码、测试向量实现。包名保持 com.tanluzhe.controlterminal.vr，版本2.11.0 / versionCode20；同时包含独立高质量录制与1080P自适应预览接口。

## 1. 产品入口与行为

- 启动页撤销“分块彩色点云浏览”“实验室有色场景／独立浏览”及旧有色模型URL输入。旧独立场景Intent不再打开独立页面。
- 连接AIPC进入正常VR，默认实时点云。菜单增加“场景 / 实时”，继续使用原有功能bar、状态、视频与手柄输入框架。
- 模式面板包含：实时模式、场景模式、刷新AIPC目录、目录分页、真实场景选择、缓存进度与占用、按场景地面Y微调、复位、删除此场景缓存、清全部缓存及确认框。
- 场景列表来自AIPC真实catalog，可保存目录供离线查看；没有把示例清单硬编码成在线目录。断网且没有目录时，场景模式仍可尝试上次选中的场景及本地缓存。
- 本地输入演示仍不自动联网；在该正常演示页面主动选择场景/实时，才启动对应只读点云连接。
- 模式切换只切点云客户端和渲染层，不重建控制PC、不改变ABXY/侧键/扳机编码，不改机械臂解算、车辆使能和CAN，不把视频/遥测改接点云端口。
- 进入静态场景不会把历史图当实时地图。静态图尚未与实时定位配准，所以不把实时车体/机械臂模型强行叠到历史图的任意位置；视频、控制状态和普通VR操作界面保留。“未配准”会明确显示。

## 2. 默认地址与权限

| 数据 | 默认地址 | 协议 |
|---|---|---|
| 实时融合状态 | http://192.168.137.2:8088/v2/cloud/live/state | 只读JSON |
| 实时融合点快照 | http://192.168.137.2:8088/v2/cloud/live/frame | VCL1 |
| 静态目录 | http://192.168.137.2:18184/api/v2/catalog | 显式场景v2 |
| 静态元信息/选区/块 | /api/v2/scenes/{scene_id}/manifest、select、blocks/{id}.gz | v2 |
| VR录像与预览 | http://VR_IP:8095/v1/view/... | 两路独立H.264及文件管理 |

鉴权均按团队约定使用 Authorization: Bearer 1，不需要手动输入令牌，不使用证书连接。静态和实时地址可在点云设置中分别修改，面板显示当前实际URL。旧内置本机离线URL/实验室Wi-Fi默认值会迁移至生产LAN；用户自定义的其他地址保留。

profile只控制预算，不切换网络路由。客户端不调用服务端全局模式切换，不调用写设置接口；后台profile默认值通过catalog/选区响应读取。2–5Hz选块与头显原生刷新分离。只保留 tlz.ctrl.v2 / tlz.probe.v2，旧 tlz.scene.v2 不创建，收到该旧DataChannel也直接关闭，不关闭控制PC。

## 3. 实时渲染

- 5Hz、单请求在途；请求带上次ETag，304保留上一有效快照，不当空图。
- 严格检查VCL1头、JSON/压缩/原始长度上限、gzip、原始SHA256、点数×16、XYZ有限性和矩阵。
- 每点float32 XYZ + RGBA8，保留源alpha。每帧整体替换，不叠加；epoch改变清旧缓冲，版本只递增接受，重复版本不重复上传。
- 503、源龄≥2秒、长时间没有新帧会提示实时不可用并隐藏陈旧实时点，不切静态图冒充实时。
- GPU绘制每个快照；最多保留一个待上传快照，不让网络积压阻塞XR。最大快照1,920,000字节，分配/上传与原生绘制分离。
- 明确使用 `p_display = A × map_to_vehicle × p_camera_init`，A执行一次 Z-up→Y-up；不再次加安装外参或车辆运动位姿。显示锚点独立于静态场景，原始头显/手柄上报坐标不因此改变。

## 4. 静态持久缓存

持久目录为应用 `files/scene-cloud/{scene_id}/{manifest_revision}/`，不再使用Android cacheDir。manifest_revision按服务端原样读取，不重新序列化计算；cache_namespace核对scene_id+revision。

- 粗图文件 `coarse-{raw_sha256}.bin` 固定保留到手动清除。
- 精细文件 `{raw_sha256}.bin`，独立256MiB磁盘LRU；半包按gzip内容hash隔离。完整后校验gzip SHA、原始SHA、长度与坐标范围，再原子写入已完成缓存。
- 首次可使用同包预置的真实117,299点粗图，经过哈希核对并写入持久缓存。它不是541,599点完整轻量场景。其他场景从其真实manifest获取，不套用同一资产。
- 返回同一场景先加载已校验缓存；断网保留粗图与已缓存区域。退出只释放GPU/解压内存，不删除磁盘。
- `cached`只声明当前manifest中匹配原始SHA、已可用的块；实现进一步只报告GPU驻留块，因此磁盘有数据但GPU尚未就绪时也不虚报显示完成。服务器重复计划不会导致重新下载，先从本机恢复。
- 当前近区缓存和GPU显示分别计数，显示磁盘总占用与GPU点缓冲占用。进度条代表粗图/当前近区，不代表39.7M点全图已全部缓存。
- 清此场景／清全部均需确认，显示目标范围，先停止在途下载再删除本应用拥有的缓存文件；不删除AIPC原始点、不删除录像、不删除其他应用文件。
- 409刷新manifest并隔离新版本；迟到下载不能写入新generation的GPU层。401等停止盲目请求，本地已拥有的合法缓存仍可查看。

## 5. GPU与坐标

静态原始步长15字节，后台整理为16字节GPU顶点，不把15字节源当成16字节读取。RGB按sRGB处理。原生VBO每帧上传最多2MiB、排队预算16MiB、点缓冲预算96MiB；这些不包含XR交换链、视频和录制缓冲。

按服务端profile的near/prefetch/retain半径和预算调度；默认3/4/5米。逐点做near球距离裁切；利用块cell的GPU就绪纹理按区域渐进替换粗点，未就绪区域保留粗图，不是一块到齐就移除整片粗图。显存紧张时优先淘汰远处预取块，必要时明确显示尚未完整精细。

固定1米=1米；不恢复旧沙盘自动缩放。source_to_scene已经应用，不重复变换。`p_scene=inverse(T_stage_from_scene)*p_head_stage`，选区中心是头显中点，不是屏幕像素、机器人位置或方向向量。地面Y按scene_id独立保存，默认0表示尚未校准，不代表真实地板；已知一米尺度、朝向和地面须现场确认。OpenXR参考空间变化会相应转换场景锚点。

当前GPU区域就绪索引有有界内存上限；超出网格索引范围时保留全近区就绪门控，不渲染缺块空洞。后续更大场景可替换为空间哈希/局部索引；不应取消内存上限或一次加载全图。

## 6. 预留扩展

源码 `SceneExtensions.java` 提供本地、场景限定的扩展契约，Activity通过 `sceneExtensions()`、`sceneExtensionContext()` 暴露入口；读取上下文需在Android主线程：

- `Context`：sceneId、manifestRevision、列主序T_stage_from_scene、navigationAligned=false。
- `ViewMode`：HEADSET、TOP_DOWN、ORBIT；预留视角请求回调。
- `Target`：场景坐标米制XYZ，附带完整Context；预留选点回调。
- `Handler`：onViewModeRequested / onTargetSelected；SceneModeController.extensionContext()提供当前有效上下文。

当前没有注册处理器，不显示可误触的导航按钮，未实现自动导航或真实俯视相机；未安装扩展时明确拒绝调用。未来可在同一模式控制器扩展相机和选点，点云客户端/缓存不必重写。选点只表示本地场景坐标，不是机器人目标；在增加已验证静态→实时配准、导航协议和使能策略前，不得直接发送车辆运动命令。

## 7. 诊断与验收证据

ADB快照增加scene_mode、scene_cache_status、scene_cloud_status、scene_cloud_error；原colored_scene_stats复用为点缓冲统计。SCENE/MODE_LIVE、MODE_STATIC、CATALOG、STATUS日志可读取，每5秒记录状态，令牌不输出。

```powershell
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command snapshot
adb -s QUEST_SERIAL exec-out run-as com.tanluzhe.controlterminal.vr cat files/v2-diagnostics.json
adb -s QUEST_SERIAL logcat -v threadtime TLZ.SCENE:I TLZ.CAPTURE:I TLZ.RECORD:I TLZ2:I *:S
```

验证结果：

- 交接包提供的真实AIPC服务端源码 + 真实1,219块场景，生产Java客户端视点[-4,0.8,1]：近区88/88；完成预取后首次下载77,266,081字节；重入下载0，约4.79秒；离线恢复0字节，约5.19秒，缓存约85.1MiB。这是主机确认Sink，不是Quest性能。
- 31项v2/VCL1校验：持久缓存、按场景删除、epoch/版本、304/503、RGBA和矩阵；实时样例明确是synthetic解码向量，不冒充生产实时数据。
- 真实桌面GLES执行生产shader：区域粗细替换、RGBA透明度、快照替换与epoch清理、色彩、预算和资源释放通过；附图为桌面渲染，不是Quest截图。
- 原控制/显示回归2,976项、原生跟随视角/IPD等2,200项、取景中心70,000项通过。录制/Range/下载删除与直播协议测试见另一份交接。
- 本机访问生产192.168.137.2的8088/18184均TCP超时。生产桥接链路、Quest实际帧时间、内存峰值、温度、2K60双编码并发、尺度与地面尚未验收。

## 8. 后续现场验收顺序

安装2.11覆盖旧版本，不清数据；进入正常VR确认默认实时；再刷新目录选场景，检查粗图、近区、缓存占用与GPU显示分开统计；往返模式确认视频和控制继续；退出重入确认粗图不重复下载；断网确认缓存可见并提示离线；测试按场景及全清确认；最后独立测试AIPC启动2K60录像、1080P预览和文件Range/删除。不得用这份主机报告声称Quest实机已通过。

现场测试安排：用户已说明本机通过远程桌面操作、不在对应环境，本轮明确不做实机或生产链路验收；后续由现场人员按需进行。

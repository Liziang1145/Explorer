> 2.7.0 新增 `CONTROLLER_MODEL` 日志与 `controller_geometry_revision`、`controller_left_model_source`、`controller_right_model_source` 快照字段。详见 [对接补充](VR头显手柄朝向与包围盒协议补充_20261028.md)。

# 探路者2.4：安装与ADB诊断

2026-10-22。包名com.tanluzhe.controlterminal.vr，Quest ARM64；默认192.168.137.2:8088、令牌1。原独立cloud_demo保留；不安装到模拟器/手机。

```powershell
adb -s QUEST_SERIAL install -r 探路者-控制终端-2.4.0.apk
.\vr_adb_debug.ps1 -Serial QUEST_SERIAL -Action status
.\vr_adb_debug.ps1 -Serial QUEST_SERIAL -Action collect
```

脚本显式要求Quest序列号并核对型号。可用动作install/status/snapshot/logs/probe/demo/stop/exit/video/logs_ui/collect；视频mode=0关闭/1标准/2宽幅。stop仅发送已有TLZ停止信号，不申请租约、不同步、不使能。媒体源可在VR视频设置选择RGB或伪彩深度。

```powershell
adb -s QUEST_SERIAL logcat -v threadtime TLZ.NET:I TLZ.RTC:I TLZ.VIDEO:I TLZ.INPUT:I TLZ.PROTO:I TLZ.XR:I TLZ.UI:I TLZ.ADB:I TLZ2:I *:S
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command snapshot
adb -s QUEST_SERIAL exec-out run-as com.tanluzhe.controlterminal.vr cat files/v2-diagnostics.json
```

DebugReceiver仅在debug版本启用，并受android.permission.DUMP保护。日志详情可刷新/筛选/复制；应用日志位于files/logs/ui.jsonl、vr.jsonl及轮转文件。包含时间、级别、模块、事件码、原因，密钥脱敏。ADB快照可能是历史文件，应核对run_id/时间/vr_running；视频连接成功不算已解码。

关键媒体事件：HEVC_OPEN、HEVC_DECODER、HEVC_FIRST_FRAME、HEVC_RETRY。快照包含video_transport、video_source、video_status、video_decoder、video_width/video_height、video_pts_us；视频PTS仅用于播放，不是采集到显示延时。face_buttons含revision/valid_mask/pressed_mask（A=1/B=2/X=4/Y=8）；INPUT/SAMPLE也打印face_valid/face_pressed。display_hz是提交帧率，observation_actual_hz是发送帧率，二者独立。

附handoff-test.apk只编译、本轮未执行。可选检查命令：

```powershell
adb -s QUEST_SERIAL install -r handoff-test.apk
adb -s QUEST_SERIAL shell am instrument -w -r com.tanluzhe.controlterminal.vr.test/com.tanluzhe.controlterminal.vr.v2.HandoffInstrumentation
```

它检查默认AIPC地址/端口/密钥、IP点号编辑、旧入口缺失、无申请按钮、调试权限、日志脱敏及HUD纹理，不代表HEVC、XR追踪或真实链路通过。

[本轮实现及验收边界](VR直连AIPC_2.4实现与验收_20261022.md)。本轮未运行Quest；AIPC只读访问超时，实际视频、ABXY与重连需实机联调。

# 探路者控制终端 2.4：AIPC直连与玻璃界面

日期：2026-10-22。主契约为用户提供的[VR_DIRECT_AIPC_HANDOFF_20261022.md](../../VR_DIRECT_AIPC_HANDOFF_20261022.md)。包名仍为 `com.tanluzhe.controlterminal.vr`，版本 `2.4.0-development` / code 7，可更新2.3，原独立cloud_demo保留。

## 本次实现

- 默认手动地址 `192.168.137.2:8088`，HTTP/WS，令牌 `1`。升级时旧自动网关、空地址和三个已知旧基站地址迁移到新目标；自定义主机保留，主机/端口继续可编辑。网关模式仍可手动选，但默认关闭，避免误连DHCP网关 `.1`。
- 删除租约申请、参考同步、本地授权及停止菜单按钮；菜单保留返回、视频、视角、日志、退出。客户端不发送 `lease.request`、`lease.renew`、`sync.request`、`stop.request` 等申请事件，不以租约或本地使能作为原始输入发送前提。执行许可与控制算法由AIPC负责。
- 保留TLZ头、DataChannel、时钟探测/映射、状态/控制回执、场景与地图接口。`base_node_id/ref_B`等是兼容字段，不表示物理基站。`/v2/events` URL带当前十进制session_id；媒体PC仅建立 `tlz.scene.v2`，不再添加RTP视频transceiver。
- 原始 `0x0104` 独立发送器保持当前配置（默认50Hz），不自动生成 `0x0101`。key11仍为模拟控件，新增key13报告真实ABXY；保持本地ABXY界面操作。暂停/退出/ADB停止仍可发送原TLZ STOP信号，它不是租约申请或使能流程。
- 注册能力仅声明 `cbor/opbin1`、`face_buttons_revision:1`、`HEVC/hevc-fmp4`；本轮不请求opq1。OPC1 revision、blob长度公式和姿态/模拟控件布局不改，key13在外层保留。
- 断线先使旧连接失效、清理session/时钟/输入，约1秒后创建全新客户端重新注册，PC、逐stream序号和映射重新建立；不重放旧输入。旧连接回调不能发布新会话的场景。设备UUID稳定，boot_uuid在同次应用运行/重连时保持，session重新获取。

## HEVC视频

使用固定版本AndroidX Media3 `1.8.0` 解析fragmented MP4并调用HEVC硬件解码器；不按TCP read分割access unit，不在VR转码H.264。官方实现说明：[Progressive媒体源](https://developer.android.com/media/media3/exoplayer/progressive)、[fMP4提取器源码](https://github.com/androidx/media/blob/1.8.0/libraries/extractor/src/main/java/androidx/media3/extractor/mp4/FragmentedMp4Extractor.java)。

1. 独立请求当前AIPC的 `GET /v2/media`，带Bearer，校验HEVC/hevc-fmp4。支持streams对象或列表中的URL/path，缺省使用契约规定的 `/v2/media/hevc/camera`、`/depth`；不跳转旧基站或8096。服务端给出的媒体URL必须与当前AIPC同源，所有GET均带Bearer，禁止HTTP重定向。
2. 视频页可以选择RGB相机或伪彩深度。**一次订阅并解码一个选中源**，默认RGB，降低头显并发解码负担。切换时释放旧播放器/缓存，重新GET新源。两个源均可切换查看，当前不是双流同时铺屏。
3. 媒体读取、fMP4解析和硬件解码独立于输入线程。每次订阅新建提取器和TimestampAdjuster，首帧归零但保留本订阅内PTS间隔，传递hvcC/VPS/SPS/PPS至MediaCodec，不拼接两次连接的时间线。
4. 缓存目标50–300ms，首次播放等待设为0；网络读超时6秒。错误、503、EOF或6秒没有解码输出，约1秒后以全新播放器重新GET、等待初始化段与同步帧；不在旧DataSpec位置恢复。不支持的硬件/profile清楚报错，不静默降为软件解码。缓存积压超过1.5秒也重新订阅最新GOP，这些阈值不是实际端到端延时承诺。
5. 视频纹理继续用于双眼中的同一视频面板，不虚构双目相机。按实际分辨率/像素宽高比等比适配，避免将4:3深度显示拉成16:9。伪彩深度不是毫米/米深度值。
6. 日志含 `HEVC_OPEN / HEVC_DECODER / HEVC_FIRST_FRAME / HEVC_RETRY`。只有首帧回调后显示硬件播放状态；连接成功不算解码成功。快照记录媒体源、状态、解码器名、分辨率与播放PTS。PTS不是传感器采集时间，不据此显示精确采集到显示延时；原RTT/时钟统计独立保留。

## ABXY key13

每次采样按各OpenXR布尔动作的isActive和焦点报告有效性，不以UI点击边沿代替按住状态，不因手柄姿态丢失伪造四个有效“松开”。位顺序为A=1、B=2、X=4、Y=8；与旧本地UI的A/X/B/Y顺序明确转换。

```text
13: {0:1, 1:valid_mask, 2:pressed_mask}
```

当前未采集触摸，省略3/4。失焦、输入超过100ms未更新时发 `{0:1,1:0,2:0}`，保持原始采样时间；不会用新时间戳伪装旧快照。pressed必须是valid子集；0x0104的64B头和1100B上限保持。压缩外层key13与原key12并列，绝不追加进blob。

完整样例（头显、双手、双眼/FOV、模拟输入、A+Y按下）为 **405B CBOR / 308B opbin1**，包含64B应用头，不含网络开销。相比旧397/300B样例多8B的key13。交付JSON、Java、独立Python编解码按位核对；Python参考实现增加了key13类型/revision/有效位/触摸配对校验。opq1样例仅保留旧codec回归用途，当前连接不宣告也不接受它。

## 世界与高斯玻璃

原空间分层保留：控制栏/FPS/RTT随视线，视频和状态板固定在车辆前方，支持旁观/跟随。没有反馈时使用显示原点，有新反馈才更新车辆位姿；无有效反馈保持末次显示值，不预测。

- 天空有蓝色渐变、方向光晕与轻微云层明暗；地面有近暗远亮的雾化、宽范围明暗和衰减网格，避免近白清屏。不是调用系统Home素材。
- 每眼先绘制天空、地图/点云、车体和视频，再将背景缩到1/4尺寸，做横/纵两遍9抽头Gaussian。世界面板采样当前眼的模糊背景，叠加透色、亮边和清晰文字；弹窗额外模糊其后的世界面板。射线/手柄最后绘制，保持清晰。
- 设置/日志的2D窗口也使用缓存的天空地面背景和两遍Gaussian模糊玻璃表面。其背景是本程序生成的静态场景，不是模糊其他系统应用；CPU缓存不参与XR逐帧渲染。

点云解析、格式、压缩、组包、地图块完整性和渲染数据通路未在本轮改造；仅随新的AIPC连接目标和会话生命周期使用既有入口。

## 本轮结果与验收边界

已通过494项纯Java断言、240项独立Python紧凑编码/ABXY检查、独立CBOR交叉解码、2200项原生视角矩阵检查。生产天空/玻璃/高斯着色器已离屏编译、链接、渲染，棋盘格检查确认高频对比度降低，四种布局已生成并检查。APK和设备检查包可构建。

本机对 `192.168.137.2:8088/v2/media` 和 `/v2/health` 的只读访问超时。**没有声称已在真实AIPC或Quest验证HEVC硬解、ABXY、重连和FPS。** 离线GLSL预览使用桌面字体、虚拟数值，不是Quest截图。设备检查包本轮仅编译，未运行；新媒体源切换、服务器实际JSON与相机profile、真实无线延时、设置页玻璃效果和佩戴舒适度需要实机验收。

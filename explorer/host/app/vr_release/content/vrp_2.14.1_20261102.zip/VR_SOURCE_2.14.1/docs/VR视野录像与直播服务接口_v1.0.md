> 2026-10-31 更新：VR 2.9.1 移除本地录像，默认开启直播并固定光轴居中。当前行为见 [2.9.1 接口变更](VR默认直播与光轴居中_2.9.1_20261031.md)，下文保留为历史协议。

> 2026-10-28：2.7.1 起以 [直播数据传输与后台启动协议 v1.1](VR视野直播数据传输与后台启动协议_v1.1.md) 为准。后台直接启动，无 VR 确认；VR 仅提示和菜单取消。本文保留为 v1.0 历史说明。

# VR 视野录像与直播服务接口 v1.0

适用：探路者-控制终端 2.6.0（versionCode 13），2026-10-25。

## 1. 服务位置与画面范围

**本接口运行在 Quest 上，不在 AIPC 上。** 上位机、基站主机或 AIPC 作为客户端，访问 `http://<Quest 的 Wi-Fi IP>:8095/v1/view/...`。VR 原来对 AIPC 的 8088/8092 连接继续工作，控制协议和发送频率不变。

进入应用内 VR 场景并完成图形初始化后，接口自动监听 8095；默认既不录像也不开直播。暂停应用会结束录像、停止直播；恢复后需重新启动。退出 VR 场景会关闭服务。下载录像时也需要保持 VR 场景或暂停中的该 Activity 存活，或使用 ADB 获取文件。

- 录制内容是**本应用所绘制的单眼未畸变视野**：三维场景、视频、点云、小地图、菜单、状态栏、手柄等。录制时打开菜单，菜单也会出现在录像中。
- 可选择左眼或右眼，输出普通二维视频；不拼接双眼，不生成双目 3D 视频。
- 不包括 Quest 系统主页、系统弹窗、其他应用或系统额外合成的透视层；不录麦克风/音频。
- 没有新增申请使能、租约或机器人运动接口。所有本服务请求只影响取景、录像和直播。

接口为 HTTP，不需要 HTTPS/证书。所有请求，包括状态、直播和下载，都需要：

```http
Authorization: Bearer 1
```

密钥复用当前 APP 设置里的连接密钥，默认 `1`。修改密钥后退出 VR、从设置重新进入，使本服务使用新值。服务不提供 query-string token，也不开放跨域 CORS；调用方需能访问 Quest 的 8095 端口。

## 2. VR 内操作

终端菜单增加“录像 / 直播”：

- 开始/停止录像；开启/关闭直播，两者可同时工作，共用一次硬编码。
- 画幅预设：1280×720、960×720、720×1280、1024×1024、1920×1080。
- 垂直视野角每次 ±5°；四边边距一起每次 ±2%；取景中心四向每次移动 0.05；左右眼切换、恢复默认。
- 显示当前画幅/FPS、取景参数、接口地址和错误。场景内有 REC/LIVE 指示。
- 四边单独边距、精确中心、FPS、码率通过下面的配置接口设置。界面同步读取同一份配置。

预设是否可用由本机硬件编码器能力决定。录像中修改分辨率/FPS/码率会被拒绝，先停止录像再改；FOV、边距、中心、左右眼可以边录边调。恢复默认如果涉及编码参数变化也遵守此规则。

## 3. 请求与响应

请求使用 HTTP/1.1，JSON 请求体 UTF-8。控制请求体最大 8192 字节，请求头最大约 8192 字节；不接受重复头或 chunked 请求体。JSON 数值必须是有限数字，整数参数不接受小数，未知参数报错。每次请求结束连接，直播响应例外地持续发送；控制启动/停止幂等，不会重复创建多个编码器。

| 方法 | 路径（均以 `/v1/view` 开头） | 作用 |
|---|---|---|
| GET | `/status` | 完整状态、配置、生效取景和错误 |
| GET | `/config` | 同 `/status`，配置在 `config` 对象内 |
| PUT | `/config` | 部分更新配置，未提供字段保留当前值 |
| POST | `/record/start` | 开始本地 MP4 录像 |
| POST | `/record/stop` | 停止并封装本地录像 |
| POST | `/live/start` | 开启直播编码，尚无接收端也可以保持开启 |
| POST | `/live/stop` | 停止直播，关闭接收连接；若正在录像则保留编码器 |
| POST | `/keyframe` | 请求编码器尽快产生同步帧 |
| GET | `/live.h264` | 标准 H.264 Annex-B HTTP 直播 |
| GET | `/live.tlzv` | 带时间戳、尺寸和帧边界的 H.264 直播 |
| GET | `/recordings` | 已正常封装的录像清单 |
| GET | `/recordings/<name>` | 下载指定的已完成 MP4 |

POST 使用空请求体或 `{}`；参数只通过 PUT `/config` 设置。

### 配置字段

```json
{
  "width": 1280,
  "height": 720,
  "fps": 24,
  "bitrate": 4000000,
  "eye": 0,
  "vertical_fov_deg": 70,
  "margin_left": 0.02,
  "margin_right": 0.02,
  "margin_top": 0.02,
  "margin_bottom": 0.02,
  "center_x": 0.5,
  "center_y": 0.5
}
```

| 字段 | 范围/含义 |
|---|---|
| `width` / `height` | 输出编码画面实际像素宽高。偶数；宽≥320、高≥240；单边≤1920；像素总数≤2,073,600。还需硬件编码器支持该画幅/帧率 |
| `fps` | 5–30，输出采样上限；实际帧率取决于 XR 有效帧、GPU 和编码器负载，不补造中间帧 |
| `bitrate` | 250000–16000000，目标编码码率，bit/s |
| `eye` | 0 左眼、1 右眼 |
| `vertical_fov_deg` | 20–120，边距裁剪前的期望垂直视野角，单位度；受实际单眼视野限幅 |
| `margin_*` | 每边 0–0.45，表示从**已适配期望视野角的取景窗**相应边裁掉的比例，不是输出黑边。改变边距会改变取景范围；上下/左右各保留至少 10% |
| `center_x` | 0–1，取景窗可移动范围内从左到右的位置，0.5 居中 |
| `center_y` | 0–1，取景窗可移动范围内从上到下的位置，0.5 居中 |

参数保存到本机，下次进入 VR 继续使用；不自动恢复录像/直播的开启状态。

FOV/边距/中心/单眼变更，在后续有效采样帧实时生效，无需重启编码器。实际源单眼视野以运行时为准，不能靠调大角度生成原视野之外的画面；边距也会缩小最终有效 FOV，所以最终垂直角可能小于配置的 20° 下限。

只有直播时修改宽高/FPS/码率：校验后停止旧编码器和旧接收连接，重新建立编码器。接收端**必须重连**并重新解析 SPS/PPS/尺寸。自带 Python 预览客户端会重连。录像中同类修改返回 409，配置不变，避免在一个 MP4 内混入不同编码规格。若重启因实际编码资源不足而失败，直播会停止，应查询 `status.error`、降低规格后重新开启，不要认为旧流仍在运行。

### 状态响应

```json
{
  "version": 1,
  "ready": true,
  "foreground": true,
  "encoding": true,
  "recording": false,
  "streaming": true,
  "config": {"width": 1280, "height": 720},
  "effective": [0.05, 0.17, 0.95, 0.83, 88.0, 56.0, 2064.0, 2208.0],
  "effective_order": ["left_uv", "bottom_uv", "right_uv", "top_uv", "horizontal_fov_deg", "vertical_fov_deg", "eye_width", "eye_height"],
  "frame_age_ms": 25,
  "exported_frames": 240,
  "encoded_frames": 239,
  "clients": 1,
  "session_id": 1,
  "current_recording": null,
  "last_file": "",
  "error": "",
  "encoder": "<设备编码器名>",
  "service_port": 8095,
  "service_running": true
}
```

上例数字仅解释结构，`config` 实际返回全部字段。`effective` 是最后一次成功送入导出路径的取景计算结果，首次采样前为空数组；它依赖实际设备的单眼 FOV，不能使用上述示例值硬编码。归一化 UV 原点在**左下角**，与配置 `center_y=0` 表示上边的方向约定不同。网页绘制裁剪框时，顶边坐标为 `1-top_uv`。实际 GPU 裁剪边界按源像素四舍五入，存在至多约 1 像素的边界误差。

`frame_age_ms` 无有效帧时为 null，否则是本机距最后导出帧的时间；不是网络端到端直播延时。`exported_frames`、`encoded_frames` 是本 Activity 的累计计数，异步管线瞬间可能不同；`session_id` 随编码器生命周期变化。`error` 汇总最近操作/编码错误与服务启动错误。`ready=true` 只表示图形上下文已附接，不等于此刻有有效追踪或已成功取得硬编码资源。

### 错误码

400 参数/JSON/请求无效；401 缺少或错误密钥；404 路径或录像不存在；405 方法不支持；409 状态冲突（例如先开直播、录像中不允许改编码规格、前台未就绪、硬件不支持）；500 设备/文件/编码初始化等运行错误。错误体形如 `{"error":"..."}`。启动操作可能需要几秒，超时后先 GET status 再决定下一步。

## 4. 透视与取景规则

输出是选中单眼在 OpenXR 镜头畸变之前的线性投影图，不使用设备显示器的畸变画面，不拉伸双目截图。

1. 获取该帧该眼实际非对称 FOV，使用其 `tan(left/right/up/down)` 建立投影平面。
2. 在实际视野内，按期望垂直 FOV 与输出宽高比拟合基础取景窗；根据中心参数移动。
3. 从该基础窗裁掉四边边距，再居中取一个能保持输出宽高比的最大子窗。不能同时把任意裁剪矩形四角都强行铺满而保持正确透视，因此不匹配的维度会进一步裁切，不用拉伸补齐。
4. 计算源单眼纹理上的归一化 UV 范围，经 GPU 裁剪/缩放至输出实际宽高。
5. 返回最终有效角度与范围。改变角度/边距只影响导出，不修改佩戴者实际 VR 投影或控制坐标。

若最终 UV 为 `(u0,v0,u1,v1)`，原始四边切线为 `tL,tR,tD,tU`，满足：

```text
((u1-u0)*(tR-tL)) / ((v1-v0)*(tU-tD)) = width / height
水平有效角 = atan(tL+u1*(tR-tL)) - atan(tL+u0*(tR-tL))
垂直有效角 = atan(tD+v1*(tU-tD)) - atan(tD+v0*(tU-tD))
```

角度结果换算为度。这保证投影平面上的相同长度在水平/垂直方向具有相同像素尺度，横竖屏不会把场景拉扁；像素取整仍有上述边界误差。输出分辨率提高也不会凭空增加源视野细节。

## 5. 直播二进制格式

### `/live.h264`

- `Content-Type: video/h264`，HTTP/1.1 chunked 响应，无音频。
- 内容是连续 H.264 Annex-B 访问单元，**HTTP chunk 边界不应作为 H.264 NAL/帧边界使用**；交给 H.264 解复用/解码器处理。
- 新接收端等待同步帧；同步帧前附带当前 SPS/PPS，并向编码器请求关键帧。编码器还配置约每秒一个关键帧。
- 采用 AVC Baseline、无 B 帧的低延时配置，硬件实际支持情况需设备验证。
- 普通浏览器 `<video src=...>` 不能直接当 MP4 播放本端点；使用 FFmpeg/GStreamer 或实现下一节的时间戳接入。不是 HLS/RTSP/WebRTC。

### `/live.tlzv`

`Content-Type: application/x-tlz-view`，HTTP chunked。解开 HTTP chunked 后，每条应用帧为 **32 字节头 + payload**。TCP/HTTP 分段可能拆分或合并帧，接收端必须累积读取，不能假设一次 read 就是一帧。

所有多字节字段采用**网络大端序**：

| 字节偏移 | 长度 | 字段 |
|---|---|---|
| 0 | 4 | ASCII `TLZV` |
| 4 | 1 | 版本 1 |
| 5 | 1 | flags，bit0=同步帧，其他为0 |
| 6 | 2 | 头长 32 |
| 8 | 4 | 访问单元序号，u32，按2³²回绕；首帧不要求0 |
| 12 | 8 | presentation timestamp，u64，微秒，发送端单调时钟域 |
| 20 | 2 | 实际编码宽度 u16 |
| 22 | 2 | 实际编码高度 u16 |
| 24 | 4 | payload字节数 u32，不含32字节头 |
| 28 | 4 | 保留，必须为0 |
| 32 | payload长度 | 一个完整 H.264 Annex-B 访问单元；关键帧前附当前SPS/PPS |

时间戳来自该帧 GPU 导出的单调时间，经编码器 presentationTimeUs 输出；不是 UTC/NTP 时间。可用于播放节奏、帧间隔与同发送端时间域的分析。**没有跨机时钟同步时，不可直接用客户端当前时间减它当链路延时。** 本版本不修改之前 AIPC 控制链路的延时统计接口。

接收端应在首次同步帧后开始解码，按访问单元处理，解码器检测分辨率/SPS变化；连接结束后重连。`live.tlzv` 比裸 H.264 更适合上位机保留时间戳和实际尺寸。

## 6. 本地录像

H.264/MP4，无音轨。录像从下一同步帧开始写入，文件首个有效样本 PTS 归零，使用真实帧时间，不靠累计帧数伪造恒定帧间隔。点击停止、应用暂停或正常退出会关闭并封装 MP4。空间不足时结束录像：启动至少128MiB可用空间，录制中定期检查、低于64MiB停止。

- 正在写入的文件名带 `.partial.mp4`，不进入清单，不允许通过下载接口读取。
- 正常封装后改名为 `view-设备本地时间-随机标识.mp4`。
- 异常断电/强制杀进程可能留下未封装的 partial 文件；本版不承诺修复这种 MP4。结束录制后再取文件。
- 通常保存于 `/sdcard/Android/data/com.tanluzhe.controlterminal.vr/files/recordings/`，若外部应用目录不可用则回落内部应用目录。优先用鉴权下载接口获取。

GET `/recordings` 返回：

```json
{"files":[{"name":"view-20261025-120000-123-abcd1234.mp4","bytes":1200000,"modified_ms":1792900800000}]}
```

GET `/recordings/<name>` 返回 `video/mp4` 和 Content-Length，下载完整文件；本版不实现 Range/分段续传或 HTTP 删除接口。

## 7. 线程、性能和生命周期

```mermaid
flowchart LR
  XR[单眼已合成视野] --> GPU[切线空间裁剪 / GPU三槽缓冲]
  GPU --> EGL[独立共享EGL上下文 / 同步栅栏]
  EGL --> AVC[单个H.264硬件编码器]
  AVC --> MP4[本地MP4]
  AVC --> HTTP[HTTP有界队列]
  HTTP --> PC[上位机直播客户端]
```

没有为了录像在 XR 线程逐帧 glReadPixels/Bitmap 压缩；GPU槽忙就跳过导出采样，避免在 XR 线程等待网络或编码消费。单独编码输出线程及时取走编码器输出；录像和直播复用同一次编码。SRGB缓冲与输出着色器处理颜色转换，避免导出意外变暗。

同时最多2个直播接收端，每端队列8个访问单元。慢端队列满或网络写长时间阻塞会断开该端，需重新连接并等同步帧，不丢掉参考P帧后强行继续解码。关闭直播、重新配置编码尺寸和退出会结束旧连接。

硬编码、额外GPU复制、存储和无线发送仍会消耗资源，不能据此承诺对显示帧率零影响。默认1280×720/24FPS/4Mbit/s是起始设置；需要 Quest 上在双路HEVC输入同时播放时实测可用并发资源和帧率。硬件不支持时明确报错，当前实现不悄悄降级为高CPU的软件编码。

## 8. 客户端示例

交付目录提供 `vr_view_client.py`，Python标准库即可使用控制/下载；预览另外需要本机 `ffplay`。**host填写QuestIP，不是AIPCIP。**

```powershell
python .\vr_view_client.py --host 192.168.1.50 status
python .\vr_view_client.py --host 192.168.1.50 config --config-file .\capture-config.example.json
python .\vr_view_client.py --host 192.168.1.50 record-start
python .\vr_view_client.py --host 192.168.1.50 record-stop
python .\vr_view_client.py --host 192.168.1.50 files
python .\vr_view_client.py --host 192.168.1.50 download --name view-20261025-120000-123-abcd1234.mp4 --out .\view.mp4
python .\vr_view_client.py --host 192.168.1.50 preview
python .\vr_view_client.py --host 192.168.1.50 live-stop
```

示例IP/文件名需替换成实际值。预览客户端会开启共享直播，读TLZV后把H.264送给ffplay，并在服务因改规格断开时重连。Ctrl+C或关闭播放器只关闭本接收端，不停止其他接收端/录像；需要停止共享直播时再调用 live-stop。该简单预览器按H.264码流播放，未将TLZV的单调时钟PTS转换成跨机墙钟延时。

也可通过 USB：`adb -s <Quest序列号> forward tcp:8095 tcp:8095`，再使用 `--host 127.0.0.1`。这只转发服务，不负责唤醒/启动VR。

## 9. 验证范围与实机验收

本轮完成编译、原生构建、签名、取景数学、真实Socket传输与桌面共享EGL检查。未在Quest上运行实际MediaCodec录制/双路HEVC并发和外部直播，不能把桌面检查当成实机录像验收。

提供可选设备自测，使用交付目录 `verification/handoff-test.apk`，需**先退出VR场景**。该测试不启动OpenXR或连接机器人，在设备EGL共享上下文中生成16帧测试画面，验证硬件AVC输出、本地MP4尺寸/样本PTS及并行直播访问单元：

```powershell
adb -s <Quest序列号> install -r .\verification\handoff-test.apk
adb -s <Quest序列号> shell am instrument -w -e capture true com.tanluzhe.controlterminal.vr.test/com.tanluzhe.controlterminal.vr.v2.HandoffInstrumentation
```

本轮仅编译该测试，未执行。测试文件在应用缓存的 capture-smoke 目录，配置使用隔离偏好，不覆盖正式参数。

现场还需验证：实际3D文字/人物或圆形物体在16:9、4:3、竖屏和正方形下无拉伸；四边和FOV实时修改范围正确；选定眼与未畸变视图一致；MP4实际可播放、开始/停止/暂停封装正常；两个接收端/慢端/重连可用；改直播尺寸后接收端更新SPS；双路HEVC输入并发时记录显示/控制发送帧率和温度。

实现所用标准参考：[Android MediaCodec](https://developer.android.com/reference/android/media/MediaCodec)、[Android MediaMuxer](https://developer.android.com/reference/android/media/MediaMuxer)、[OpenGL ES 3.0.6 规范](https://registry.khronos.org/OpenGL/specs/es/3.0/es_spec_3.0.pdf)（投影、共享对象、同步与sRGB读写）。

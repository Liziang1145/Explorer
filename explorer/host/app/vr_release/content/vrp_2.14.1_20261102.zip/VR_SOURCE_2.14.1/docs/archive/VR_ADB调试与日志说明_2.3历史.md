# 探路者控制终端 2.3：安装、日志与ADB调试

日期：2026-10-19。包名`com.tanluzhe.controlterminal.vr`，版本`2.3.0-development`，ARM64。连接默认HTTP/WS端口8080，密钥默认`1`；原有非空自定义密钥继续保留。此处是开发APK，不要求HTTPS证书。

## 安装与页面

```powershell
adb -s QUEST_SERIAL install -r "探路者-控制终端-2.3.0.apk"
```

连接页只有当前基站连接、本地输入演示和日志，没有旧UDP端口、旧引擎或兼容模式。IP可自动读取Wi-Fi网关；手动模式自带数字、`.`和退格键，也可以打开系统URI文本键盘。IP包含三个点，不使用只允许一个小数点的数字输入模式。保存时校验四段IPv4。连接密钥为空时使用`1`，不写入日志。

“检测基站”只GET `/v2/health`：区分主机不可达/超时、HTTP401/403密钥不一致、404接口缺失和HTTP成功。成功仅证明HTTP可达，不证明WebRTC或车端已就绪，不创建控制会话或租约。

VR底部为视频、地图、菜单、日志和退出五个大按钮。菜单内集中放置申请控制权、同步参考、显式授权、停止、日志和退出。A确认高亮项，B返回，X切换视频，Y打开菜单；左摇杆在弹窗内选择，亦可用射线和食指扳机点击。ABXY不会进入网络输入掩码。菜单和日志页会停止操控，但原始观察快照继续按有效性发送。

## 日志

设置页“查看详细日志”可刷新、筛选警告错误、复制完整文字；VR“日志”按钮打开分页详情。日志包含时间、级别、模块、事件码、原因。保存路径为`files/logs/ui.jsonl`、`files/logs/vr.jsonl`；每个进程保留当前文件及两份轮转文件，每份约256KiB，写入队列有界。异常突发时允许舍弃旧排队日志，不阻塞XR采样。

| 模块/事件 | 含义 |
|---|---|
| NET/SESSION_BEGIN、HTTP_RESULT | 注册及配置请求、路径、HTTP结果；不记录Authorization头或密钥 |
| NET/WS_OPEN、LINK_FAILED | 信令建立或失败及原因 |
| RTC/ICE_STATE、CHANNEL_STATE | control/media与各DataChannel状态 |
| INPUT/SAMPLE | 约每秒采样摘要：真实模拟值、valid_mask、追踪和本地模式预览 |
| INPUT/OBSERVATION | 发送成功数、丢弃数、编码字节、实际观察Hz、使用的通道；不是车端执行回执 |
| INPUT/ENCODE_FAILED、PROTO/PACKET_REJECT | 编码失败或收到的包无效 |
| CONTROL/LEASE_REQUEST、SYNC_REQUEST、ARM_REJECT、STOP | 页面事务、本地检查失败条件及停止原因 |
| XR/GL_READY、NATIVE_ERROR、PAUSE | 图形初始化、错误、暂停撤销授权 |

当前输入扩展只发送观察数据，由AIPC实现运动模式、标定、IK和安全授权网关。界面本地授权检查通过、密钥验证通过、key11到达都不能单独等同于机器人获准移动。此版不再把摇杆积分成机器人底盘位姿，不自动生成CONTROL_SETPOINT；主协议0x0101格式仍供后续受授权的目标产生方使用。停止、租约与同步事务保留。

## ADB读取

命令必须指定Quest的serial。开发APK支持`run-as`，不需要root：

```powershell
adb -s QUEST_SERIAL logcat -v threadtime TLZ.APP:I TLZ.UI:I TLZ.NET:I TLZ.RTC:I TLZ.INPUT:I TLZ.CONTROL:I TLZ.PROTO:I TLZ.XR:I TLZ.ADB:I TLZ2:I '*:S'
adb -s QUEST_SERIAL exec-out run-as com.tanluzhe.controlterminal.vr cat files/logs/vr.jsonl
adb -s QUEST_SERIAL exec-out run-as com.tanluzhe.controlterminal.vr cat files/logs/ui.jsonl
adb -s QUEST_SERIAL exec-out run-as com.tanluzhe.controlterminal.vr cat files/v2-diagnostics.json
```

日志文件在首次使用相应进程后创建。最后一份诊断可能来自已经退出的会话；用下面的status看`vr_running`，并结合`run_id`、`demo`和文件时间判断，不能把历史快照当实时状态。

## 简要调试

开发版提供显式组件`com.tanluzhe.controlterminal.vr/.DebugReceiver`，要求调用方拥有Android `DUMP`权限。正常ADB shell通常具有此权限；如果设备策略拒绝，可继续使用`run-as`读取文件。release构建禁用该Receiver。

```powershell
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command status
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command snapshot
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command probe
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command demo
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command logs
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command video --ei mode 0
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command stop
adb -s QUEST_SERIAL shell am broadcast -n com.tanluzhe.controlterminal.vr/.DebugReceiver --es command exit
```

video mode为0关闭/1小窗/2大屏。demo只进入本地虚拟输入演示；已有VR会话时不再启动第二个会话。stop撤销本地授权并发送停止事务，exit停止后返回设置。调试入口不提供使能、申请控制权或伪造运动输入命令。snapshot是JSON状态，不会自动截取真实相机画面。

附带`vr_adb_debug.ps1`要求显式serial并检查设备型号为Quest，支持install/status/snapshot/logs/probe/demo/stop/exit/video/logs_ui/collect：

```powershell
.\vr_adb_debug.ps1 -Serial QUEST_SERIAL -Action install
.\vr_adb_debug.ps1 -Serial QUEST_SERIAL -Action collect
.\vr_adb_debug.ps1 -Serial QUEST_SERIAL -Action video -Mode 1
```

## 验证边界

本轮没有Quest在本机，只交付APK：已完成321项Java离线断言及152项独立OPC1紧凑编解码检查、2200项原生视角矩阵检查、独立Python CBOR交叉解码、ARM64/Android编译与APK清单/内容检查。新的键盘、VR页面、观察频率实测、ADB Receiver及日志详情尚未在本轮Quest上运行；2026-10-18旧2.1包的实测不能代替本包验收。

可选`handoff-test.apk`以`-PhandoffSmoke assembleDebugAndroidTest`构建，无需佩戴/联网，检查默认密钥、三点IP编辑、旧入口缺失、ADB权限、日志脱敏及四种HUD纹理：

```powershell
adb -s QUEST_SERIAL install -r handoff-test.apk
adb -s QUEST_SERIAL shell am instrument -w -r com.tanluzhe.controlterminal.vr.test/com.tanluzhe.controlterminal.vr.v2.HandoffInstrumentation
```

它只编译交付，本轮未执行。即使通过，也不代表厂商系统键盘、XR追踪或真实AIPC链路已验收。

压缩可选协商见[OPC1规范](VR控制输入压缩传输规范_OPC1_20261019.md)；INPUT/ENCODING_SELECTED记录会话选择，OBSERVATION日志和JSON快照的observation_encoding记录实际使用格式（可能回退cbor）。

2.3诊断新增display_hz（真实提交帧率）、view_mode（observer/follow）、vehicle_pose_fresh及hud_text_hz。display_hz与发送帧率observation_actual_hz（配置项为observation_hz_requested）是不同指标；无运行采样时display_hz为null。

# VR v2：实现、界面与对接契约

日期：2026-10-19。范围仅为VR应用；本文不表示AIPC、基站服务已经实现。主规范为工作区根目录《探路者全链路通信协议规范_v2.0.md》。本文将其中尚未冻结的JSON字段、事件和统计键落实为当前VR实现的对接约定，其他两端应据此共同核对。

## 1. 交付状态与验证边界

新增从源码构建的OpenXR/GLES运行层，采用真实左右眼视图、头显/手柄追踪。当前APK已移除旧入口、旧UDP参数、旧引擎和旧着色器，不再依赖原APK构建；仅使用固定哈希的通用OpenXR loader及当前源码引擎。应用包名仍为`com.tanluzhe.controlterminal.vr`，版本`2.3.0-development`，名称和图标仍为“探路者-控制终端”。原始`org.khronos.openxr.cloud_demo`不改动。

已实现的客户端代码：

- 两条独立WebRTC连接、HTTP/WS注册与信令和设备令牌，无需证书或指纹配置。
- v2公共头/严格CBOR、每stream独立序号、最新观察采样、租约/显式本地授权检查/停止/暂停撤销授权。
- 原始头显/手柄/视锥沿用OPERATOR_STATE key0–10，新增key11保存侧键、食指扳机与摇杆；不包含ABXY。v2模型仍可接收车端关节和位姿反馈。
- 状态与显示姿态驱动的线框，区分真实反馈与命令；当前用简化线框表示对象，不宣称精确双臂数字孪生。
- H.264硬件解码、GPU视频纹理、按帧元数据追踪采集到提交年龄；无匹配时显示N/A。
- 地图完整块原子发布、SHA-256检查、HTTP缺块恢复、实时点云独立块与超时清理、60k点显示上限。
- 四时间戳对时提案、基站确认映射、两段与端到端RTT、控制到达估计、中继驻留、反馈/视频丢包统计。
- 无网络虚拟演示，显示明确标记的测试图、点云和机器人线框，不创建BaseLink、不发送机器人控制。

离线测试覆盖codec、非法包、租约、时钟、地图原子性/损坏/删除、陈旧点云、视频时间关联、反馈几何与丢包乱序窗口。Android APK和ARM64原生库可以在本机构建。

以下为历史2.0/2.1验证，不能代替本轮2.3验收：基础双眼演示渲染及H.264本机回环已在Quest验证；2.0.1版HTTP配置/地图下载及WS收发也已在Quest本机验证。2.1实机记录Touch Plus双手有效追踪、A/B/X/Y、双摇杆/扳机/侧握模拟轴、射线点击、视频三种模式与退出请求；用户确认操作有响应且退出返回设置。**未验收项：**真实v2基站/AIPC联通、真实视频的SurfaceTexture时间关联、真实地图与手柄控制效果、全部快捷键、完整暂停/恢复生命周期及整车联调。验证记录另见开发版交付目录；本机演示不能代替真实链路验收。

本版只协商H.264硬解、单视频轨道、点格式1–4和`compression=none`；不宣告支持Zstd、RGB-D原始深度、双视频分层、FEC或音频。基站按能力选择，不能发送未协商格式。VR显示的是局部地图缓存，完整地图由基站保存。

## 2. 界面与手柄设计

当前连接页只有基站连接、本地输入演示、检测基站和详细日志；已完全移出旧版入口及端口设置。自动地址读取Wi-Fi网关，手动IP支持三个点，自带数字/小数点键盘。端口默认8080，连接密钥默认`1`（已有非空密钥保留），无需证书。高级输入参数：观察10–90Hz、全按0.95/释放0.90、预览死区0.10，均可调整。

当前2.3改为浅色空间界面：视频与状态卡固定在车辆前方，不随转头移动；帧率、延时和控制栏位于视线中心偏下，随视角移动。控制栏有视频、地图、菜单、旁观/跟随切换、日志、退出六项。菜单、视频设置和日志工具作为临时交互面板跟随视角，车辆状态信息仍留在世界层。设置/日志页面使用定制圆角、浅色面板和点击反馈，不使用系统默认按钮外观。

本地手柄体积线框、射线与光标按OpenXR预测显示时间逐帧定位、绘制，不经过Java位图或网络发送定时器。HUD文字/按钮约20Hz更新，世界信息约5Hz更新，但两张纹理在每个XR帧重新投影，空间运动不会被文字刷新频率限制。网络观察发送仍由独立ObservationRate定时器控制，默认50Hz，可配置10–90Hz，本轮未调整；车端真实反馈的刷新率取决于服务端，不能冒充本地显示帧率。

默认旁观模式：显示相机使用原始XR头显位置/方向，可在实际空间观察；跟随模式：显示视点中心锁定车辆位置上方1.6m，保留头部旋转与真实双眼间距，物理平移不改变虚拟视点中心。两种模式仅修改渲染，不修改传输的原始头显/手柄姿态、参考系或控制协议。

场景原点在首次有效追踪时以用户水平朝向对齐；优先使用OpenXR STAGE地面，缺失时以初始头高减1.6m估计。背景为本地程序化的浅蓝灰天空、柔和地平线与衰减地面网格，不是调用或复制Quest系统Home场景。未使能时车辆显示位置默认原点；使能且收到有效反馈时，使用经参考系变换的实际底盘位置和水平朝向，反馈陈旧时保持最后显示位置并标记，禁止外推。视频/信息板中心位于车辆前方3.8m、高1.65m；视频默认宽幅、可选标准或关闭，两种大小始终绑定车辆。原点与1.6m虚拟眼高仅为显示约定，不是机器人标定。

详细坐标、帧率与验收说明见[VR空间界面与双视角](VR空间界面与双视角_2.3.md)。

| 本地操作 | 当前行为 |
|---|---|
| A | 确认当前高亮页面项；无高亮时打开菜单 |
| B | 返回上级页面；在主场景打开菜单并停止 |
| X | 视频标准→宽幅→关闭循环 |
| Y / 左菜单 | 打开/关闭终端菜单；打开撤销本地授权并发停止事务 |
| 射线+食指扳机 | 点击对应手的射线目标，持续扣住不重复点击 |
| 弹窗内左摇杆 | 上下选择页面项，A确认；不转换为车辆速度 |
| 左/右摇杆按下 | 保留地图/视频快捷切换 |
| B+Y按住1.2秒 | 备用退出，先停止再返回设置 |
| 菜单中的申请/同步/授权/停止 | 保留原租约、参考和安全检查；ABXY原始状态不因此加入传输字段 |

“上键”已由用户确认是左右食指模拟扳机。物理模式表为：无全按侧键idle、仅左全按vehicle_left（只取左摇杆）、仅右全按vehicle_right（只取右摇杆）、双侧全按arms（车辆意图无效，手柄分别对应双臂，食指扳机分别对应夹爪）。VR只做本地预览和原始采集，AIPC负责最终模式、标定、速度单位/范围、IK与安全网关。阈值采用可调迟滞；从arms释放一侧、失焦/追踪失效/UI操作后，预览需两侧释放且摇杆回中才重新选择，避免误切车辆。

**当前2.3不会把摇杆积分成机器人底盘目标，也不自动生成CONTROL_SETPOINT。** 主规范0x0101结构不变，供受授权目标产生方使用；原始0x0104、连接密钥、租约和本地授权状态都不能单独被下游当作移动授权。基站与AIPC须另外实现安全网关，再按实际底盘能力确定摇杆物理映射。此前2.1的VR内位姿积分不再使用。

地址为`http://基站IP:8080`、`ws://基站IP:8080/v2/events`，HTTP和WS握手均带Bearer密钥。HTTP/WS为局域网明文通路。WebRTC内部DTLS由协议栈自动处理；无用户证书步骤。视频/地图解码和反馈接口保持不变。

手柄使用OpenXR左右grip/aim动作空间与Touch/Touch Plus/Touch Pro/Simple绑定。模拟控件逐项依据`isActive`和XR焦点设置有效位，不用姿态是否追踪来伪造模拟0。左右射线由应用绘制；输入震动仅代表UI已识别，不代表车端执行。暂停停止授权但不因普通暂停主动结束XR会话。

[日志与ADB说明](VR_ADB调试与日志说明.md)包含时间/模块/事件码、错误原因和只读检测，调试入口没有使能或运动伪造命令。接口参考：[Meta动作/绑定](https://developers.meta.com/vr/documentation/native/android/mobile-openxr-actions-actionsets-bindings/)、[Android字符输入过滤](https://developer.android.com/reference/android/text/method/DigitsKeyListener)。

## 3. POST /v2/sessions

VR请求：

```json
{
  "protocol": "TLZ/2.0",
  "role": "vr",
  "device_uuid": "persistent-device-uuid",
  "boot_uuid": "new-uuid-for-this-session",
  "capabilities": {
    "max_message_bytes": 1100,
    "input_controls_revision": 1,
    "operator_hz": 50,
    "operator_encoding_profiles": ["cbor", "opbin1", "opq1"],
    "setpoint_owner": "aipc",
    "point_formats": [1, 2, 3, 4],
    "point_attribute_policy": "base_filtered",
    "compression": ["none"],
    "video_codec": "H264",
    "max_tile_bytes": 262144,
    "max_scene_points": 60000
  }
}
```

最小响应：

```json
{
  "session_id": "123456789",
  "operator_encoding": "cbor",
  "node_id": 2,
  "base_node_id": 1,
  "clock_epoch": 1,
  "config_revision": 1,
  "ice_udp_range": [41000, 41031]
}
```

所有64位ID/ns在JSON中用十进制字符串；二进制codec保留完整u64位宽。返回的会话绑定Bearer令牌。不同VR/AIPC会话使用不同session_id，基站转发时改成对应下游会话，保留原来源/序号/采样时间。

## 4. GET /v2/config

下面仅是**虚拟测试数据**，不能把示例恒等外参直接用于真车。矩阵为列主序T_map_frame；OpenXR原始右/上/后坐标在VR发送操作者姿态时统一转换为前/左/上。对姿态先做相对头显变换，再进行基变换，手部缩放/偏置仍由AIPC根据reference_revision应用一次。

```json
{
  "robot_id": 1,
  "robot_node_id": 3,
  "map_epoch": "1",
  "reference_revision": 1,
  "point_attribute_policy": "base_filtered",
  "target_base_frame_id": 1,
  "target_hand_frame_id": 4,
  "operator_frame_id": 2,
  "base_frame_id": 3,
  "streams": [
    {"name":"control.setpoint","id":101},
    {"name":"operator.state","id":102},
    {"name":"probe","id":103},
    {"name":"robot.state.base","id":201},
    {"name":"robot.state.arms","id":202},
    {"name":"control.receipt","id":203},
    {"name":"link.stats","id":204},
    {"name":"lidar.live","id":301},
    {"name":"camera.depth_cloud","id":302},
    {"name":"map.tiles","id":303},
    {"name":"scene.poses","id":304},
    {"name":"video.metadata","id":401}
  ],
  "frames": [
    {"id":1,"name":"map","T_map_frame":[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]},
    {"id":2,"name":"operator_stage_flu","T_map_frame":[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]},
    {"id":3,"name":"base_link","T_map_frame":[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]},
    {"id":4,"name":"teleop_head_reference","T_map_frame":[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]}
  ]
}
```

sample的key4是**该sample时间戳所属的node_id**，A测量填A，B估计填B。基站不能把A采样时间保留却把source改为B。状态sample必须提供key0时间、1epoch、2valid、3value、4node、5quality；base_pose要使用target_base_frame_id这一实际地图/里程计参考，VR才会用其初始化底盘目标。基站使用控制进度时区分已收到、已接受、已进入控制循环和已下发。

基站推送SCENE_POSES可承担机械臂模型正运动学，VR绘制简化姿态线框。动态base_link变换由真实base_pose更新。地图/相机外参必须来自真实标定，未知frame的数据拒绝显示。

## 5. WebRTC与信令事件

VR先连WS，再分别POST SDP offer。B监听VR创建的DataChannel，不再创建相同label的第二条通道。C与M分别使用独立PeerConnection；UDP直连，TCP候选关闭。媒体offer是recvonly H.264视频+scene DataChannel，不请求麦克风或相机采集权限。

WS统一信封：

```json
{
  "event_id": "a-uuid",
  "type": "ice.candidate",
  "session_id": "123456789",
  "payload": {"pc":"control","sdpMid":"0","sdpMLineIndex":0,"candidate":"candidate:..."}
}
```

| 事件 | 发起方 | payload关键字段 |
|---|---|---|
| ice.candidate | V/B | pc=control或media、sdpMid、sdpMLineIndex、candidate |
| lease.request | V | robot_id、reference_revision |
| lease.granted/renewed | B | holder_node_id、lease_id字符串、expiry_B_ns字符串、allowed_mask；须已获A接受 |
| lease.renew | V | lease_id字符串，约250–300ms一次 |
| lease.revoked | B | reason；VR立即清空租约和本地使能 |
| sync.request | V | lease_id、reference_revision |
| sync.result | B | status=completed、state_seq字符串、reference_revision；只有真实A确认才发completed |
| stop.request | V | stop_event_id、lease_id、reason、latch=true；C包与此事件关联stop_event_id |
| stop.result | B | stop_event_id、status；VR保持未使能 |
| clock.mapping.propose | V | 下节映射字段；B校验并确认，不能不加验证广播其他节点映射 |
| clock.mapping | B | 确认后的A/B/V映射；至少2Hz刷新相关映射 |
| map.manifest.changed | B | epoch、revision；VR刷新局部清单 |
| config.changed | B | revision；当前VR暂停操控，要求重新连接加载配置 |
| event.result | B | status、reason；特别是rejected要给明确原因 |

当前配置/地图epoch改变采用“暂停后重新连接”的明确策略，不在运动过程中自动切换坐标。新地图连接加载后丢弃旧块；未知epoch的实时包不能强制替换当前地图。

B→V点云应预变换到登记的稳定map/scene坐标，并带正确transform_revision，避免让VR按“当前base_link”变换一个过去采集的相机点。传感器外参、逐点/逐帧运动补偿和时间对齐放在A/B完成；不要把未配准的光学坐标点当地图点送来。

`base_filtered`是本开发版必需的显示处理能力：B完成法线/大小等旧属性的保真缓存、动态点寿命计算和可见性过滤，持久地图发给V的块只含静态有效点，动态点走短寿命实时流。V绘制位置/颜色与统一点大小，格式3/4可解码但不在VR中重建旧点生命周期算法。B必须在config回显该策略，否则VR拒绝进入联机控制；不能以忽略动态属性的方式假装完全兼容。A→B仍可保留所有原始点属性，B不能用VR显示副本覆盖源数据。

控制权恢复、停止解除的最终决策在A，不能仅因为V再次申请就绕开A的锁存停止条件。VR等待grant与sync后仍要求X显式使能。

## 6. 对时与延时字段

TIME_REQ/RESP、PING/PONG按主规范。B必须回显probe_id和原t1，端到端PING必须由A回复后经B回传；B不能代答“车端在线”。

`clock.mapping` JSON：

```json
{
  "node_id": 2,
  "epoch": 1,
  "ref_X": "1000000000",
  "ref_B": "1004000000",
  "drift_ppb": 0,
  "uncertainty_ns": "5500000",
  "updated_B_ns": "1010000000",
  "mapping_revision": 1
}
```

B也发送自己的恒等映射（ref_X=ref_B），以及A的当前映射。VR不直接把本地提案当作确认映射。A/B/V各自时钟质量/更新时间不满足条件时，VR不使能控制；RTT仍可测。

LINK_STATS当前冻结的CBOR key：0 interval_ms、1 expected_count、2 received、3 lost、4 reordered、5 duplicates、6 rtt_p50_ms、7 rtt_p95_ms、8 rtt_max_ms、9 rtt_mean_abs_consecutive_difference_ms、10 base_to_aipc_rtt_ms（B提供）、11 send_queue_bytes（可选）、12 clock_uncertainty_ms（可选）。浮点是f32，未知键缺省，不发送NaN或假0。

VR统计反馈序号缺口时给予200ms乱序窗口；面板反馈丢失按10秒窗口、视频丢包按WebRTC会话累计展示，二者标签不同。控制消息为每stream独立序号，不能用全局计数令正常流被误判丢包。

控制回执stamps用主规范key0–10。VR显示V输入到A收到与B驻留；没有源时间、epoch或有效映射就显示N/A。用户看见的不是“电机已运动完成”。

## 7. 视频对接

单路H.264、packetization-mode=1、无B帧、720p30起步；B转发时使用当前输出SSRC与RTP timestamp生成VIDEO_FRAME_META。B不能把转码时间当作新采集时间。

Android固定版本WebRTC解码器包装层用`floor(rtp_timestamp/90)*1e6`作为传入Java硬解的frame timestamp ns；客户端在解码回调取得这个帧标记，使用EglRenderer的presentation timestamp传给SurfaceTexture，从SurfaceTexture取到同一标记后关联VIDEO_FRAME_META。关联键不得用帧到达顺序。RTP wrap/视频epoch/SSRC变更后重建关联缓存。

该路径依据WebRTC官方Android包装层源码，但本机没有Quest硬件输出验证；实测若某解码器输出时间戳不保留该标记，客户端会显示采集时间未关联，必须修正映射后才能宣称测得视频年龄，不允许改成接收时间凑数。

当前客户端在已关联且有有效对时的情况下，丢弃确认超过200ms的解码输出，保留解码器参考链；这是丢弃过时显示，不是跳过H.264参考帧输入。WebRTC内部抖动缓冲的实际上限、NACK恢复时延及Quest硬解队列仍需抓包/实测，不能把源码中的20–50ms目标直接宣称为已达成的缓冲保证。

官方源码参考：[video_decoder_wrapper.cc](https://webrtc.googlesource.com/src/+/refs/heads/main/sdk/android/src/jni/video_decoder_wrapper.cc)、[video_frame.cc](https://webrtc.googlesource.com/src/+/refs/heads/main/sdk/android/src/jni/video_frame.cc)。构建依赖固定为`io.github.webrtc-sdk:android:144.7559.09`，下载来源与SHA-256见`tools/v2_deps/inputs.json`。

## 8. 地图清单与补块

VR每2秒核对局部清单，最多缓存64个tile，显示总点数最多60k，实时点云先于地图占用显示预算。基站应按该VR最新OPERATOR_STATE的位姿/FOV返回当前局部ROI与LOD清单（≤64条，近处优先），不向这个开发版返回未经筛选的整张大地图。完整地图依旧保存在基站。

清单响应示例：

```json
{
  "map_epoch":"1",
  "revision":"12",
  "tiles":[
    {
      "tile":[0,0,0],"version":"5","lod":0,
      "coordinate_frame_id":1,"transform_revision":1,
      "format":1,"origin":[0,0,0],"scale_m":0.01,
      "point_count":100,"object_size_bytes":1000,
      "sha256":"BASE64_OF_32_HASH_BYTES",
      "deleted":false
    }
  ]
}
```

路径`GET /v2/maps/1/tiles/0,0,0/5/0`返回1000字节未压缩点记录。SHA-256覆盖所有记录原始字节。最多2个并发补块，单块≤256KiB，超限拒绝；缺块下次清单检查继续。deleted=true保留版本/描述符字段，长度/点数0，零长度SHA-256，用于可靠删除。

实时tile包和HTTP对象使用相同descriptor；完整才发布，缺块期间继续显示旧完整tile。实时点云不补旧帧，150ms后清理，避免陈旧动态物体一直留在画面里。

## 9. 构建、测试与文件

Windows本机已有Android SDK/Android Studio JBR/Gradle。当前使用工作区NDK与OpenXR头、固定哈希的通用loader，静态链接C++运行时。loader缓存见vr/openxr-runtime.json；prepare_openxr_runtime.py只准备此运行库，不读取原APK或打包旧引擎。

```powershell
python tools/prepare_v2_dependencies.py
python tools/test_v2_contract.py
# 设置JAVA_HOME、ANDROID_HOME后，使用本机Gradle：
gradle -p vr --offline --no-daemon assembleDebug
```

`prepare_v2_dependencies.py`把官方NDK、固定版本AAR/JAR和OpenXR头保存在`tools/v2_deps`，不修改用户全局SDK；NDK还校验Google发布的SHA-1，全部下载记录SHA-256。该目录约数GB，已加入.gitignore，不应提交二进制SDK进Git。

Android Studio请单独打开`interaction-end/vr`作为工程；仓库根目录旧C++工程仍属于历史构建入口。`tools/v2_dependencies.lock.json`固定下载哈希。`python tools/check_v2_vectors.py`使用独立Python cbor2校验Java生成的控制/地图样例，cbor2安装在工作区测试目录即可；它不是APK依赖。

无证书HTTP/WS实机测试：以`-PhttpSmoke assembleDebugAndroidTest`构建，runner为`com.tanluzhe.controlterminal.vr.v2.HttpConnectionInstrumentation`。测试只访问设备自身127.0.0.1的临时服务，覆盖HTTP JSON、二进制地图、WS握手/回显以及拒绝自动重定向，不连接机器人，也不需要佩戴头显。

交互实测以`-PuiSmoke assembleDebugAndroidTest`构建，runner为`com.tanluzhe.controlterminal.vr.v2.VrInteractionInstrumentation`：生成四种平面HUD预览后启动虚拟VR，最多等待2分钟操作；`-e layoutOnly true`只验证HUD渲染，不启动XR。平面预览不含视频纹理和XR场景，不可当作实机眼视图。完整测试器要求单次运行内覆盖全部视频模式、射线点击、菜单、震动、退出；若分两次验证则可能报告INCOMPLETE，应按各项诊断与用户确认分别记载，不伪记为全项PASS。

实机测试包的默认runner为`com.tanluzhe.controlterminal.vr.v2.V2SmokeInstrumentation`，先执行设备本机WebRTC无序零重传数据通道与H.264硬编解码回环，再进入虚拟演示，等待实际XR渲染及完整PNG写入，写`files/v2-diagnostics.json`和一次虚拟场景眼视图`files/v2-eye.png`，不申请真实控制权。回环只发送PING和虚拟视频。当前已删除旧引擎及legacySmoke测试入口。

2026-10-18 Quest实机已通过本机回环（5帧H.264解码及时间戳一致）和双眼渲染；截图已确认模拟视频/HUD。点云视觉效果、手柄以及真实基站链路仍待验证，见交付目录`VR_V2_DEVELOPMENT_20261018/Quest实机验证记录.md`。

关键文件：

- `vr/src/main/cpp/terminal_v2.cpp`：OpenXR会话、双眼、手柄、GLES视频/点云/HUD。
- `vr/src/main/java/.../v2/V2Activity.java`：真实VR生命周期与虚拟演示。
- `BaseLink.java`：会话、信令、控制、租约、对时与补块客户端。
- `Cbor/Packet/ClockSync/ControlGate/SceneStore/RobotScene/VideoTiming`：可离线验证的协议核心。
- `tests/java/V2ContractTest.java`、`tools/test_v2_contract.py`：无机器人、无模拟器的离线契约测试。

正式联调顺序：双方按此契约启动虚拟基站→Quest只读视频/点云与时间验证→租约和停止异常注入→纯虚拟机器人控制→最后受控整车。当前开发APK不能仅凭编译通过就用于真车运动验收。

## 10. 2026-10-19 原始输入扩展

OPERATOR_STATE(kind0x0104，stream按配置通常102)保留key0–10，增加可选key11（input_controls）：

| key11内键 | 字段 | 类型 |
|---|---|---|
| 0 | revision | uint，固定1 |
| 1 / 2 | left_grip / right_grip | f32[0,1]，真实压下程度 |
| 3 / 4 | left_trigger / right_trigger | f32[0,1]，真实食指扳机压力，不倒置成开口 |
| 5 / 6 | left_stick / right_stick | f32[2]，每轴[-1,1]，不做线速度映射或死区处理 |
| 7 | valid_mask | uint，仅bit0左侧键、bit1右侧键、bit2左扳机、bit3右扳机、bit4左摇杆、bit5右摇杆 |

只携带有效位对应字段；有效的真实0仍发送，缺失不补0。无效扩展仍携带{0:1,7:0}。ABXY、数字按钮掩码、推算关节角、未经IK的电机目标均不在key11内。

观察发送由独立定时器控制，默认50Hz、可配10–90Hz，与探测10Hz/维护10Hz分开，未使能也继续发送。优先tlz.ctrl.v2，仅该通道未打开时用tlz.probe.v2；拥塞时有界丢弃，日志记录累计丢弃和实际Hz。保持原始采样time/epoch，不把重复发送包装成新传感器采样；采样陈旧100ms后清姿态与控件有效位，包仍标原采样时刻，过期后由接收方TTL/watchdog处理。尚无XR采样时不伪造输入包。

注册能力增加可选input_controls_revision=1、operator_hz=配置值、setpoint_owner=aipc。基站需保留key11透明转发，不能只接收到key11就驱动运动。含头显、双手、双眼、完整key11的已知样例总包397字节，50Hz编码净量约19,850B/s（不含传输开销）；这是编码计算，非本轮实机吞吐测量。

本轮2.2只有离线测试与构建/静态APK检查；用户头显不在本机，未安装、未做新UI/键盘/50Hz实测。交付内含JSON编解码样本、可选无需佩戴的handoff-test.apk及ADB说明。

## 11. 可选OPC1紧凑传输

完整规范见[OPC1服务端对接文档](VR控制输入压缩传输规范_OPC1_20261019.md)。POST注册请求上报operator_encoding_profiles，POST响应operator_encoding选择cbor/opbin1/opq1，缺失按cbor；当前GET配置不改变该选择。opbin1无损紧凑布局，opq1仅姿态定点量化，所有侧键/扳机/摇杆仍为原f32。完整已知样例397B→300B/260B；不是无线实测值。TLZ64B头、类型0x0104、flags0不变；紧凑主体用key12 byte string取代key3/4/5/6/11，其他元数据保留。各包独立，未知字段/范围或不能减小包长时回退CBOR。不要在未协商session发送key12，也不要压缩STOP/租约/时间探测。

本轮Java314项断言和独立Python紧凑编解码152项检查通过，服务端实际接入与无线测试未执行。开关由会话协商决定，客户端默认不改变已有服务的CBOR格式。

> 此文为2.9.1历史设计。2.11已按新要求恢复AIPC后台专用录制（VR内无录制按钮），当前接口见 [高质量录制与1080P预览](AIPC_VR高质量录制与1080P自适应预览接口_20261031.md)。

# VR 2.9.1：默认直播、固定居中取景

日期：2026-10-31；包名 com.tanluzhe.controlterminal.vr，versionCode 18。可覆盖安装原 2.9.0，不需要清数据。点云令牌和控制密钥仍按约定为 1，原点云适配保留；手机版未改动。

## 行为变化

- 移除本地 MP4 录像、文件封装/写盘和录像按钮，不再创建 recordings 目录。历史录像文件不自动删除。
- 进入实际 VR 场景、渲染上下文就绪且处于前台时，默认启动 H.264 硬件编码和直播。启动页尚未进入 VR 时不编码。
- 不需要后台再次发起 start，也不需要 VR 端确认；画面保留“直播中”提示，菜单“视野直播”中可取消。
- 暂停/休眠时停流并释放编码器；未被取消的直播在恢复前台后自动启动。菜单/后台明确取消后，本次场景会话内暂停恢复不会重开。重新进入 VR 场景默认开启；后台仍可 POST start 再开启。
- 分辨率、比例、FOV、边距实时协商保留。更改编码分辨率/FPS/码率会重建编码器，流连接会结束，接收端须重新订阅。

## 固定光轴居中

旧算法取单眼投影纹理的 UV 中点；OpenXR 的左右、上下视锥通常不对称，因此 UV=(0.5,0.5) 可能偏离眼睛正前方。新算法围绕所选眼正前方投影光轴（切线坐标 X=0、Y=0）取对称窗口，而不是围绕纹理几何中点。

- 横屏、竖屏、正方形与所有支持的宽高比均保持同一正前方中心；比例改变只改变取景范围。
- 同时满足目标宽高比与眼睛可用视锥，必要时缩小 FOV，不拉伸、不填黑边、不向某边平移。
- 旧配置 center_x/center_y 仍可被解析，但统一归一为 0.5，读取 config 返回实际值。旧的偏移设置不再生效，菜单移除中心移动按钮。
- 为避免非对称边距造成偏心，左右取 max(margin_left,margin_right)，上下取 max(margin_top,margin_bottom)，两边对称应用。返回的 config 已反映归一后的值。
- 实际 UV 裁切框不保证自身中点为 0.5；应将 UV 通过本帧 eye FOV 还原到投影切线坐标后检查中心是否为零。所选眼 eye=0/1、立体渲染流程不变。

## 接收端接口（HTTP，无证书）

服务仍运行在 VR 的 TCP 8095。鉴权请求头：Authorization: Bearer 1。既有直播 H.264 / TLZV 数据格式保持不变。

| 方法和路径 | 行为 |
|---|---|
| GET /v1/view/status | 状态、编码参数、实际取景范围与错误 |
| GET /v1/view/live.tlzv | 直接订阅带 32 字节帧头的 Annex-B H.264，HTTP chunked |
| GET /v1/view/live.h264 | 直接订阅裸 Annex-B H.264，HTTP chunked |
| PUT /v1/view/config | 调整分辨率、比例、FPS、码率、FOV、边距与所选眼 |
| POST /v1/view/live/start | 后台显式恢复直播，重复调用幂等，不需要确认 |
| POST /v1/view/live/stop | 后台显式停止 |
| POST /v1/view/keyframe | 请求关键帧 |
| /v1/view/record* | 统一返回 HTTP 410 Gone，本地录像已移除 |

默认开启指 VR 自动编码并开放现有直播订阅接口。后台通过 GET 连接获取视频，不要求先 POST start；本次没有另加未经约定的主动上传地址。

```bash
# 已进入 VR 场景即可订阅；无需先调用 start。
curl -H "Authorization: Bearer 1" http://VR_IP:8095/v1/view/status
curl -H "Authorization: Bearer 1" http://VR_IP:8095/v1/view/live.h264 --output vr-live.h264
curl -X PUT -H "Authorization: Bearer 1" -H "Content-Type: application/json" \
  --data '{"width":720,"height":1280,"vertical_fov_deg":70}' \
  http://VR_IP:8095/v1/view/config
```

新增/更新状态字段：live_policy_revision=2、live_default_on=true、live_wanted（本次会话是否允许自动恢复）、framing_center="optical_axis"、local_recording_supported=false。兼容旧接收端保留 recording=false、current_recording=null、last_file=null。自动启动时 live_started_by="automatic"；显式后台启动为 "backend"。

## 验证

- 43 项主机检查：生产配置归一、自动直播策略、菜单取消后不自动重开、后台重开、真实 HTTP 鉴权与 chunked H.264/TLZV、移除录像接口返回 410。
- 70,000 项原生取景数学断言：非对称眼 FOV、横竖比例、随机不对称边距及旧中心偏移；始终围绕光轴、范围有效、目标比例正确且无透视拉伸。
- 原有协议回归 2,964 项通过。
- Android 实机验收测试代码已改为检查默认直播编码及取消/恢复策略，不再写入 MP4。编译 APK 与测试 APK，不代表已经执行了 Quest 实机测试。
- 本轮没有安装模拟器；尚未做 Quest 实际直播画面、硬件编码和不同画幅现场验收。

## 主要源码

- vr/src/main/cpp/view_capture_math.h：光轴对称裁切。
- CaptureConfig.java：固定中心和边距对称归一。
- ViewCapture.java、LiveSessionState.java：默认直播生命周期、取消与恢复；移除 MediaMuxer 写盘。
- ViewHttpServer.java：保留直播格式，录像旧路径返回 410。
- VrUiState.java、VrHud.java、V2Activity.java：仅直播菜单，移除录像及中心偏移操作。

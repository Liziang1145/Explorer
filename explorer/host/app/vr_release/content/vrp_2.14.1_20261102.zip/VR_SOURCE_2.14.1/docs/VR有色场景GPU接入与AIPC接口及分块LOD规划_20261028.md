# VR 有色场景 GPU 接入、AIPC 资源接口与分块 LOD 规划

2026-10-28，对应探路者-控制终端 **2.8.0 / versionCode 16**。

## 1. 本次交付与接口边界

已读取 `D:\2026FPGArace\VR有色点云场景接口` 中的接入说明、解压后的 README、manifest、SHA256SUMS 和三个 bin，并运行原交付的 `validate_package.mjs` 验证。

这批数据实际是 **410,071 顶点、780,279 三角形的有色重建网格**，不是现有 TLZ CLOUD/TILE 的实时点云报文。按提供的 bin 路径完整接入，显示真实扫描表面，另提供“顶点点云”显示模式。不能将 78 万三角形放入旧的 60,000 实时点数限额后声称已完整显示。

本版本实现：

- 已把验证后的真实扫描 bin 内置，安装 APK 即可浏览，不需要工作台登录或临时下载。
- 实现与该包结构匹配的 **AIPC HTTP 静态资源拉取通道**，可从设置中的 manifest URL 读取清单、校验表和三个 bin。
- 没有将工作台的登录文件下载 URL 冒充机器人 Bearer 接口；也没有声称 AIPC 已部署了本节 URL。原资料没有给出可用的实时场景服务地址/消息格式，真实 AIPC 在线读取尚未验收。
- 原有实时点云/地图 DataChannel、输入 50 Hz、视频/遥测、手柄 box 和直播功能保留。新的扫描资产不自动覆盖生产导航地图。

## 2. 使用入口与独立浏览

设置页新增 **“实验室有色场景 / 独立浏览”**。进入后默认显示内置真实扫描的沙盘。

底栏提供：场景、沙盘、1∶1、复位、日志、退出。场景菜单可选“内置真实扫描”“从 AIPC 读取”“显示顶点点云 / 显示有色表面”。录像/后台直播仍可通过原菜单/HTTP服务使用。

- 沙盘按最大水平跨度缩至 1.5m，约 0.0841 倍；置于初次有效头显位置前方约 1.5m、地面上约 0.85m。场景展示锚点与资产本身分离。
- 1∶1 保持米制，将资产展示原点置于当前所在位置的地面参考，不拉伸高度。
- 左摇杆移动虚拟场景，方向参考头显水平朝向；沙盘速度 0.25m/s，1∶1 为 1m/s。右摇杆横向超过阈值执行 30° 分段转向，回中后才能再次触发。菜单打开时不移动。
- 复位/系统重置参考空间仅重置展示锚点，退出后不会自动进入遥操作或恢复行驶。
- 此入口不创建 BaseLink，不创建视频/遥测/机器人控制会话，也不发布 ABXY、扳机、侧键、底盘或机械臂输入。手柄只用于本地 UI 和浏览。返回设置后必须显式选择连接 AIPC 才开始原来的遥操作流程。

“从 AIPC 读取”只下载场景文件，不获取机器人控制权。

## 3. AIPC 当前可接入的静态文件服务约定（本版本已实现客户端）

设置页填写 **AIPC 有色场景清单 URL**，完整格式例如：

```text
http://<AIPC-IP>:<实际场景服务端口>/colored-scenes/lab_right_20261028/assets/manifest.json
```

此地址为部署示例，不是声称 AIPC 已存在此端口或路径。留空则不自动联网，仍可浏览内置扫描。进入场景菜单选择“从 AIPC 读取”才发起请求。

AIPC/文件发布服务需要按原始交付结构提供：

```text
colored-scenes/lab_right_20261028/
  SHA256SUMS.txt
  assets/
    manifest.json
    positions.bin
    colors.bin
    indices.bin
```

VR 相对于 manifest 所在目录读取：

| 顺序 | HTTP GET 相对路径 | 处理 |
| --- | --- | --- |
| 1 | `../SHA256SUMS.txt` | 最多 64 KiB，解析 SHA-256 与相对文件名 |
| 2 | `manifest.json` | 最多 64 KiB，校验 `assets/manifest.json` 的 SHA-256 |
| 3 | `positions.bin` | 必须正好 `vertices × 12` 字节 |
| 4 | `colors.bin` | 必须正好 `vertices × 3` 字节 |
| 5 | `indices.bin` | 必须正好 `triangles × 12` 字节 |

所有请求使用 HTTP，无 HTTPS/证书，携带当前 APP 设置的 `Authorization: Bearer <AIPC连接密钥>`，默认 `1`。AIPC 发布服务需按这套鉴权提供直接文件读取；工作台浏览器 Cookie 登录不是同一种鉴权。连接超时 3 秒、读超时 10 秒，不跟随 3xx 跳转，不向跳转目标转发凭据。

manifest URL 必须是 `http://主机[:端口]/.../manifest.json`，不包含用户信息、query 或 fragment。当前不接受 `api/v1/files/content?path=...` 这类工作台下载 URL；不要求提供工作台密码。

清单的既有字段：

```json
{
  "schema": "apex-quest-scene/1",
  "vertices": 410071,
  "triangles": 780279,
  "units": "metre",
  "source_frame": "independent_FAST_LIVO2_world",
  "bounds": [[-13.950570,-0.120455,-5.280784],[3.884858,0.849376,7.245167]],
  "source_to_display": ["保留原交付矩阵，客户端不重复应用"]
}
```

上例 matrix 项只为说明处理规则；实际发布必须使用原始有效 manifest 文件及原始 SHA256SUMS，不要把这个解释性 JSON 覆盖过去。

bin 的布局保持原交付：小端、紧密排列，无头；位置 float32 XYZ，颜色 uint8 RGB，三角形索引 uint32。文件长度与 SHA-256 均需匹配清单/校验表。发布同一版本期间不要原地修改其中一部分；新版本用新目录发布，再更新客户端清单地址，防止下载混代文件。

客户端不是以 ZIP 作为每帧消息传输，不反复经 DataChannel 发送整张网格。当前网络加载为手动整资源请求：没有实现后台轮询、增量地图更新、磁盘断点续传或网络分块 LOD 调度。

遇到 401/404/3xx、损坏数据、长度/单位/schema 不符、索引越界、内存预算超限等，明确记录错误并保留已经显示的旧场景，不显示半份损坏网格，也不偷偷使用随机演示点云。

## 4. 坐标与颜色

本次采用 **bin 备用路径**：`positions.bin` 已经是最终显示 Y-up 坐标，直接使用，**不再乘 manifest 的 source_to_display**。GLB 路径的节点变换规则没有混用到 bin 上。

- 单位米、右手 Y-up，三个分量按 bin 原值上传；不把它当成线路 FLU 再交换一次轴。
- `independent_FAST_LIVO2_world` 尚未与生产导航地图、车辆 base_link 或 Quest STAGE 做外参标定。因此新入口采用独立展示锚点，不自动把车、机械臂或导航轨迹叠到扫描里。
- 原始高度范围约 -0.12～0.85m，缺失上层结构保持缺失，不扩高或生成虚构墙面。
- 原始 RGB 字节为 sRGB；后台加载时用 256 项查表转线性 RGB，上传 float3，在线性空间进行 GPU 插值。白色 255 保持线性 1，不被过滤。
- 专用无光照顶点颜色 shader，不依赖法线或光源，不套灰色材质。
- OpenXR 使用 sRGB swapchain 时让 framebuffer 编码一次；回退 RGBA8 时由场景 shader 线性→sRGB 一次，不双重解码/编码。

## 5. GPU 渲染与本轮资源调度

```mermaid
flowchart LR
  A[内置资产 / AIPC HTTP文件] --> B[后台线程校验长度与SHA256]
  B --> C[后台native分块 / sRGB转线性]
  C --> D[最新一次待提交场景]
  D --> E[XR线程每帧最多上传2MiB]
  E --> F[每块独立VBO + uint32 EBO]
  F --> G[每眼AABB视锥裁剪]
  G --> H[GPU三角形 / 顶点点云绘制]
```

本扫描结果：

| 指标 | 实测离线结果 |
| --- | ---: |
| 来源顶点 | 410,071 |
| 完整三角形 | 780,279 |
| 空间块 | 113 |
| 块内独立顶点总数 | 433,709（边界顶点可重复） |
| GPU 顶点+索引数据 | 19,772,364 B（约19.8MB） |
| 单资源解码数据预算 | 48MiB |
| 场景 GPU 数据预算（旧+新） | 64MiB |
| GPU 每帧上传字节上限 | 2MiB |
| 桌面 GLES 完整上传 | 10 个 tick/frame |

空间块按三角形重心落入 2m 网格分组。每块 bounds 包含全部引用顶点，跨边界三角形不被裁断；法向缺失不影响 unlit 渲染。各块使用局部重映射的 **uint32** 索引，不截断原始大索引。

当前没有减面/抽点；所有三角形保留。顶点点云模式对块内独立顶点 `glDrawArrays(GL_POINTS)`，表面模式 `glDrawElements(GL_TRIANGLES, ..., GL_UNSIGNED_INT)`。分块边界重复顶点不代表原始测量点增加。

- CPU 负责一次性读取、校验、重分块和包围盒测试；GPU 负责逐眼变换、深度测试、光栅化、颜色插值。这里的 GPU 加速不意味着把网络或所有解析工作塞到 GPU。
- 两眼复用同一份静态 GPU 数据，只传不同 MVP，不逐帧重建 40 万点数组或重新上传模型。
- 每帧累计 VBO/EBO `glBufferSubData` 数据不超过 2MiB；分配/驱动调用仍可能有开销，不能把字节预算解释成保证某个毫秒时限。
- 新场景全部上传成功后才在帧边界替换旧场景；失败保留旧场景。替换/退出删除旧 VBO/EBO。64MiB 是场景缓冲数据预算，不含纹理、视频、编码器及驱动开销。
- 当前可见性筛选为 CPU AABB 视锥裁剪，绘制为 GPU GLES；没有声称实现 GPU indirect draw、compute 剔除或多精度网络加载。

## 6. 后续分块、分精度流式加载规划（尚未实装的协议草案）

未来让 **AIPC 生成块与 LOD**，VR 按视域和预算请求；不要在 Quest 上实时重建网格、TSDF 或对整图反复减面。保留当前独立 GPU 块和上传队列，改动集中在资源描述/请求与驻留管理层。

### 6.1 建议的新清单与资源分层

以下是待两端确认的新接口，不是当前已部署接口，**2.8 不会主动请求它们**：

```text
GET  /v2/colored-scenes/current
GET  /v2/colored-scenes/{scene_id}/manifest
POST /v2/colored-scenes/{scene_id}/interest
GET  /v2/colored-scenes/{scene_id}/objects/{sha256}
```

静态文件读取通道作为兼容入口保留。新清单使用单独版本 schema，不修改 apex-quest-scene/1 的含义。

```json
{
  "schema": "tlz-colored-scene/2",
  "scene_id": "lab_right",
  "epoch": "1",
  "frame": "independent_FAST_LIVO2_display_y_up",
  "units": "metre",
  "chunks": [{
    "id": "x/y/z",
    "version": "3",
    "bounds": [[0,0,0],[2,2,2]],
    "levels": [{
      "lod": 0,
      "geometric_error_m": 0.10,
      "primitive": "triangles",
      "vertices": 12000,
      "indices": 48000,
      "position_encoding": "xyz_f32_le",
      "color_encoding": "rgb8_srgb",
      "index_encoding": "u32_le",
      "bytes": 372000,
      "sha256": "64位十六进制",
      "url": "objects/<sha256>"
    }]
  }]
}
```

- epoch、version 用十进制字符串承载 u64，避免 JSON/JavaScript 精度丢失；epoch 变更废弃旧请求、旧缓存映射。
- id 标识空间块，version 标识内容更新，lod=0 约定最粗，数值增大更精细；每级有明确几何误差，不仅给一个点数。
- triangles 与 points 作为独立 primitive；不能把同一数据的三角形数量当成点数。
- 编码格式显式声明。初期沿用 float32/uint32，再协商块内 uint16 量化坐标+origin/scale；颜色空间和索引精度不可依靠猜测。
- 内容寻址 URL 不原地覆盖；每个对象可独立下载/校验/解码。后续增加 Range、ETag/If-None-Match 和磁盘 SHA 缓存，减少重下相同块。
- 对象的二进制头、压缩算法及协商字段需 AIPC/VR 联调后定版，不能把此示例视为现成二进制标准。

### 6.2 选择与优先级

- 先低精度覆盖可见区域，再细化近处、视野中心和任务相关区域；视锥外或身后降低优先级。
- 以屏幕空间误差 SSE 决定级别：`error_pixels ≈ geometric_error_m × display_scale × viewport_height / (2 × tan(vFOV/2) × distance)`。沙盘和1∶1采用同一公式，尺度必须计入。
- 加入升级/降级滞回和最小驻留时间，防止临界距离来回换级；例如升级阈值12px、降级阈值6px仅为起始调参建议。
- 同一空间块同一帧只绘制一个 LOD，父/粗块保留到新子/细块全部校验并上传成功，避免空洞、闪烁和双层面。
- interest 只传场景显示坐标下的浏览视锥/预算，不复用机器人控制指令；独立浏览没有 OPERATOR_STATE，因此不能依赖它隐式推导离线浏览相机。

### 6.3 资源、并发和降级

- 低优先级独立网络队列，初期2个并发下载、4个请求硬上限；后台解码队列有界，转头后取消过时请求，不积压过期高精度块。
- 保留每帧上传字节预算，并在实机测得 CPU/GPU 帧时间后增加上传耗时预算。大对象拆成可独立提交的块，避免一次巨型 GL 分配。
- 驻留管理按 GPU/CPU/磁盘分别计费。GPU 超预算先降级不重要区域，再淘汰视锥外块；优先保留当前可见粗层。新旧替换同时驻留的峰值也计入预算。
- 版本键至少包含 `(scene_id, epoch, chunk_id, version, lod, format)`，generation 失配的网络/解码回调不得提交，防止旧响应覆盖新地图。
- 静态几何初期用可靠 HTTP 按需获取即可；若未来动态点云使用可丢弃通道，要求块独立解码、短 TTL、序号和丢包恢复，不能把不完整三角索引直接画出来。
- 网络拥塞、GPU预算不足时先保持粗层/最后有效内容，减少场景请求；不得占用控制信号线程，也不靠降低头显追踪/UI刷新率减负。

### 6.4 建议分期

1. 本版本：真实整资源接入、113个GPU块、裁剪、预算上传和完整性检查（已完成）。
2. AIPC 提供上述分块清单、稳定 frame/epoch/version、粗细两档不可变对象；VR 增加内容缓存、按需拉取、LRU 驻留和原子块级替换。
3. 增加 SSE 多级选择、可见父子覆盖、请求取消/优先级和相机预测；再根据实测考虑 GPU 剔除或固定注视点渲染。

没有给原始单分辨率数据凭空编造多精度层；细节应由 AIPC 的真实重建结果生成。

## 7. 诊断、测试与现场验收

ADB 快照 `v2-diagnostics.json` 新增 `scene_browser`、`colored_scene_status`、`colored_scene_error`、`colored_scene_stats`。

stats 顺序：`[resident_chunks, triangles, source_vertices, resident_gpu_bytes, uploaded_bytes, upload_total_bytes, last_eye_visible_chunks, error_code]`。error=1 场景GPU预算不足，2 GL分配/上传错误。visible 是最后一次绘制眼的可见块数量，不是全帧双眼总和。

日志：`TLZ.SCENE` 的 `ASSET_STAGED` / `LOAD_FAILED`，以及原生 `TLZ2 / COLORED_SCENE staged ...`。loader 的 HTTP/校验失败与 native 上传失败分开显示，旧场景保留。

已完成：

- 原交付 Node 校验：13项文件哈希、GLB/bin 索引一致，位置最大差约4.77e-7m，线性颜色最大差约2.57e-8。
- 生产 native 解码器检查全部三角形和颜色的顺序无关哈希，验证未丢面、未截断uint32索引、显示坐标未重复变换、bounds及裁剪。
- 真正的桌面 ANGLE EGL/GLES 执行生产 Gpu 类和生产场景 shader：10帧预算上传、表面/点模式绘制、原子替换和 VBO/EBO 释放检查通过。
- 生产 Java loader 用本地资产、真实 HTTP Socket 和鉴权请求检查 manifest/校验表/三个缓冲，验证损坏颜色、3xx不跟随及缺少地址错误。Android Context/JSON/JNI 在该 host 测试中为适配器，不代表在 Quest 执行过。
- 原有契约/直播/UI测试、视频纹理与玻璃/录像共享纹理检查通过，Android 主 APK 和实机测试 APK 可编译。

复现命令位于源码 `interaction-end/tools`：`test_colored_scene.py`、`test_colored_scene_gpu.py`、`test_colored_scene_http.py`、`test_v2_contract.py`、`preview_vr_hud.py`、`check_vr_environment.py`。

本轮 ADB 未检测到 Quest，只发现非 Quest 设备；没有安装到手机或模拟器。尚需 Quest 上测沙盘/1∶1持握比例、颜色、GPU帧时间P50/P95、掉帧、首次加载时间、内存峰值及多次进退；AIPC 发布实际 URL 后再做在线资源读取验收。桌面截图不替代头显帧率测试。

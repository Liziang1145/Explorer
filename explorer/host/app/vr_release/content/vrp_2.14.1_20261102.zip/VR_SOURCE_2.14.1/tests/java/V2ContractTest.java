import com.tanluzhe.controlterminal.vr.v2.*;
import java.nio.*;
import java.security.*;
import java.util.*;

public final class V2ContractTest {
  static int checks;
  static void require(boolean b, String message) {
    checks++;
    if (!b)
      throw new AssertionError(message);
  }
  static void rejects(Runnable r) {
    boolean rejected = false;
    try {
      r.run();
    } catch (RuntimeException e) {
      rejected = true;
    }
    require(rejected, "Malformed input was accepted");
  }
  static float[] identity() {
    return new float[] {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
  }
  static Packet packet() {
    Packet p = new Packet();
    p.session = 1;
    p.seq = 1;
    p.time = 100;
    p.type = Packet.CONTROL;
    p.ttlMs = 60;
    p.body = Cbor.map(0, 1, 1, 63, 2, 205, 3, 1, 4, 1, 5, 1, 6, 1, 7,
        Cbor.map(0, 1, 1, new float[] {1, 2, 3}, 2, new float[] {0, 0, 0, 1}), 9,
        Cbor.map(0, 2, 1, new float[] {.1f, .2f, .3f}, 2, new float[] {0, 0, 0, 1}), 11,
        new float[] {1, 2, 3, 4, 5, 6}, 12, new float[] {6, 5, 4, 3, 2, 1}, 13,
        Cbor.map(0, 0, 1, .25f), 14, Cbor.map(0, 0, 1, .75f), 15, 31, 16, 1, 18, 110);
    return p;
  }
  static byte[] points(int count) {
    ByteBuffer b = ByteBuffer.allocate(count * 10).order(ByteOrder.LITTLE_ENDIAN);
    for (int i = 0; i < count; i++)
      b.putShort((short) 100)
          .putShort((short) 200)
          .putShort((short) 300)
          .put((byte) 255)
          .put((byte) 128)
          .put((byte) 0)
          .put((byte) 255);
    return b.array();
  }
  static Packet tile(byte[] all, int index, int count, byte[] part) throws Exception {
    Packet p = new Packet();
    p.type = Packet.TILE;
    p.body = Cbor.map(2, 1, 3, 1, 4, index, 5, count, 6, part.length / 10, 7, 1, 8,
        new float[] {0, 0, 0}, 9, .01f, 10, 0, 11, part.length, 12, part, 20, 1, 21,
        Arrays.asList(0L, 0L, 0L), 22, 1, 23, 0, 24, all.length, 25,
        MessageDigest.getInstance("SHA-256").digest(all), 26, 0);
    return p;
  }
  public static void main(String[] args) throws Exception {
    long now=10_000_000_000L;
    Telemetry.Arm unknown=Telemetry.Arm.unknown();
    SpeedDisplay speed=new SpeedDisplay();
    require(speed.update(new Telemetry(now,"base","控车","",false,0,0,0,unknown,unknown),now,false)==1,"Zero speed initially visible");
    long five=now+5_000_000_000L;
    require(speed.update(new Telemetry(five,"base","控车","",false,0,0,0,unknown,unknown),five,false)==1,"Repeated zero samples preserve five second hold");
    long fade=five+325_000_000L;
    require(Math.abs(speed.update(new Telemetry(fade,"base","控车","",false,0,0,0,unknown,unknown),fade,false)-.5)<.001,"Zero speed fades after five seconds");
    long end=five+650_000_000L;
    require(speed.update(new Telemetry(end,"base","控车","",false,0,0,0,unknown,unknown),end,false)==0,"Zero speed hidden after fade");
    require(speed.update(new Telemetry(end,"base","控车","",false,.3,.4,0,unknown,unknown),end,false)==1&&Math.abs(speed.value-.5)<.0001,"Planar speed resumes immediately");
    require(speed.update(new Telemetry(end,"arms","双臂","",false,.3,.4,0,unknown,unknown),end,false)==0,"Arm mode hides speed");
    require(speed.update(Telemetry.unknown(),end,false)==0,"Stale speed never shown as live");
    float[] baseL=ArmGeometry.position(0,new float[]{0,0,0}),baseR=ArmGeometry.position(1,new float[]{0,0,0});
    require(Math.abs(baseL[0]+.155)<.00001&&Math.abs(baseR[0]-.155)<.00001,"Arm bases fixed to correct sides");
    float[] tip=ArmGeometry.position(0,new float[]{10,20,30});
    require(Math.abs(tip[0]+.055)<.00001&&Math.abs(tip[1]-.640)<.00001&&Math.abs(tip[2]+.385)<.00001,"B-frame cm transformed into OpenXR metres");
    float[][] joints={{0,0,0},{0,0,10},{0,0,10},{0,10,20},{0,20,20},{0,20,20},{0,30,20}};
    Telemetry.Arm arm=new Telemetry.Arm("following","feedback","",joints,new float[]{0,0,0,1},.5f);
    ArmGeometry geometry=new ArmGeometry();
    float[] line=geometry.sample(new Telemetry(now,"arms","双臂","",false,0,0,0,arm,unknown),now);
    require(line.length==140,"Four nondegenerate arm segments and six parallel gripper segments");
    require(Math.abs(geometry.labels[3]-.5)<.00001&&geometry.labels[7]==-2,"Gripper opening labelled only for valid arm");
    require(geometry.sample(Telemetry.unknown(),now).length==0,"Invalid or stale arm geometry hidden");
    VrUiState scroll=new VrUiState();scroll.presentation(VrUiState.LOGS);scroll.logLines=new String[100];scroll.logLoaded=100;
    scroll.navigate(1,now);for(int i=1;i<50;i++)scroll.navigate(1,now+i*100_000_000L);
    require(scroll.logScroll>70&&scroll.logWanted==200,"Thumbstick scroll loads older log history");
    require(scroll.mapVisible,"Minimap starts visible");scroll.presentation(VrUiState.MAP);require(!scroll.mapVisible,"Map action switches minimap");
    Packet original = packet();
    byte[] encoded = original.encode();
    Packet decoded = Packet.decode(encoded);
    require(
        encoded.length <= 1100 && ByteBuffer.wrap(encoded).getInt() == 0x544c5a32, "Header/MTU");
    require(
        decoded.body.containsKey(11L) && decoded.body.containsKey(12L), "Joint targets retained");
    for (int n = 0; n < 64; n++) {
      byte[] shortPacket = Arrays.copyOf(encoded, n);
      rejects(() -> Packet.decode(shortPacket));
    }
    byte[] bad = encoded.clone();
    bad[10] = 1;
    rejects(() -> Packet.decode(bad));
    rejects(() -> Cbor.decode(new byte[] {(byte) 0xa2, 0, 1, 0, 2}));
    rejects(() -> Cbor.decode(new byte[] {(byte) 0x9f, 1, (byte) 0xff}));
    rejects(() -> Cbor.encode(Float.NaN));
    rejects(() -> Cbor.decode(new byte[] {0x61, (byte) 0xff}));
    rejects(() -> Cbor.map(0, 1, 0, 2));
    rejects(() -> Cbor.decode(new byte[] {(byte) 0xfa, 0x7f, (byte) 0x80, 0, 0}));
    Object max = Cbor.decode(new byte[] {0x1b, -1, -1, -1, -1, -1, -1, -1, -1});
    require(max.toString().equals("18446744073709551615"), "u64 full width");
    require(Arrays.equals(Cbor.encode(max), new byte[] {0x1b, -1, -1, -1, -1, -1, -1, -1, -1}),
        "u64 roundtrip");
    ClockSync c = new ClockSync();
    ClockSync.Mapping m =
        c.sample(2, 1, 1_000_000_000L, 1_009_000_000L, 1_010_000_000L, 1_011_000_000L);
    require(m.base(1_000_000_000L) == 1_004_000_000L, "Four timestamp offset");
    require(m.uncertainty >= 5_000_000L, "RTT uncertainty not disguised");
    require(c.sample(2, 1, 10, 9, 8, 11) == null, "Invalid clock order");
    c.install(m);
    ClockSync.Mapping base = new ClockSync.Mapping();
    base.node = 1;
    base.epoch = 1;
    base.refLocal = 0;
    base.refBase = 0;
    base.updatedBase = 1_010_000_000L;
    c.install(base);
    require(c.controlReady(1, 2, 1_020_000_000L), "Confirmed clock readiness");
    require(Double.isNaN(c.ageMs(2, 9, 1_000_000_000L, 2, 1_020_000_000L)),
        "Unknown epoch unavailable");
    ControlGate g = new ControlGate();
    g.connected = g.foreground = g.tracking = g.clockConfirmed = g.robotReady = true;
    g.lease = 7;
    g.allowedMask = 63;
    g.leaseExpiryBase = 200;
    require(!g.arm(100), "Stop latch holds");
    g.stopLatched = false;
    require(g.arm(100), "Explicit arm succeeds");
    require(!g.allow(201), "Lease expiry disarms");
    g.reset();
    require(!g.armed && g.lease == 0, "Reconnect cannot restore motion");
    SceneStore scene = new SceneStore();
    scene.transform(1, identity());
    scene.selectEpoch(1);
    byte[] all = points(4);
    Packet a = tile(all, 0, 2, Arrays.copyOfRange(all, 0, 20)),
           b = tile(all, 1, 2, Arrays.copyOfRange(all, 20, 40));
    scene.accept(a, 0);
    require(scene.vertices().length == 0, "Partial map not published");
    scene.accept(b, 1);
    float[] xyz = scene.vertices();
    require(xyz.length == 28 && Math.abs(xyz[0] + 2) < .001 && Math.abs(xyz[1] - 3) < .001
            && Math.abs(xyz[2] + 1) < .001,
        "Complete map FLU->XR and precision");
    Packet corrupt = tile(all, 0, 1, points(4));
    corrupt.body.put(22L, 2L);
    ((byte[]) corrupt.body.get(12L))[0] = 3;
    scene.accept(corrupt, 2);
    require(scene.vertices().length == 28 && scene.rejected > 0, "Hash corruption keeps old map");
    Packet oldEpoch = tile(all, 0, 1, all);
    oldEpoch.body.put(20L, 999L);
    scene.accept(oldEpoch, 3);
    require(scene.vertices().length == 28, "Unauthorized map epoch not applied");
    Packet del = tile(new byte[0], 0, 1, new byte[0]);
    del.body.put(22L, 3L);
    del.body.put(26L, 1L);
    scene.accept(del, 4);
    require(scene.vertices().length == 0, "Reliable tombstone deletes");
    Packet cloud = tile(points(1), 0, 1, points(1));
    cloud.type = Packet.CLOUD;
    cloud.body.put(0L, 1L);
    cloud.body.put(1L, 1L);
    scene.accept(cloud, 10);
    require(scene.vertices().length == 7, "Live block independent");
    scene.expire(151_000_011L);
    require(scene.vertices().length == 0, "Stale live points removed");
    float[] poses = {1, 1, 1, 0, 0, 0, 1, 2, 3, 4, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1};
    float[] rel = Math3.relative(poses, 7);
    require(rel[0] == 1 && rel[1] == 2 && rel[2] == 3, "Hand relative pose");
    Dashboard status = new Dashboard();
    require(status.lines(100, false).contains("N/A"), "No fake zero latency");
    LossWindow loss = new LossWindow();
    Packet tracking = packet();
    tracking.seq = 1;
    loss.receive(tracking, 0);
    tracking.seq = 3;
    loss.receive(tracking, 1);
    tracking.seq = 2;
    loss.receive(tracking, 100_000_000L);
    loss.receive(tracking, 110_000_000L);
    tracking.seq = 5;
    loss.receive(tracking, 200_000_000L);
    loss.expire(500_000_000L);
    long[] counts = loss.snapshot();
    require(counts[0] == 4 && counts[1] == 1 && counts[2] == 1 && counts[3] == 1,
        "Reorder grace and duplicates");
    RttHistory history = new RttHistory();
    history.add(1, 100);
    history.add(2, 101);
    history.add(8, 102);
    float[] percentile = history.summary(103);
    require(
        percentile[0] == 2 && percentile[1] == 8 && percentile[2] == 8, "Measured RTT percentiles");
    require(history.summary(11_000_000_103L) == null, "RTT samples expire");
    ClockSync.Mapping camera = new ClockSync.Mapping();
    camera.node = 3;
    camera.epoch = 1;
    camera.refBase = 8_000_000L;
    camera.updatedBase = 1_010_000_000L;
    camera.uncertainty = 1_000_000L;
    c.install(camera);
    VideoTiming video = new VideoTiming(c, status);
    video.localNode(2);
    Packet meta = new Packet();
    meta.body = Cbor.map(1, 1, 3, 3, 4, 1_010_000_000L, 5, 1, 6, 0, 9, 12, 10, 90000);
    video.metadata(meta);
    video.submitted(1_000_000_000L, 1_020_000_000L);
    require(
        Math.abs(status.videoAge - 6) < .001, "Video source capture age uses both clock mappings");
    require(!video.acceptDecoded(1_000_000_000L, 1_500_000_000L),
        "Obsolete video output rejected without breaking decoder references");
    video.submitted(1_001_000_000L, 1_020_000_000L);
    require(Double.isNaN(status.videoAge), "Unmatched video is N/A");
    RobotScene robot = new RobotScene(scene);
    robot.baseFrameId = 2;
    Packet feedback = new Packet();
    feedback.body = Cbor.map(3,
        Cbor.map(0, 100, 1, 1, 2, true, 3,
            Cbor.map(0, 1, 1, new float[] {1, 2, 3}, 2, new float[] {0, 0, 0, 1}), 4, 3, 5, 1),
        5, Cbor.map(0, 100, 1, 1, 2, true, 3, new float[] {1, 2, 3, 4, 5, 6}, 4, 3, 5, 1));
    robot.state(feedback, 100);
    require(robot.leftJoints.length == 6 && robot.actualBasePosition[0] == 1,
        "Joint and pose feedback both preserved");
    require(robot.lines(101).length == 24 * 7, "Measured robot geometry");
    require(robot.lines(300_000_101L).length == 0, "Stale geometry not presented as live");
    float[] display=robot.displayBase(101);
    require(display!=null && display[0]==-2 && display[1]==3 && display[2]==-1,"Vehicle FLU converted to display coordinates");
    require(robot.displayBase(300_000_101L)==null,"Stale feedback cannot update display rig");
    float[] parent={0,1,0,0,-1,0,0,0,0,0,1,0,10,20,30,1};
    scene.transform(robot.actualBaseFrame,parent);
    display=robot.displayBase(101);
    require(display!=null && Math.abs(display[0]+21)<1e-5 && Math.abs(display[1]-33)<1e-5 && Math.abs(display[2]+8)<1e-5,"Display base honors parent-frame rotation and translation");
    require(Math.abs(display[3]-Math.PI/2)<1e-5,"Vehicle yaw includes parent-frame rotation");
    VrUiState vr = new VrUiState();
    require(!vr.followView,"Observer is default");
    vr.presentation(VrUiState.VIEW);
    require(vr.followView && vr.hit(870f/1600,934f/1000)==VrUiState.VIEW,"Follow switch is reachable on dock");
    vr.presentation(VrUiState.VIEW);
    require(!vr.followView,"Observer switch round-trip");
    require(vr.videoMode == 2 && vr.mapVisible, "VR default large vehicle-anchored video and visible map");
    vr.presentation(VrUiState.VIDEO_OFF);
    require(vr.videoMode == 0, "VR video off");
    vr.presentation(VrUiState.VIDEO_LARGE);
    require(vr.videoRect().w == 960, "VR large video geometry");
    vr.presentation(VrUiState.VIDEO_SMALL);
    require(vr.videoRect().x == 450, "VR standard video remains vehicle centered");
    float[] pointer = {-1, -1, 720f / 1600, 934f / 1000, 0, 0, 0, 0};
    require(vr.pointerAction(pointer, true) == 0, "Focus starts without a synthetic click");
    pointer[5] = .9f;
    require(vr.pointerAction(pointer, true) == VrUiState.MENU, "Right aim trigger hits menu");
    require(vr.pointerAction(pointer, true) == 0, "Held trigger does not repeat UI action");
    vr.demoArmed = true;
    vr.demoSynced = true;
    vr.presentation(VrUiState.MENU);
    require(vr.menuOpen && !vr.demoArmed && !vr.demoSynced && vr.blocksControl(),
        "Menu revokes demo arming/reference and blocks control");
    require(vr.hit(720f / 1600, 934f / 1000) == 0, "Modal menu blocks underlying buttons");
    require(vr.hit(950f / 1600, 575f / 1000) == VrUiState.EXIT, "Modal exit has a separate target");
    pointer[2] = 950f / 1600;
    pointer[3] = 575f / 1000;
    require(vr.pointerAction(pointer, false) == 0 && vr.pointerAction(pointer, true) == 0,
        "Focus regain while trigger held cannot confirm exit");
    require(vr.buttonEdges(2, false) == 0 && vr.buttonEdges(2, true) == 0,
        "Focus regain while X held cannot arm or exit");
    vr.buttonEdges(0, true);
    require(vr.buttonEdges(2, true) == 2, "Fresh X edge detected");
    for (int face = 0; face < 16; face++) {
      require(vr.localButtonAction(face) == 0, "ABXY combinations never operate local UI or exit");
      require(vr.localButtonAction(face | 16) == VrUiState.MENU, "Dedicated menu remains reachable");
    }
    require(vr.hit(Float.NaN, .5f) == 0 && vr.hit(-1, -1) == 0, "Invalid/outside ray cannot click");
    InputControls controlsAll =
        new InputControls(63, 1, 1, .25f, .75f, new float[] {0, 0}, new float[] {.5f, -.5f});
    Map<Long, Object> raw = controlsAll.cbor();
    require(raw.size() == 8 && Cbor.number(raw, 0, 0) == 1 && Cbor.number(raw, 7, 0) == 63,
        "Key11 revision, full valid mask and exactly six controls");
    require(raw.get(1L) instanceof Float && raw.get(3L).equals(.25f),
        "Raw pressures are float32 without gripper inversion");
    InputControls missing = InputControls.invalid();
    require(missing.cbor().size() == 2 && !missing.cbor().containsKey(1L),
        "Missing controls omitted, never zero-filled");
    require(new InputControls(1, 0, 0, 0, 0, new float[2], new float[2]).cbor().get(1L).equals(0f),
        "Valid released grip carries real zero");
    require(
        new InputControls(63, Float.NaN, 1, .2f, .3f, new float[] {2, 0}, new float[2]).valid == 46,
        "Bad values clear only affected source validity");
    InputMode modes = new InputMode(.95f, .90f, .10f);
    require(modes.update(controlsAll, true, 7, false) == InputMode.Mode.IDLE,
        "Starting with both grips held cannot enter arms");
    InputControls neutral = new InputControls(63, 0, 0, 0, 0, new float[2], new float[2]);
    modes.update(neutral, true, 7, false);
    require(modes.update(new InputControls(63, .94f, 0, 0, 0, new float[] {.5f, 0}, new float[2]),
                true, 7, false)
            == InputMode.Mode.IDLE,
        "Near-full is not full press");
    require(modes.update(new InputControls(63, .96f, 0, 0, 0, new float[] {.5f, 0}, new float[2]),
                true, 7, false)
            == InputMode.Mode.VEHICLE_LEFT,
        "Left full grip selects left vehicle input");
    require(modes.update(new InputControls(63, .92f, 0, 0, 0, new float[] {.5f, 0}, new float[2]),
                true, 7, false)
            == InputMode.Mode.VEHICLE_LEFT,
        "Grip hysteresis retains selected mode");
    require(modes.update(controlsAll, true, 7, false) == InputMode.Mode.ARMS,
        "Both full grips select arms only");
    require(modes.update(new InputControls(63, 1, 0, 0, 0, new float[] {.5f, 0}, new float[2]),
                true, 7, false)
                == InputMode.Mode.IDLE
            && modes.releaseRequired,
        "Arms release cannot immediately drive vehicle");
    require(modes.update(new InputControls(63, 0, 0, 0, 0, new float[] {.5f, 0}, new float[2]),
                true, 7, false)
                == InputMode.Mode.IDLE
            && modes.releaseRequired,
        "Reentry requires both sticks centered");
    modes.update(neutral, true, 7, false);
    require(modes.update(new InputControls(63, 0, 1, 0, 0, new float[2], new float[] {.5f, 0}),
                true, 7, false)
            == InputMode.Mode.VEHICLE_RIGHT,
        "Right full grip selects right vehicle input");
    require(
        modes.update(controlsAll, false, 7, false) == InputMode.Mode.IDLE && modes.releaseRequired,
        "Focus loss clears preview intent");
    require(modes.update(controlsAll, true, 7, true) == InputMode.Mode.IDLE,
        "UI blocks local motion preview");
    require(modes.axis(.1f) == 0 && Math.abs(modes.axis(.55f) - .5f) < .0001,
        "Preview deadzone is continuous, raw wire value untouched");
    OperatorState.Sample sample = new OperatorState.Sample();
    sample.time = 1000;
    sample.flags = 7;
    sample.controls = controlsAll;
    sample.poses = new float[21];
    sample.poses[6] = sample.poses[13] = sample.poses[20] = 1;
    sample.eyes = new float[22];
    sample.eyes[6] = sample.eyes[17] = 1;
    Map<Long, Object> body = OperatorState.body(sample, 2000, true, 0, 0, 1);
    require(body.containsKey(11L) && body.containsKey(3L) && body.containsKey(4L)
            && body.containsKey(5L),
        "Unarmed observation contains key11 and existing poses");
    Packet op = packet();
    op.type = Packet.OPERATOR;
    op.stream = 102;
    op.time = sample.time;
    op.body = body;
    byte[] opBytes = op.encode();
    for(int valid=0;valid<16;valid++)for(int pressed=0;pressed<16;pressed++){
      if((pressed&~valid)!=0)continue;
      FaceButtons face=new FaceButtons(valid,pressed);
      Map<Long,Object> source=new HashMap<>(body);source.put(13L,face.cbor());
      Map<Long,Object> packedFace=OperatorCompact.pack(source,"opbin1");
      require(Cbor.object(packedFace.get(13L)).equals(face.cbor()),"OPC1 keeps key13 outside blob");
      require(Cbor.object(OperatorCompact.expand(packedFace).get(13L)).equals(face.cbor()),"OPC1 expansion preserves ABXY");
    }
    float[] nativePointer={-1,-1,-1,-1,0,0,0,0,63,15};
    require(FaceButtons.nativeSample(1|8,nativePointer,true).pressed==9,"A+Y wire mapping");
    require(FaceButtons.nativeSample(2,nativePointer,true).pressed==4,"Local X maps to wire bit2");
    require(FaceButtons.nativeSample(4,nativePointer,true).pressed==2,"Local B maps to wire bit1");
    require(FaceButtons.nativeSample(15,nativePointer,false).valid==0,"Focus loss invalidates ABXY");
    Map<Long,Object> staleFace=OperatorState.body(sample,sample.time+101_000_000L,true,0,0,1);
    require(Cbor.number(Cbor.object(staleFace.get(13L)),1,15)==0,"Stale button state is not released-valid");
    boolean illegalFace=false;try{new FaceButtons(1,2);}catch(IllegalArgumentException e){illegalFace=true;}
    require(illegalFace,"Reject pressed outside valid");
    for(VrUiState.Rect rect:VrUiState.DIALOG)require(rect.id<8||rect.id>11,"Removed lease/sync/arm/stop menu items");
    require(opBytes.length <= 1100, "Full operator state with stereo views stays within1100 bytes");
    require(Cbor.number(Cbor.object(Packet.decode(opBytes).body.get(11L)), 7, 0) == 63,
        "Operator key11 survives strict codec roundtrip");
    Map<Long, Object> stale = OperatorState.body(sample, 200_000_000L, true, 0, 0, 1);
    require(Cbor.number(Cbor.object(stale.get(11L)), 7, 1) == 0 && !stale.containsKey(3L),
        "Stale sampling clears controls and poses");
    Map<Long, Object> background = OperatorState.body(sample, 2000, false, 0, 0, 1);
    require(Cbor.number(Cbor.object(background.get(11L)), 7, 1) == 0 && !background.containsKey(4L),
        "Background observation invalidates controlsAll sources");
    require(
        new ObservationRate(50).periodNs == 20_000_000L, "Independent50Hz observation schedule");
    vr.presentation(VrUiState.LOGS);
    require(vr.logsOpen && vr.hit(400f / 1600, 760f / 1000) == VrUiState.LOG_REFRESH,
        "Scrolling log dialog has accessible controls");
    vr.presentation(VrUiState.RESUME);
    require(!vr.logsOpen && vr.menuOpen, "Back from logs returns to menu");
    vr.presentation(VrUiState.VIDEO_PANEL);
    require(vr.videoPanel && vr.hit(800f / 1600, 450f / 1000) == VrUiState.VIDEO_SMALL,
        "Large video choices are independently hittable");
    Map<Long, Object> packed = OperatorCompact.pack(body, "opbin1");
    Map<Long, Object> expanded = OperatorCompact.expand(packed);
    require(!packed.containsKey(11L) && packed.containsKey(12L) && expanded.containsKey(11L),
        "Lossless compact envelope roundtrip");
    require(Arrays.equals(Cbor.floats(Cbor.object(expanded.get(4L)).get(1L), 3),
                Cbor.floats(Cbor.object(body.get(4L)).get(1L), 3)),
        "Lossless pose values preserved");
    for (int mask = 0; mask < 64; mask++) {
      sample.controls = new InputControls(
          mask, 0f, .95f, .25f, .75f, new float[] {-.1f, .1f}, new float[] {.5f, -.5f});
      Map<Long, Object> src = OperatorState.body(sample, 2000, true, 0, 0, 1);
      Map<Long, Object> round = OperatorCompact.expand(OperatorCompact.pack(src, "opbin1"));
      require(Cbor.number(Cbor.object(round.get(11L)), 7, -1) == mask,
          "Every control validity combination survives compact codec");
      require(Cbor.object(round.get(11L)).keySet().equals(Cbor.object(src.get(11L)).keySet()),
          "Absent controls remain absent");
      if ((mask & 2) != 0)
        require(Float.floatToRawIntBits((Float) Cbor.object(round.get(11L)).get(2L))
                == Float.floatToRawIntBits(.95f),
            "Critical grip threshold pressure remains bit-exact");
    }
    byte[] malformed = ((byte[]) packed.get(12L)).clone();
    malformed[3] = 9;
    Map<Long, Object> broken = new LinkedHashMap<>(packed);
    broken.put(12L, malformed);
    rejects(() -> OperatorCompact.expand(broken));
    Map<Long, Object> truncated = new LinkedHashMap<>(packed);
    truncated.put(12L, Arrays.copyOf((byte[]) packed.get(12L), 20));
    rejects(() -> OperatorCompact.expand(truncated));
    Map<Long, Object> mixed = new LinkedHashMap<>(packed);
    mixed.put(3L, body.get(3L));
    rejects(() -> OperatorCompact.expand(mixed));
    Map<Long, Object> tiny = Cbor.map(0, 0, 1, 0, 2, 0, 11, Cbor.map(0, 1, 7, 0));
    require(OperatorCompact.choose(tiny, "opbin1") == tiny, "Do not increase tiny snapshot size");
    sample.controls = controlsAll;
    sample.poses[7] = .1234567f;
    sample.poses[8] = -.7654321f;
    Map<Long, Object> quantSrc = OperatorState.body(sample, 2000, true, 0, 0, 1);
    Map<Long, Object> quant = OperatorCompact.expand(OperatorCompact.pack(quantSrc, "opq1"));
    float[] quantPos = Cbor.floats(Cbor.object(quant.get(4L)).get(1L), 3),
            sourcePos = Cbor.floats(Cbor.object(quantSrc.get(4L)).get(1L), 3);
    for (int k = 0; k < 3; k++)
      require(Math.abs(quantPos[k] - sourcePos[k]) <= .000051,
          "Quantized position error within specified unit bound");
    require(Cbor.object(quant.get(11L)).get(3L).equals(.25f),
        "Quantization never changes raw trigger pressures");
    Map<Long, Object> unusual = new LinkedHashMap<>(body);
    unusual.put(12L, new byte[0]);
    require(OperatorCompact.choose(unusual, "opbin1") == unusual,
        "Unknown compact extension collision falls back without dropping data");
    // Compare geometry against an independent native-space quaternion sandwich.
    float[] bounds={-.02f,-.03f,-.07f,.04f,.05f,.08f,0,
                     -.025f,-.04f,-.08f,.03f,.06f,.07f,1};
    sample.controllerBounds=bounds;
    Random geometryRandom=new Random(2700);
    for(int iteration=0;iteration<40;iteration++){
      for(int side=0;side<2;side++){
        int off=7+side*7;
        for(int k=0;k<3;k++)sample.poses[off+k]=geometryRandom.nextFloat()*4-2;
        float qnorm=0;
        for(int k=3;k<7;k++){sample.poses[off+k]=geometryRandom.nextFloat()*2-1;qnorm+=sample.poses[off+k]*sample.poses[off+k];}
        for(int k=3;k<7;k++)sample.poses[off+k]/=(float)Math.sqrt(qnorm);
      }
      Map<Long,Object> full=OperatorState.body(sample,2000,true,0,0,1);
      Map<Long,Object> boxes=Cbor.object(full.get(14L));
      require(Cbor.number(boxes,0,0)==1,"Geometry extension revision");
      for(int side=0;side<2;side++){
        Map<Long,Object> box=Cbor.object(boxes.get((long)side+1));
        require(Cbor.number(box,0,0)==side+4,"Box references original grip orientation, no duplicate quaternion");
        require(Cbor.number(box,1,-1)==side,"Geometry source survives snapshot");
        float[] actual=Cbor.floats(box.get(3L),24);
        int off=7+side*7,boff=side*7;
        float[] q=Arrays.copyOfRange(sample.poses,off+3,off+7),inv={-q[0],-q[1],-q[2],q[3]};
        for(int corner=0;corner<8;corner++){
          // Wire bits X/Y/Z correspond to native -Z/-X/+Y, including sign flips.
          float[] local={bounds[boff+((corner&2)==0?3:0)],bounds[boff+((corner&4)==0?1:4)],
                         bounds[boff+((corner&1)==0?5:2)],0};
          float[] r=Math3.mul(Math3.mul(q,local),inv);
          float[] expected={-sample.poses[off+2]-r[2],-sample.poses[off]-r[0],sample.poses[off+1]+r[1]};
          for(int k=0;k<3;k++)require(Math.abs(expected[k]-actual[corner*3+k])<.000003,"Rotated/translated box corner shares tracking frame");
        }
      }
      op.body=full;require(op.encode().length<=1100,"Full geometry + stereo snapshot fits transport MTU");
      if(iteration==0){
        Map<Long,Object> maxBody=OperatorState.body(sample,2000,true,-1L,Long.MAX_VALUE,Integer.MAX_VALUE);
        op.body=maxBody;int largest=op.encode().length;
        require(largest<=1100,"Maximum IDs with geometry and stereo fit MTU");
        op.body=OperatorCompact.pack(maxBody,"opbin1");require(op.encode().length<=1100,"Maximum IDs compact geometry fit MTU");
        System.out.println("OPERATOR_STATE geometry sample="+Cbor.encode(full).length+" payload bytes; maximum tested IDs="+largest+" total bytes");
      }
      for(String profile:new String[]{"opbin1","opq1"}){
        Map<Long,Object> packedGeometry=OperatorCompact.pack(full,profile);
        require(packedGeometry.containsKey(14L),"Geometry remains outside OPC1 blob");
        require(Arrays.equals(Cbor.encode(full.get(14L)),Cbor.encode(OperatorCompact.expand(packedGeometry).get(14L))),"Codec preserves all geometry bytes");
        op.body=packedGeometry;require(op.encode().length<=1100,"Compressed geometry snapshot fits MTU");
      }
    }
    require(!OperatorState.body(sample,200_000_000L,true,0,0,1).containsKey(14L),"Stale geometry is absent");
    require(!OperatorState.body(sample,2000,false,0,0,1).containsKey(14L),"Background geometry is absent");
    sample.flags=2;
    Map<Long,Object> leftOnly=Cbor.object(OperatorState.body(sample,2000,true,0,0,1).get(14L));
    require(leftOnly.containsKey(1L)&&!leftOnly.containsKey(2L),"Lost hand never persists in a new snapshot");
    sample.flags=7;bounds[6]=-1;bounds[13]=-1;
    require(!OperatorState.body(sample,2000,true,0,0,1).containsKey(14L),"Unfocused native hand cannot generate a visible box");
    bounds[6]=0;bounds[0]=Float.NaN;
    require(!OperatorState.body(sample,2000,true,0,0,1).containsKey(14L),"Malformed bounds do not create invalid wire floats");
    LiveSessionState livePolicy=new LiveSessionState();
    require(!livePolicy.snapshot().active&&livePolicy.snapshot().revision==0,"Live is off initially");
    livePolicy.startRemote();
    require(livePolicy.snapshot().active&&livePolicy.snapshot().startedBy.equals("backend"),"Backend starts immediately without UI consent");
    long liveRevision=livePolicy.snapshot().revision;livePolicy.startRemote();
    require(livePolicy.snapshot().revision==liveRevision,"Repeated start on active stream is idempotent");
    livePolicy.stop("vr_menu");
    require(!livePolicy.snapshot().active&&livePolicy.snapshot().stopReason.equals("vr_menu"),"Menu cancellation is visible to backend");
    liveRevision=livePolicy.snapshot().revision;livePolicy.stop("backend");livePolicy.stop("app_paused");
    require(livePolicy.snapshot().revision==liveRevision&&livePolicy.snapshot().stopReason.equals("vr_menu"),"Cleanup does not overwrite prior local cancellation");
    livePolicy.startRemote();
    require(livePolicy.snapshot().active&&livePolicy.snapshot().stopReason.isEmpty(),"Only an explicit new backend start restarts cancelled live");
    livePolicy.stop("encoder_error");
    require(!livePolicy.snapshot().active&&livePolicy.snapshot().stopReason.equals("encoder_error"),"Encoder failure stops live state");
    VrUiState viewer=new VrUiState();viewer.sceneBrowser=true;
    require(viewer.buttons()==VrUiState.TOOLBAR,"Legacy standalone flag cannot replace normal VR toolbar");
    viewer.sceneCatalogIds=new String[]{"scene-a","scene-b","scene-c","scene-d"};viewer.sceneCatalogLabels=viewer.sceneCatalogIds.clone();
    viewer.presentation(VrUiState.SCENE_PANEL);
    require(viewer.modal()&&viewer.hit(400f/1600,210f/1000)==VrUiState.MODE_LIVE,"Integrated mode panel supports live selection");
    require(viewer.hit(900f/1600,210f/1000)==VrUiState.MODE_SCENE,"Integrated panel supports scene mode");
    require(viewer.hit(400f/1600,375f/1000)==VrUiState.SCENE_ITEM,"Real scene list supports ray selection");
    for(VrUiState.Rect button:viewer.buttons())require(button.id!=VrUiState.SCENE_LOCAL&&button.id!=VrUiState.SCENE_REMOTE,"No legacy mesh/source browser actions");
    viewer.sceneScroll=viewer.sceneScrollMax();require(viewer.hit(400f/1600,600f/1000)==VrUiState.SCENE_ITEM+3,"Scrolled scene list reaches final item");for(VrUiState.Rect button:viewer.buttons())require(button.id!=VrUiState.SCENE_PREV&&button.id!=VrUiState.SCENE_NEXT,"No paginated catalog controls");
    for(int mask=0;mask<128;mask++)if((mask&16)==0)require(viewer.localButtonAction(mask)==0,"Physical clicks and face buttons never operate menus/video/map");
    float[] stickPointer=new float[11];stickPointer[10]=3;for(int value=0;value<4;value++){int buttons=((value&1)!=0?64:0)|((value&2)!=0?32:0);StickButtons clicks=StickButtons.nativeSample(buttons,stickPointer,true);require(clicks.valid==3&&clicks.pressed==value,"Left/right click native order");sample.stickButtons=clicks;sample.time=10;Map<Long,Object> clicksBody=OperatorState.body(sample,20,true,1,1,1);for(String codec:new String[]{"opbin1","opq1"})require(Cbor.object(OperatorCompact.expand(OperatorCompact.pack(clicksBody,codec)).get(15L)).equals(clicks.cbor()),"Click state survives packed encoding");require(Cbor.number(Cbor.object(OperatorState.body(sample,200000000,true,1,1,1).get(15L)),1,3)==0,"Stale click state invalid");}
    require(StickButtons.nativeSample(96,stickPointer,false).valid==0,"Unfocused click input invalid");stickPointer[10]=1;require(StickButtons.nativeSample(96,stickPointer,true).pressed==1,"Inactive right click is not released-valid");

    viewer.presentation(VrUiState.RESUME);require(!viewer.scenePanel&&viewer.menuOpen,"Scene panel returns to normal menu");
    viewer.presentation(VrUiState.RESUME);require(!viewer.modal(),"Mode panel returns to normal VR");
    for(double scale:new double[]{1,.5,.25}){Telemetry scaled=new Telemetry(10,"arms","双臂模式","",false,0,0,0,Telemetry.Arm.unknown(),Telemetry.Arm.unknown(),"",scale,"");require(scaled.modeSummary(11).contains("倍率："+(scale==1?"1":scale==.5?"0.5":"0.25")+"×"),"Scale formatting preserves decimal precision");require(scaled.modeSummary(3000000000L).equals("模式未知 · 倍率：—"),"Stale scale is not displayed as current");}
    require(Telemetry.unknown().modeSummary(10).equals("模式未知 · 倍率：—"),"Missing scale never defaults to 1x");
    System.out.println("OPERATOR_STATE full sample bytes=" + opBytes.length);
    System.out.println("PASS: " + checks
        + (" contract, malformed input, lease, time, map atomicity/hash/recovery, coordinate and "
            + "stale-cloud assertions"));
  }
}


import com.tanluzhe.controlterminal.vr.v2.*;
import java.util.*;
public final class V2Fixture {
  private static String hex(byte[] b) {
    StringBuilder s = new StringBuilder();
    for (byte x : b) s.append(String.format(Locale.ROOT, "%02x", x & 255));
    return s.toString();
  }
  public static void main(String[] args) throws Exception {
    Packet control = V2ContractTest.packet();
    control.node = 2;
    control.stream = 101;
    control.epoch = 1;
    control.body.put(
        10L, Cbor.map(0, 2, 1, new float[] {-.1f, .2f, .3f}, 2, new float[] {0, 0, 0, 1}));
    byte[] object = V2ContractTest.points(4);
    Packet first = V2ContractTest.tile(object, 0, 2, Arrays.copyOfRange(object, 0, 20)),
           second = V2ContractTest.tile(object, 1, 2, Arrays.copyOfRange(object, 20, 40));
    for (Packet p : new Packet[] {first, second}) {
      p.session = 1;
      p.node = 3;
      p.stream = 303;
      p.epoch = 1;
      p.time = 100;
      p.ttlMs = 500;
    }
    first.seq = 1;
    second.seq = 2;
    OperatorState.Sample sample = new OperatorState.Sample();
    sample.time = 1_000_000_000L;
    sample.flags = 7;
    sample.poses = new float[21];
    sample.poses[6] = sample.poses[13] = sample.poses[20] = 1;
    sample.poses[7] = .1234567f;
    sample.poses[8] = -.7654321f;
    sample.poses[11] = .38268343f;
    sample.poses[13] = .9238795f;
    sample.eyes = new float[22];
    sample.eyes[6] = sample.eyes[17] = 1;
    sample.faceButtons=new FaceButtons(15,9);
    sample.controllerBounds=new float[]{-.025f,-.025f,-.06f,.025f,.025f,.06f,0,
                                        -.025f,-.025f,-.06f,.025f,.025f,.06f,1};
    sample.controls =
        new InputControls(63, 1, 1, .25f, .75f, new float[] {0, 0}, new float[] {.5f, -.5f});
    Packet operator = new Packet();
    operator.type = Packet.OPERATOR;
    operator.stream = 102;
    operator.node = 2;
    operator.session = 1;
    operator.epoch = 1;
    operator.seq = 1;
    operator.time = sample.time;
    operator.ttlMs = 1000;
    operator.body = OperatorState.body(sample, sample.time, true, 0, 0, 1);
    byte[] original = operator.encode();
    operator.body = OperatorCompact.pack(operator.body, "opbin1");
    byte[] lossless = operator.encode();
    operator.body = OperatorCompact.pack(OperatorCompact.expand(operator.body), "opq1");
    byte[] quantized = operator.encode();
    operator.body = OperatorCompact.expand(operator.body);
    System.out.println("{\n  \"protocol\":\"TLZ/2.0\",\n  \"operator_state_hex\":\"" + hex(original)
        + "\",\n  \"operator_lossless_hex\":\"" + hex(lossless)
        + "\",\n  \"operator_quantized_hex\":\"" + hex(quantized)
        + "\",\n  \"operator_bytes\":" + original.length + ",\n  \"note\":\"Codec fixtures only; "
        + "timestamps are not a live session.\",\n  \"control_hex\":\"" + hex(control.encode())
        + "\",\n  \"map_chunk_0_hex\":\"" + hex(first.encode()) + "\",\n  \"map_chunk_1_hex\":\""
        + hex(second.encode()) + "\",\n  \"map_object_hex\":\"" + hex(object) + "\"\n}");
  }
}

# 2.7 新增第三方组件说明

cgltf 1.15，MIT；源码：https://github.com/jkuhlmann/cgltf/tree/v1.15

cgltf.h SHA256：e378a21c084bf1f288bb799de827bb26906efb024255f1ecf1705ea13f11c6ec

Quest 官方手柄几何通过运行时加载，本 APK 没有打入静态 Meta 模型文件。

以下许可证适用于本次新增的 cgltf；原有组件的许可证仍适用。

```text
Copyright (c) 2018-2021 Johannes Kuhlmann

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

离线测试输入（不打入 APK）：WebXR Input Profiles / meta-quest-touch-plus 左右 GLB，MIT，Copyright (c) 2019 Amazon。
来源提交 `f4992299601614adbfefd398dc8e281556bb7444`：
https://github.com/immersive-web/webxr-input-profiles/tree/f4992299601614adbfefd398dc8e281556bb7444/packages/assets/profiles/meta-quest-touch-plus
许可证保存在 `tools/v2_deps/controller_model_test/LICENSE.md`。此资源仅测试 GLB 解析器，不能当作 Quest 官方运行时加载的实机证明。

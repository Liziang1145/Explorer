﻿param(
  [Parameter(Mandatory=$true)][string]$Serial,
  [ValidateSet('install','status','snapshot','logs','probe','demo','stop','exit','video','logs_ui','collect')][string]$Action='status',
  [string]$AdbPath="$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe",
  [string]$ApkPath=(Join-Path $PSScriptRoot '探路者-控制终端-2.8.0.apk'),
  [ValidateRange(0,2)][int]$Mode=1,
  [string]$OutputDirectory=(Join-Path $PSScriptRoot 'adb-diagnostics')
)
$ErrorActionPreference='Stop'
$terminalPackage='com.tanluzhe.controlterminal.vr'
if(-not(Test-Path -LiteralPath $AdbPath)){throw 'ADB not found; specify -AdbPath.'}
$model=(& $AdbPath -s $Serial shell getprop ro.product.model | Out-String).Trim()
if($LASTEXITCODE -ne 0 -or $model -notmatch 'Quest'){throw "Expected an explicitly selected Quest, got '$model'. No action performed."}
function Invoke-TerminalDebug([string]$Command){
  & $AdbPath -s $Serial shell am broadcast -n "$terminalPackage/.DebugReceiver" --es command $Command
  if($LASTEXITCODE -ne 0){throw 'ADB debug command failed.'}
}
switch($Action){
  'install' {if(-not(Test-Path -LiteralPath $ApkPath)){throw 'Specify -ApkPath to the APK.'};& $AdbPath -s $Serial install -r $ApkPath}
  'logs' {& $AdbPath -s $Serial logcat -d -v threadtime -t 600 'TLZ.APP:I' 'TLZ.UI:I' 'TLZ.NET:I' 'TLZ.RTC:I' 'TLZ.VIDEO:I' 'TLZ.INPUT:I' 'TLZ.CONTROL:I' 'TLZ.PROTO:I' 'TLZ.XR:I' 'TLZ.SCENE:I' 'TLZ.TELEMETRY:I' 'TLZ.CAPTURE:I' 'TLZ.ADB:I' 'TLZ2:I' '*:S'}
  'video' {& $AdbPath -s $Serial shell am broadcast -n "$terminalPackage/.DebugReceiver" --es command video --ei mode $Mode}
  'logs_ui' {Invoke-TerminalDebug 'logs'}
  'collect' {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    Invoke-TerminalDebug 'snapshot' | Set-Content -LiteralPath (Join-Path $OutputDirectory 'status.txt') -Encoding UTF8
    foreach($entry in @(@('files/v2-diagnostics.json','snapshot.json'),@('files/logs/ui.jsonl','ui.jsonl'),@('files/logs/vr.jsonl','vr.jsonl'))){
      & $AdbPath -s $Serial exec-out run-as $terminalPackage cat $entry[0] 2>&1 | Set-Content -LiteralPath (Join-Path $OutputDirectory $entry[1]) -Encoding UTF8
    }
    Write-Output "Collected app diagnostics to $OutputDirectory. Files not yet created are reported as missing."
  }
  default {Invoke-TerminalDebug $Action}
}

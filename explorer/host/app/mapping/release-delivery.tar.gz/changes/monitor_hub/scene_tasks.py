"""Map-scoped semantic context and supervised, one-step-at-a-time task tools.
No model supplied URL, code, epoch, enable/resume or CAN command is accepted.
"""
import hashlib
import json
import math
import secrets
import time
import itertools
from pathlib import Path
from http.client import HTTPConnection
from urllib.request import Request, build_opener, ProxyHandler
from task_service import TaskService as LegacyTasks, NoRedirect
from intent_gateway import Rejected, number

LABELS={'chair':'椅子','dining table':'桌子','bottle':'瓶子','person':'人','cup':'杯子','laptop':'笔记本电脑','tv':'显示器','bench':'长凳','backpack':'背包','keyboard':'键盘','mouse':'鼠标','book':'书','cell phone':'手机','bus':'公交车（请核验）','surfboard':'冲浪板（请核验）'}
LABELS.update({'baseball bat':'棒球棒','bed':'床','refrigerator':'冰箱','remote':'遥控器','skateboard':'滑板','suitcase':'行李箱','umbrella':'伞'})
FIELDS={'preset':{'side','which'},'ee_delta':{'side','d'},'ee_abs':{'side','p'},'joints_abs':{'side','deg'},'gripper':{'side','open'},'base_drive':{'vx','vy','wz','duration_s','rc'},'base_stop':set(),'stop':set()}

def console(path,body=None):
    if path not in ('/api/intent','/api/safety','/api/status','/api/base_status','/api/vr_telemetry') or (body is not None and path!='/api/intent'):raise Rejected('非法接口')
    c=HTTPConnection('127.0.0.1',8092,timeout=5)
    try:
        c.request('GET' if body is None else 'POST',path,None if body is None else json.dumps(body,allow_nan=False),{'Content-Type':'application/json','Origin':'http://127.0.0.1:8092'})
        r=c.getresponse();raw=r.read(1048577)
        if len(raw)>1048576:raise Rejected('响应过大')
        d=json.loads(raw)
        if r.status not in (200,202) or d.get('ok') is False:raise Rejected(str(d.get('error',r.status)))
        return d
    finally:c.close()

def validate_command(cmd,schema):
    if not isinstance(cmd,dict) or cmd.get('intent') not in FIELDS:raise Rejected('未登记的意图')
    name=cmd['intent']
    if set(cmd)!={'intent'}|FIELDS[name]:raise Rejected('意图参数字段不匹配')
    if name not in {x['intent'] for x in schema.get('intents',[])}:raise Rejected('当前接口不支持此意图')
    lim=schema['limits_machine'];en=schema['enums']
    if 'side' in cmd and cmd['side'] not in en['side']:raise Rejected('机械臂侧别无效')
    if name=='preset' and cmd['which'] not in en['which']:raise Rejected('预设位姿无效')
    for k,n in [('d',3),('p',3),('deg',6)]:
        if k in cmd:
            if not isinstance(cmd[k],list) or len(cmd[k])!=n:raise Rejected('向量长度错误')
            for v in cmd[k]:number(v)
    if name=='ee_delta' and max(map(abs,cmd['d']))>lim['ee_delta_max_cm']:raise Rejected('末端步进超限')
    if name=='gripper' and not 0<=number(cmd['open'])<=1:raise Rejected('夹爪范围错误')
    if name=='base_drive':
        for k,l in [('vx','base_max_vx_mps'),('vy','base_max_vy_mps'),('wz','base_max_wz_rads')]:
            if abs(number(cmd[k]))>lim[l]:raise Rejected('底盘速度超限')
        if not 0<number(cmd['duration_s'])<=lim['base_max_duration_s'] or type(cmd['rc']) is not bool:raise Rejected('时长或模式错误')
        if cmd['rc'] and cmd['vy']!=0:raise Rejected('RC 模式不支持横移')
        if not cmd['rc'] and cmd['wz'] and (cmd['vx'] or cmd['vy']):raise Rejected('全向模式平移和转向互斥，请分步或用RC')
    return cmd

def validate(value,c):
    if not isinstance(value,dict) or set(value)!={'schema','map_epoch','map_revision','summary','steps'} or value['schema']!='robot-task/3':raise Rejected('任务结构错误')
    if any(value[k]!=c[k] for k in ('map_epoch','map_revision')):raise Rejected('地图版本不匹配')
    if not isinstance(value['summary'],str) or not 1<=len(value['summary'])<=1000:raise Rejected('任务说明无效')
    if not isinstance(value['steps'],list) or not 1<=len(value['steps'])<=16:raise Rejected('任务最多16步')
    objects={o['id'] for o in c['scene']['objects']};places={p['id'] for p in c['places']}
    for s in value['steps']:
        if not isinstance(s,dict):raise Rejected('步骤类型错误')
        skill=s.get('skill')
        if skill=='intent' and set(s)=={'skill','command'}:validate_command(s['command'],c['intent_schema'])
        elif skill=='navigate_to_object' and set(s) in ({'skill','object_id'},{'skill','object_id','purpose'}) and s['object_id'] in objects and s.get('purpose','approach') in ('observe','approach'):pass
        elif skill=='navigate_to_place' and set(s)=={'skill','place_id','heading'} and s['place_id'] in places and s['heading'] in ('recorded','any'):pass
        elif skill=='observe_scene' and set(s)=={'skill'}:pass
        elif skill=='ask_user' and set(s)=={'skill','question'} and isinstance(s['question'],str) and 1<=len(s['question'])<=500:pass
        elif skill=='grasp_object' and set(s)=={'skill','object_id','side'} and s['object_id'] in objects and s['side'] in ('left','right'):pass
        else:raise Rejected('步骤含未知对象、地点或不支持字段')
    return value

class TaskService(LegacyTasks):
    def __init__(self,*a,scene_path='/home/apex/semantic_mapping/runtime/scene.json',**kw):
        super().__init__(*a,**kw);self.scene_path=Path(scene_path)
        for p in (self.root/'tasks').glob('*.json'):
            t=json.loads(p.read_text())
            if t.get('proposal',{}).get('schema')=='robot-task/3' and t.get('state') in ('prepared','awaiting_verification'):
                t.update(state='interrupted',error='服务重启；不恢复执行，请检查实车后新建任务');self.save(t)

    def scene(self,n=None):
        n=n or self.drive.get('navigation','/navigation/api/status')
        m=self.drive.map_for(n)
        scene_path=Path(m.get('semantic_scene_file') or self.scene_path)
        d=json.loads(scene_path.read_text())
        if str(d.get('map_epoch'))!=str(n['map_epoch']) or d.get('frame_id')!='camera_init' or d.get('synthetic') or d.get('incomplete'):raise Rejected('语义场景与当前地图不同源或不完整')
        H=m.get('transform_nav_from_saved')
        if not H or len(H)!=4 or any(len(row)!=4 for row in H):raise Rejected('缺少建图使用的原始地图到导航地图变换')
        def transform(p):return [sum(H[i][j]*p[j] for j in range(3))+H[i][3] for i in range(3)]
        objects=[];w=m['width'];res=m['resolution_m'];ox,oy=m['origin_xy_m'];valid=m.get('rectangle',{}).get('any_heading_free')
        for raw in d['objects']:
            o={k:raw.get(k) for k in ('id','label','center_m','bounds_m','size_m','observations','state','first_seen_s','last_seen_s','evidence_frames','bounds_kind','graspability','reachability')}
            if not o['center_m'] or not all(math.isfinite(v) for v in o['center_m']):continue
            o['source_center_m']=o['center_m'];o['center_m']=transform(o['center_m'])
            b=o['bounds_m'];corners=[transform(p) for p in itertools.product(*[(b[i],b[i+3]) for i in range(3)])]
            o['bounds_m']=[min(p[i] for p in corners) for i in range(3)]+[max(p[i] for p in corners) for i in range(3)]
            o['size_m']=[o['bounds_m'][i+3]-o['bounds_m'][i] for i in range(3)]
            o['label_zh']=LABELS.get(o['label'],o['label']);o['xy']=o['center_m'][:2];o['confidence']=None
            o['confidence_note']='多帧确认不是人工确认；未存储可靠的物体级置信概率'
            o['approach_candidates']=[];b=o['bounds_m'];cx,cy=o['xy']
            radius=max(math.hypot(b[3]-b[0],b[4]-b[1])/2+.55,.75)
            for extra in (0,.3,.6):
                for i in range(24):
                    a=i*math.tau/24;p=[cx+(radius+extra)*math.cos(a),cy+(radius+extra)*math.sin(a)];x=int(math.floor((p[0]-ox)/res));y=int(math.floor((p[1]-oy)/res))
                    if 0<=x<w and 0<=y<m['height'] and m['cells'][y*w+x]==0 and (valid is None or valid[y*w+x]):o['approach_candidates'].append(p)
            o['approach_note']='候选停车点需进一步路线及车身朝向检查；物体中心不是停车点'
            objects.append(o)
        return dict(evidence_directory=d.get('evidence_directory'),map_epoch=d['map_epoch'],map_revision=n['map_revision'],scene_revision=hashlib.sha256(scene_path.read_bytes()).hexdigest(),frame=m['frame'],source_frame=d['frame_id'],transform_nav_from_saved=H,objects=objects,relations=d['relations'],source_stamp=d['source_stamp'],recorded=True,semantic_available=d.get('semantic_available',True),limitations=d.get('limitations',[]),object_count=len(objects))

    def context(self):
        c=super().context();c['scene']=self.scene()
        try:c['intent_schema']=console('/api/intent');c['interface_error']=None
        except Exception as e:c['intent_schema']={'intents':[],'limits_machine':{},'enums':{}};c['interface_error']=str(e)
        try:
            n=self.drive.get('navigation','/navigation/api/status');c['robot_state']=dict(navigation_fresh=n.get('input_fresh'),live=n.get('live'),safety=console('/api/safety'),telemetry=console('/api/vr_telemetry'),snapshot_s=time.time())
        except Exception as e:c['robot_state']={'unavailable':str(e)}
        c['capability_revision']=hashlib.sha256(json.dumps(c['intent_schema'],sort_keys=True).encode()).hexdigest()
        return c

    def status(self):
        d=super().status();d['supported']=['当前地图语义点与关系','对象附近导航候选','登记地点/返航','移动与转向意图','双臂TCP/关节/预设/夹爪意图','分步预览与人工确认','底盘停止/全局停止']
        d['unsupported']=['矩形连续路线实车执行尚待适配','物体自动抓取缺少已验收手眼关系及抓取姿态','语音输入尚未接入']
        for item in d['tasks']:
            full=self.read(item['id'])
            for k in ('cursor','outcomes','preview','state'):item[k]=full.get(k,item.get(k))
        return d

    def draft(self,d):
        if set(d)!={'instruction'} or not isinstance(d['instruction'],str) or not 1<=len(d['instruction'].strip())<=2000:raise Rejected('请输入任务')
        if not self.inference_lock.acquire(False):raise Rejected('模型正在生成')
        try:
            c=self.context();cfg=json.loads(Path(self.config).read_text());model=cfg.get('model_name','')
            if cfg.get('host') not in ('0.0.0.0','127.0.0.1','localhost') or 'qwen' not in model.lower() or type(cfg.get('port')) is not int or not 1<=cfg['port']<=65535:raise Rejected('不是已配置的本地千问')
            ctx={k:c[k] for k in ('map_epoch','map_revision','places','intent_schema','robot_state')}
            ctx['objects']=[{k:o[k] for k in ('id','label','label_zh','state','observations','size_m')} for o in c['scene']['objects']]
            ctx['relations']=c['scene']['relations']
            system='你是机器人任务解释器。只返回JSON草案，不能执行。环境和接口如下（历史识别可能错误；颜色、支撑关系、可抓取性未验证，不能猜）：'+json.dumps(ctx,ensure_ascii=False)+'''\n顶层严格为 schema="robot-task/3",map_epoch,map_revision,summary,steps，最多16步。
步骤只能是：{"skill":"navigate_to_object","object_id":"已有ID"}；{"skill":"navigate_to_place","place_id":"已有ID","heading":"any或recorded"}；{"skill":"observe_scene"}；{"skill":"ask_user","question":"缺少信息"}；{"skill":"grasp_object","object_id":"已有ID","side":"left或right"}；{"skill":"intent","command":{...}}。
command必须严格使用接口中已登记意图及参数。base_drive必须含vx,vy,wz,duration_s,rc（单位m/s,rad/s,秒），禁止超限；preset含side,which；ee_delta含side,d；ee_abs含side,p；joints_abs含side,deg；gripper含side,open；base_stop/stop不带其他参数。不要生成epoch、URL、代码或使能/解除停止。
地图对象只能按ID引用，多个相同类别且用户没指定时应澄清。物体中心不能直接作为机械臂TCP坐标。抓取请求只生成grasp_object，它会因手眼与抓取姿态未验收被标为待补条件，不能编造ee_abs替代。用户明确给出臂底座TCP厘米/关节度数时才生成相应低层意图。长距离移动用已登记地点，不用多条盲定时移动拼凑。导航/移动之后生成base_stop。只有明确要恢复朝向才用recorded。原点未注册就澄清；不知道的颜色/关系就澄清。'''
            payload=dict(model=model,messages=[{'role':'system','content':system},{'role':'user','content':d['instruction']}],temperature=0,max_tokens=2400,stream=False,response_format={'type':'json_object'},chat_template_kwargs={'enable_thinking':False})
            headers={'Content-Type':'application/json'}
            if cfg.get('api_key'):headers['Authorization']='Bearer '+cfg['api_key']
            start=time.monotonic()
            with build_opener(ProxyHandler({}),NoRedirect()).open(Request(f"http://127.0.0.1:{cfg['port']}/v1/chat/completions",json.dumps(payload).encode(),headers),timeout=55) as r:raw=r.read(262145)
            if len(raw)>262144:raise Rejected('模型响应过大')
            response=json.loads(raw);content=response['choices'][0]['message']['content'];proposal=validate(json.loads(content),c)
            t=dict(id=secrets.token_hex(16),instruction=d['instruction'],created_s=time.time(),context=c,state='draft',cursor=0,outcomes=[],proposal=proposal,model=model,model_called=True,model_response=content,latency_s=time.monotonic()-start,prompt_version='semantic-skills-v3',user_message=d['instruction'])
            self.save(t);return t
        finally:self.inference_lock.release()

    def check_context(self,t):
        if t['proposal']['schema']!='robot-task/3':return super().check_context(t)
        c=self.context()
        if any(c[k]!=t['context'][k] for k in ('map_epoch','map_revision','places_revision','capability_revision')) or c['scene']['scene_revision']!=t['context']['scene']['scene_revision']:raise Rejected('地图、语义、地点或接口已改变，请重新生成')
        validate(t['proposal'],c);return c

    def preview(self,d):
        if set(d)!={'task_id'}:raise Rejected('预览字段错误')
        with self.lock:
            t=self.read(d['task_id'])
            if t['proposal']['schema']!='robot-task/3':return super().preview(d)
            c=self.check_context(t)
            if t['state'] not in ('draft','prepared'):raise Rejected('当前任务不可重放')
            s=t['proposal']['steps'][t['cursor']];p=dict(points=[],length_m=0,hardware_command_sent=False,blockers=[],step=s,step_index=t['cursor'],executable=False)
            skill=s['skill']
            if skill=='ask_user':p['blockers']=[s['question']]
            elif skill=='grasp_object':p['blockers']=['缺少已验收的相机/地图到机械臂TCP关系、抓取姿态和当前近距离观测；不生成猜测抓取坐标']
            elif skill=='observe_scene':p.update(executable=True,observation=c['scene'])
            elif skill=='intent':
                cmd=validate_command(s['command'],c['intent_schema']);p['command']=cmd
                if cmd['intent'] in ('base_stop','stop'):p['executable']=True
                elif cmd['intent']=='base_drive':p['blockers']=['底盘移动/转向接口已登记；当前矩形连续扫掠执行器未接通，不绕过导航检查发送定时动作']
                else:
                    p['safety']=console('/api/safety');p['telemetry']=console('/api/vr_telemetry');p['blockers']=self.arm_checks(cmd,p['safety'],p['telemetry']);p['executable']=not p['blockers']
            elif skill in ('navigate_to_object','navigate_to_place'):
                n=self.drive.get('navigation','/navigation/api/status');m=self.drive.map_for(n);live=n.get('live');start=self.drive.xyz(live)[:2] if live and n.get('input_fresh') else m['example_points']['start']
                if skill=='navigate_to_object':
                    o=next(o for o in c['scene']['objects'] if o['id']==s['object_id']);goals=sorted(o['approach_candidates'],key=lambda q:math.dist(q,start))[:2];p['object']=o
                else:
                    place=next(q for q in c['places'] if q['id']==s['place_id']);goals=[place['xy']];p['resolved_place']=place
                errors=[]
                for goal in goals:
                    code,r=self.drive.transport.call('navigation','/navigation/api/plan',dict(map_epoch=c['map_epoch'],map_revision=c['map_revision'],start=start,goal=goal,radius_m=m['default_radius_m'],mode='offline'))
                    if code==200:
                        p.update(points=[q for seg in r['segments'] for q in seg['centers_xy_m']],length_m=r['total_length_m'],route=r,approach_xy=goal,offline_start=start);break
                    errors.append(r.get('error',str(code)))
                p['blockers']=['仅离线任务路线；当前矩形执行器尚未接通']
                if not p['points']:p['blockers'].append('未找到已验证接近路线：'+'; '.join(errors[-2:]))
                if skill=='navigate_to_place' and s['heading']=='recorded':p['blockers'].append('记录终点朝向需额外执行器验收，离线路线未保证该朝向')
            p['token']=secrets.token_urlsafe(24);t.update(state='prepared',preview=p,prepared_at_s=time.time());self.save(t);return t

    def arm_checks(self,cmd,safety,telemetry):
        errors=self.drive.full_contract_errors()
        if not self.drive.enabled:errors.append('未启用现场执行接口')
        status=console('/api/status')
        if status.get('deploy')!='RUNNING' or status.get('can1' if cmd['side']=='left' else 'can2')!='UP':errors.append('机械臂部署或CAN未就绪')
        if safety.get('stopped') is not False or safety.get('pending') is not False:errors.append('全局软件停止锁存，需现场人工解除')
        if self.drive.busy:errors.append('底盘任务执行中')
        base=console('/api/base_status').get('device',{});fb=base.get('feedback') or {}
        if not base.get('fresh') or not all(k in fb and abs(number(fb[k]))<=.01 for k in ('vx','vy','angular_raw')):errors.append('底盘未确认零速')
        arms=telemetry.get('arms',{});arm=arms.get(cmd.get('side'),{})
        if telemetry.get('mode')!='arms' or any(x.get('vr_pressing') for x in arms.values()):errors.append('控制权占用或未知')
        if arm.get('ee_src')!='feedback' or not arm.get('fb_deg'):errors.append('缺少真实机械臂反馈；目标坐标不能当测量值')
        if cmd['intent']=='joints_abs' and arm.get('fb_deg'):
            lim=console('/api/intent')['limits_machine']['joint_step_max_deg']
            if any(abs(a-b)>lim for a,b in zip(cmd['deg'],arm['fb_deg'])):errors.append('关节相对当前反馈步进超限')
        if cmd['intent']!='gripper' and any(x.get('state') not in ('idle','stopped',None) for x in arms.values()):errors.append('已有机械臂动作尚未结束')
        return errors

    def execute(self,d):
        with self.lock,self.drive.command_lock,self.drive.lock:
            t=self.read(d.get('task_id'))
            if t['proposal']['schema']!='robot-task/3':return super().execute(d)
            self.check_context(t)
            if set(d)!={'task_id','token','acknowledgements'} or d['acknowledgements']!={k:True for k in self.drive.ACKS} or any(type(v) is not bool for v in d['acknowledgements'].values()):raise Rejected('需现场确认')
            p=t.get('preview',{})
            if t['state']!='prepared' or time.time()-t['prepared_at_s']>20 or d['token']!=p.get('token') or not p.get('executable'):raise Rejected('预览过期或前提未通过')
            step=p['step'];cmd=step.get('command');safety=None
            if cmd and cmd['intent'] not in ('base_stop','stop'):
                safety=console('/api/safety');errors=self.arm_checks(cmd,safety,console('/api/vr_telemetry'))
                if errors or safety.get('epoch')!=p['safety'].get('epoch'):raise Rejected('状态变化，重新预览：'+';'.join(errors))
            t['state']='submitting';self.save(t)
            try:
                if step['skill']=='observe_scene':result={'scene_revision':t['context']['scene']['scene_revision'],'motion_sent':False}
                elif cmd['intent']=='base_stop':result=self.drive.stop('千问分步任务：停止底盘')
                else:
                    if cmd['intent']=='stop':self.drive.stop('千问任务请求全局停止，先终止底盘跟踪')
                    result=console('/api/intent',cmd if safety is None else dict(cmd,safety_epoch=safety['epoch']))
                t['outcomes'].append(dict(step_index=t['cursor'],time_s=time.time(),step=step,result=result,status='accepted_not_verified'))
                t.update(state='awaiting_verification',result=result);self.save(t);return t
            except Exception as e:
                t.update(state='failed',error=str(e));self.save(t);raise

    def complete_step(self,d):
        if set(d)!={'task_id','confirm_observed_completion'} or d['confirm_observed_completion'] is not True:raise Rejected('请确认实际结果')
        with self.lock:
            t=self.read(d['task_id']);self.check_context(t)
            if t['state']!='awaiting_verification':raise Rejected('没有待确认结果')
            t['outcomes'][-1]['status']='operator_verified';t['outcomes'][-1]['verified_s']=time.time();t['cursor']+=1
            t['state']='completed' if t['cursor']==len(t['proposal']['steps']) else 'draft';t.pop('preview',None);self.save(t);return t

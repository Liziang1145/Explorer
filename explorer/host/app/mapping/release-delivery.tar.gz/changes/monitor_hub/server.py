"""Loopback monitor with a separate, explicitly enabled chassis intent gate.

Map/semantic proxies remain plan/draft-only. The separate /hub/api/drive path
allows confirmed bounded straight pulses and global stop, not a generic proxy.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
from http.client import HTTPConnection,HTTPException
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
import logging
from pathlib import Path
import re
import signal
import threading
import time
import sys
sys.path.insert(0,'/home/apex/research/map_navigation_pipeline_20261031')
import pipeline_manager
from intent_gateway import Rejected
from route_gateway import RouteGateway,smooth_route_result
from motion_log import MotionLog
from evidence_tasks import TaskService
from urllib.parse import urlsplit,parse_qs

ROOT=Path(__file__).resolve().parent
STATIC={'/':('index.html','text/html; charset=utf-8'),
 '/hub/app.js':('app.js','text/javascript; charset=utf-8'),
 '/hub/style.css':('style.css','text/css; charset=utf-8'),
 '/hub/embed.css':('embed.css','text/css; charset=utf-8')}
STATIC.update({
 '/hub/evidence.css':('evidence.css','text/css; charset=utf-8'),
 '/hub/evidence-panel.js':('evidence-panel.js','text/javascript; charset=utf-8'),
 '/hub/task-evidence.js':('task-evidence.js','text/javascript; charset=utf-8'),
 '/hub/brush.js':('brush.js','text/javascript; charset=utf-8'),
 '/hub/tasks.html':('tasks.html','text/html; charset=utf-8'),
 '/hub/tasks.js':('tasks.js','text/javascript; charset=utf-8'),
 '/hub/tasks.css':('tasks.css','text/css; charset=utf-8'),
 '/hub/gaussian-viewer.html':('gaussian-viewer.html','text/html; charset=utf-8'),
 '/hub/gaussian-viewer.js':('gaussian-viewer.js','text/javascript; charset=utf-8'),
 '/hub/gaussian-viewer.css':('gaussian-viewer.css','text/css; charset=utf-8'),
 '/hub/vendor/gaussian-splats-3d.module.js':('vendor/gaussian-splats-3d.module.js','text/javascript; charset=utf-8'),
 '/hub/vendor/three.module.js':('vendor/three.module.js','text/javascript; charset=utf-8')})
STATIC.update({'/hub/cloud.html':('cloud.html','text/html; charset=utf-8'),'/hub/cloud.js':('cloud.js','text/javascript; charset=utf-8'),'/hub/cloud.css':('cloud.css','text/css; charset=utf-8')})
JOB=re.compile(r'\d{8}T\d{6}Z-(?:SYNTHETIC|real)')
CSP="default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-src 'self'; frame-ancestors 'self'; base-uri 'none'; object-src 'none'; form-action 'none'"
# Only the isolated renderer needs inline library layout and WASM/blob workers.
# No external URLs, JavaScript eval, robot endpoint or global CSP relaxation.
VIEWER_CSP=CSP.replace("style-src 'self'", "style-src 'self' 'unsafe-inline'").replace("script-src 'self'", "script-src 'self' 'wasm-unsafe-eval'")+"; worker-src 'self' blob:"


def read_json(path,limit=2*1024**2):
    with Path(path).open('rb') as f:raw=f.read(limit+1)
    if len(raw)>limit:raise ValueError('document too large')
    return json.loads(raw,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while block:=f.read(1024*1024):h.update(block)
    return h.hexdigest()


def inside_file(root,rel,max_bytes):
    p=(root/rel).resolve()
    if not p.is_relative_to(root.resolve()) or not p.is_file() or p.stat().st_size>max_bytes:
        raise ValueError('artifact outside root, missing or oversized')
    return p


class Catalog:
    def __init__(self,root):
        self.root=Path(root).resolve();self.hash_cache={};self.lock=threading.Lock()

    def checked(self,path,expected):
        if not re.fullmatch(r'[a-f0-9]{64}',str(expected)):raise ValueError('missing artifact digest')
        stat=path.stat();sig=(str(path),stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns)
        with self.lock:actual=self.hash_cache.get(sig)
        if actual is None:
            actual=sha(path)
            with self.lock:
                if len(self.hash_cache)>4096:self.hash_cache.clear()
                self.hash_cache[sig]=actual
        if actual!=expected:raise ValueError('artifact digest mismatch')

    def job(self,identifier):
        if not JOB.fullmatch(identifier):raise ValueError('invalid job id')
        path=inside_file(self.root,f'jobs/{identifier}/job.json',256*1024)
        job=read_json(path,256*1024)
        synthetic=job.get('synthetic') is True
        if (job.get('schema')!='apex-gaussian-job/1' or job.get('error') or
            job.get('status')!=('synthetic_smoke_completed' if synthetic else 'training_completed_needs_visual_review') or
            job.get('control_enabled') is not False):raise ValueError('job not a completed safe offline export')
        dataset=Path(job['source_dataset']).resolve()
        if not any(dataset.is_relative_to(self.root/part) for part in ('datasets','validation')):
            raise ValueError('dataset must belong to this independent reconstruction project')
        manifest_path=inside_file(dataset,'manifest.json',16*1024**2)
        self.checked(manifest_path,job['manifest_sha256']);manifest=read_json(manifest_path,16*1024**2)
        if (manifest.get('schema')!='apex-gaussian-dataset/1' or bool(manifest.get('synthetic'))!=synthetic or
            manifest.get('map_epoch')!=job.get('map_epoch')):raise ValueError('input provenance mismatch')
        outputs=job.get('outputs',[])
        if not outputs or len(outputs)>100:raise ValueError('no bounded output inventory')
        output=outputs[-1];name=output.get('file','')
        if not re.fullmatch(r'export_\d+\.ply',name):raise ValueError('unexpected Gaussian filename')
        ply=inside_file(path.parent,name,512*1024**2);self.checked(ply,output['sha256'])
        # We browse only actual held-out renders; no fabricated views or placeholders.
        steps=int(name.removeprefix('export_').removesuffix('.ply'))
        render_dir=path.parent/f'eval_{steps}'
        if not render_dir.resolve().is_relative_to(path.parent.resolve()):raise ValueError('render path escape')
        images=sorted(p.stem for p in render_dir.glob('*.png') if re.fullmatch(r'\d{6}',p.stem))
        if not images or len(images)>1500:raise ValueError('no bounded rendered views')
        prefix=f'/hub/api/gaussian/jobs/{identifier}'
        public=dict(id=identifier,synthetic=synthetic,live=False,state=job['status'],map_epoch=job['map_epoch'],
            steps=steps,gaussians=output['vertices'],input_frames=manifest.get('selected_frames'),
            elapsed_s=job.get('elapsed_s'),frame_ids=images,download_url=prefix+'/download.ply',
            views=[dict(id=v,input_url=prefix+'/input/'+v+'.png',render_url=prefix+'/render/'+v+'.png') for v in images],
            evaluation=job.get('evaluation'),real_scene_quality_validated=job.get('real_scene_quality_validated',False),
            warning='合成几何与已知姿态，不是实验室扫描，也不是 YOLO 识别结果。' if synthetic else '离线历史场景，不代表当前环境；外参、重影和遗漏仍需复核。')
        offset=manifest.get('experimental_pose_lookup_offset_s',0)
        if not isinstance(offset,(int,float)) or abs(offset)>.2:raise ValueError('invalid offline time experiment')
        public['variant_label']='原始初始化'
        if manifest.get('optimization')=='balanced_multiview_seed_v1':
            public['variant_label']='多视角均衡初始化'
        if manifest.get('optimization')=='reliable_rgbd_mask_and_clear_frames_v1':
            public['variant_label']='清晰帧＋可靠深度掩膜'
        if manifest.get('optimization')=='metric_depth_supervision_v1':
            weight=job.get('depth_loss_weight')
            if not isinstance(weight,(int,float)) or not 0<=weight<=1:
                raise ValueError('invalid depth experiment weight')
            public['variant_label']=f'RGB＋深度监督（权重 {weight:g}）' if weight>0 else '同帧 RGB 对照（深度损失关闭）'
            depth_eval=job.get('depth_evaluation',{})
            public['depth_evaluation']={k:depth_eval.get(k) for k in
                ('mean_coverage','mean_covered_mae_m','mean_all_valid_clipped_mae_m','limits')}
            public['warning']+=' 深度误差以过滤后的相机深度为参考，不是独立测量真值。'
        if offset:
            public['variant_label']+=f' / 位姿 {offset*1000:+.0f} ms 试验'
            public['warning']+=f' 此版本仅离线试用 {offset*1000:+.0f} ms 位姿查询偏移，未修改在线标定，不是已验收的同步参数。'
        public['preview_url']=prefix+'/preview.json' if (path.parent/'web-preview/preview.json').is_file() else None
        return public,job,manifest,dataset,path.parent,ply

    def preview(self,identifier):
        public,job,manifest,dataset,folder,ply=self.job(identifier)
        metadata=inside_file(folder,'web-preview/preview.json',512*1024)
        m=read_json(metadata,512*1024)
        if (m.get('schema')!='apex-gaussian-web-preview/1' or m.get('job_id')!=identifier or
            m.get('job_sha256')!=sha(folder/'job.json') or m.get('source_ply_sha256')!=job['outputs'][-1]['sha256'] or
            m.get('manifest_sha256')!=job['manifest_sha256'] or m.get('map_epoch')!=job['map_epoch'] or
            m.get('frame_id')!=job.get('frame_id') or bool(m.get('synthetic'))!=bool(job.get('synthetic')) or
            m.get('control_enabled') is not False or m.get('vertices')!=public['gaussians'] or
            m.get('file')!='scene.splat' or m.get('format')!='splat' or m.get('spherical_harmonics_degree')!=0):
            raise ValueError('preview provenance mismatch')
        binary=inside_file(folder,'web-preview/scene.splat',80*1024**2)
        if binary.stat().st_size!=m['vertices']*32 or binary.stat().st_size!=m['bytes']:
            raise ValueError('truncated preview')
        self.checked(binary,m['sha256'])
        result={k:m[k] for k in ('job_id','map_epoch','frame_id','synthetic','vertices','bytes','sha256',
            'overview','top','cameras','limits','spherical_harmonics_degree')}
        result.update(scene_url=f'/hub/api/gaussian/jobs/{identifier}/scene.splat',control_enabled=False,live=False)
        return result,binary

    def list(self):
        entries=[];rejected=0
        for path in sorted((self.root/'jobs').glob('*/job.json'),reverse=True)[:100]:
            try:
                public,*_=self.job(path.parent.name)
                entries.append({k:public[k] for k in ('id','synthetic','state','steps','gaussians','input_frames','warning','variant_label')})
            except (OSError,ValueError,KeyError,TypeError):rejected+=1
        return dict(jobs=entries,rejected_jobs=rejected,live=False,training_endpoint=False)

    def artifact(self,identifier,kind,frame=None):
        public,job,manifest,dataset,folder,ply=self.job(identifier)
        if kind=='download':return ply,'application/octet-stream',ply.name
        if frame not in public['frame_ids']:raise ValueError('not a recorded evaluation view')
        if kind=='input':
            rel=f'images/{frame}.png';p=inside_file(dataset,rel,12*1024**2)
            self.checked(p,manifest['artifact_sha256'].get(rel))
        elif kind=='render':
            p=inside_file(folder,f'eval_{public["steps"]}/{frame}.png',12*1024**2)
            metrics=(job.get('evaluation') or {}).get('views',[])
            expected=next((v.get('render_sha256') for v in metrics if v.get('frame')==frame),None)
            if expected:self.checked(p,expected)
        else:raise ValueError('unknown image kind')
        return p,'image/png',None


def upstream_route(path,query='',method='GET'):
    """Explicit methods, path patterns and query keys. Never accept a user URL."""
    q=parse_qs(query,keep_blank_values=True)
    if method=='POST':
        if not query and path in ('/navigation/api/plan','/navigation/api/replay','/navigation/api/seed'):
            return 'navigation',path
        return ('semantic','/api/task-draft') if path=='/semantic/api/task-draft' and not query else None
    if method!='GET':return None
    if not query and path in ('/navigation/','/navigation/nav.js','/navigation/nav.css','/navigation/drive.js',
                              '/navigation/api/map','/navigation/api/status','/navigation/api/replays','/navigation/api/last-plan'):
        return 'navigation',path
    if path in ('/mapping/','/dashboard.js','/dashboard.css') and not query:
        return 'mapping','/' if path=='/mapping/' else path
    if path in ('/semantic/','/semantic/app.js','/semantic/app.css') and not query:
        return 'semantic',path.removeprefix('/semantic')
    if path=='/api/preview' and set(q)=={'kind'} and len(q['kind'])==1 and q['kind'][0] in ('camera','depth','cloud','yolo'):
        return 'mapping',path+'?'+query
    if not query and (path in ('/api/status','/api/health','/api/map/live','/api/maps') or
        re.fullmatch(r'/api/maps/[a-f0-9]{20}(?:/download)?',path)):
        return 'mapping',path
    semantic=path.removeprefix('/semantic') if path.startswith('/semantic/') else ''
    if not query and semantic in ('/api/status','/api/health','/api/preview','/api/map','/api/semantic-layers','/api/demo-layers',
        '/api/download/lidar.ply','/api/download/map.json','/api/download/map.ply'):
        return 'semantic',semantic
    if semantic in ('/api/image/rgb','/api/image/overlay') and (not query or
        (set(q)=={'v'} and len(q['v'])==1 and re.fullmatch(r'\d{1,24}',q['v'][0]))):
        return 'semantic',semantic+('?' + query if query else '')
    return None


def adapt_asset(raw,path,which):
    if path not in ('/','/app.js'):return raw
    text=raw.decode('utf-8')
    if which=='semantic':
        text=text.replace('/api/','/semantic/api/')
        if path=='/':text=text.replace('href="/app.css"','href="/semantic/app.css"').replace('src="/app.js"','src="/semantic/app.js"')
    if which=='semantic' and path=='/':text=text.replace('</head>','<link rel="stylesheet" href="/hub/evidence.css"><script defer src="/hub/evidence-panel.js"></script></head>')
    if path=='/':text=text.replace('</head>','<link rel="stylesheet" href="/hub/embed.css"></head>')
    return text.encode('utf-8')


def decorate_plan(route, map_data):
    """A valid upstream plan can be unsuitable for continuous execution."""
    try:
        return 200,smooth_route_result(route,map_data,route['robot_radius_m'])
    except ValueError as exc:
        return 422,dict(error='路线连续跟踪检查未通过：'+str(exc),
            code='route_geometry_rejected',stage='continuous_path_validation',
            upstream_available=True,raw_plan_available=True,
            motion_authorized=False,control_enabled=False)


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def gate(self,post=False):
        host=self.headers.get('Host','')
        if not re.fullmatch(r'(127\.0\.0\.1|localhost)(:\d{1,5})?',host):return False
        origin=self.headers.get('Origin')
        return (origin=='http://'+host if post else origin in (None,'http://'+host)) and self.headers.get('Sec-Fetch-Site')!='cross-site'

    def headers_for(self,status,length,mime,download=None):
        self.send_response(status)
        for k,v in {'Content-Type':mime,'Content-Length':str(length),'Cache-Control':'no-store',
                    'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',
                    'Content-Security-Policy':VIEWER_CSP if urlsplit(self.path).path=='/hub/gaussian-viewer.html' else CSP,
                    'X-Frame-Options':'SAMEORIGIN'}.items():self.send_header(k,v)
        if download:self.send_header('Content-Disposition',f'attachment; filename="{download}"')
        self.end_headers()

    def reply(self,status,raw,mime='application/json; charset=utf-8'):
        self.headers_for(status,len(raw),mime)
        try:self.wfile.write(raw)
        except (BrokenPipeError,ConnectionResetError):pass

    def data(self,status,data):self.reply(status,json.dumps(data,ensure_ascii=False,allow_nan=False).encode())

    def proxy(self,which,path,body=None):
        port=self.server.ports[which]
        conn=HTTPConnection('127.0.0.1',port,timeout=60 if body is not None or path.startswith('/api/maps/') else 8)
        sent=False
        try:
            headers={'Host':f'127.0.0.1:{port}','Origin':f'http://127.0.0.1:{port}','Sec-Fetch-Site':'same-origin'}
            if body is not None:headers.update({'Content-Type':'application/json','Content-Length':str(len(body))})
            conn.request('POST' if body is not None else 'GET',path,body,headers)
            res=conn.getresponse();length=int(res.getheader('Content-Length','-1'))
            if not 0<=length<=256*1024**2:raise ValueError('upstream response outside size bound')
            mime=res.getheader('Content-Type','application/octet-stream')
            if which=='navigation' and path=='/navigation/api/plan' and res.status==200:
                r=json.loads(res.read(length));m=self.server.drive.get('navigation','/navigation/api/map')
                return self.data(*decorate_plan(r,m))
            if which=='navigation' and path=='/navigation/api/last-plan' and res.status==200:
                r=json.loads(res.read(length))
                if r.get('available'):
                    record=r['record'];raw=record['result'];m=self.server.drive.get('navigation','/navigation/api/map')
                    if raw.get('map_revision')==m.get('map_revision'):
                        record['raw_result']=raw
                        code,result=decorate_plan(raw,m)
                        if code!=200:return self.data(code,result)
                        record['result']=result
                        record['display_geometry']='recomputed_from_saved_raw_plan_with_current_smoothing'
                    else:record['display_geometry']='historical_map_revision_no_recompute'
                return self.data(200,r)
            transform=path=='/' or (which=='semantic' and path=='/app.js')
            if transform:
                if length>2*1024**2:raise ValueError('oversized frontend asset')
                raw=res.read(length)
                if len(raw)!=length:raise ValueError('incomplete upstream asset')
                return self.reply(res.status,adapt_asset(raw,path,which),mime)
            download=None
            if res.status==200:
                match=re.fullmatch(r'/api/maps/([a-f0-9]{20})/download',path)
                if which=='mapping' and match:download=f'map-{match[1]}.pcd'
                elif which=='semantic' and path.startswith('/api/download/'):download=path.rsplit('/',1)[1]
            self.headers_for(res.status,length,mime,download)
            sent=True
            remaining=length
            while remaining:
                block=res.read(min(65536,remaining))
                if not block:break
                self.wfile.write(block);remaining-=len(block)
        except (OSError,ValueError,HTTPException) as exc:
            logging.warning('monitor upstream failure module=%s path=%s error=%s: %s',which,path,type(exc).__name__,exc)
            # Errors before response headers can be reported normally. A partial
            # response is closed rather than injecting a second HTTP response.
            if not sent:self.data(502,dict(error='后台监控服务暂不可达或响应异常',module=which,control_enabled=False))
            else:self.close_connection=True
        finally:conn.close()

    def do_GET(self):
        if not self.gate():return self.data(403,{'error':'Same-origin loopback access required'})
        url=urlsplit(self.path)
        if url.scheme or url.netloc or len(self.path)>512:return self.data(400,{'error':'Invalid local path'})
        try:
            if url.path in STATIC and not url.query:
                name,mime=STATIC[url.path];return self.reply(200,(ROOT/'static'/name).read_bytes(),mime)
            cloud_match=re.fullmatch(r'/hub/api/cloud/(floor3-partial)/(manifest\.json|color\.bin|geometry\.bin|colored\.ply)',url.path)
            if cloud_match and not url.query:
                file=ROOT/'clouds'/cloud_match[1]/cloud_match[2]
                if not file.is_file():return self.data(404,{'error':'Export not ready'})
                return self.reply(200,file.read_bytes(),'application/json' if file.suffix=='.json' else 'application/octet-stream')
            if url.path=='/hub/api/health' and not url.query:
                return self.data(200,dict(service='apex-monitor-hub',control_enabled=self.server.drive.enabled,automatic_route_execution=True,training_enabled=False))
            if url.path=='/hub/api/status' and not url.query:return self.data(200,self.server.status())
            if url.path=='/hub/api/drive/status' and not url.query:return self.data(200,self.server.drive.status())
            if url.path=='/hub/api/drive/logs' and not url.query:return self.data(200,self.server.motion_log.read())
            if url.path=='/hub/api/evidence':
                q=parse_qs(url.query,keep_blank_values=True)
                if set(q)-{'object_id'} or ('object_id' in q and (len(q['object_id'])!=1 or not re.fullmatch(r'obj_\d{1,12}',q['object_id'][0]))):return self.data(400,{'error':'Invalid object evidence query'})
                return self.data(200,self.server.tasks.evidence_view(q.get('object_id',[None])[0]))
            evidence_image=re.fullmatch(r'/hub/api/evidence/(image/(obs_\d{6,12})|topology\.png)',url.path)
            if evidence_image:
                q=parse_qs(url.query,keep_blank_values=True)
                if set(q)!={'revision'} or len(q['revision'])!=1 or not re.fullmatch(r'[a-f0-9]{64}',q['revision'][0]):return self.data(400,{'error':'Evidence revision required'})
                p,mime=self.server.tasks.evidence_asset(evidence_image[2] or 'topology.png',q['revision'][0]);return self.reply(200,p.read_bytes(),mime)
            if url.path=='/hub/api/scene' and not url.query:return self.data(200,self.server.tasks.scene())
            if url.path=='/hub/api/tasks/status' and not url.query:return self.data(200,self.server.tasks.status())
            task_match=re.fullmatch(r'/hub/api/tasks/([a-f0-9]{32})',url.path)
            if task_match and not url.query:return self.data(200,self.server.tasks.read(task_match[1]))
            if url.path=='/hub/api/gaussian/jobs' and not url.query:return self.data(200,self.server.catalog.list())
            preview_match=re.fullmatch(r'/hub/api/gaussian/jobs/([A-Za-z0-9-]+)/(preview\.json|scene\.splat)',url.path)
            if preview_match and not url.query:
                identifier,kind=preview_match.groups();metadata,binary=self.server.catalog.preview(identifier)
                if kind=='preview.json':return self.data(200,metadata)
                self.headers_for(200,binary.stat().st_size,'application/octet-stream')
                with binary.open('rb') as f:
                    while block:=f.read(65536):self.wfile.write(block)
                return
            match=re.fullmatch(r'/hub/api/gaussian/jobs/([A-Za-z0-9-]+)(?:/(input|render)/(\d{6})\.png|/(download\.ply))?',url.path)
            if match and not url.query:
                identifier,kind,frame,download=match.groups()
                if not kind and not download:return self.data(200,self.server.catalog.job(identifier)[0])
                p,mime,name=self.server.catalog.artifact(identifier,'download' if download else kind,frame)
                self.headers_for(200,p.stat().st_size,mime,name)
                with p.open('rb') as f:
                    while block:=f.read(65536):self.wfile.write(block)
                return
            route=upstream_route(url.path,url.query)
            if route:return self.proxy(*route)
            return self.data(404,{'error':'Unknown allowed monitor route'})
        except (BrokenPipeError,ConnectionResetError):pass
        except (OSError,ValueError,KeyError,TypeError):self.data(409,{'error':'结果尚未就绪，或来源/哈希检查未通过；未使用占位图。'})

    def do_POST(self):
        if not self.gate(post=True):return self.data(403,{'error':'Same-origin request required'})
        if self.path=='/hub/api/maps/activate':
            try:
                n=int(self.headers.get('Content-Length','0'))
                if self.headers.get('Transfer-Encoding') or self.headers.get('Content-Type')!='application/json' or not 1<=n<=1024:raise Rejected('场景请求无效')
                self.connection.settimeout(65);d=json.loads(self.rfile.read(n))
                if set(d)!={'session','automatic'} or type(d['automatic']) is not bool:raise Rejected('场景请求字段无效')
                drive=self.server.drive
                # Same lock as execute(): selection cannot race a motion commit.
                with drive.lock:
                    if drive.busy:raise Rejected('导航正在执行；地图已生成，停稳后再切换')
                    # Validate before invalidating cached plans. Never send a motor/arm stop.
                    pipeline_manager.publication(d['session'])
                    drive.inhibited=True;drive.tokens.clear();drive.generation+=1
                    result=pipeline_manager.activate_locked(d['session'],d['automatic'])
                    drive.cached_map=None
                return self.data(200,result)
            except Exception as e:return self.data(409,dict(error=str(e),motion_sent=False))
        if self.path in ('/hub/api/tasks/draft','/hub/api/tasks/preview','/hub/api/tasks/execute','/hub/api/tasks/record-place','/hub/api/tasks/complete-step'):
            try:
                length=int(self.headers.get('Content-Length','0'))
                if self.headers.get('Transfer-Encoding') or self.headers.get('Content-Type')!='application/json' or not 1<=length<=8192:raise Rejected('任务请求格式或大小无效')
                self.connection.settimeout(65)
                d=json.loads(self.rfile.read(length),parse_constant=lambda _:(_ for _ in ()).throw(Rejected('非有限 JSON')))
                if not isinstance(d,dict):raise Rejected('需要 JSON 对象')
                kind=self.path.rsplit('/',1)[1].replace('-','_')
                return self.data(200,getattr(self.server.tasks,kind)(d))
            except (ValueError,KeyError,TypeError,OSError) as e:return self.data(409,dict(error=str(e),motion_retry_allowed=False))
        if self.path in ('/hub/api/drive/preview','/hub/api/drive/drawn-plan','/hub/api/drive/execute','/hub/api/drive/stop','/hub/api/drive/heartbeat','/hub/api/drive/rearm'):
            try:
                length=int(self.headers.get('Content-Length','0'))
                planning=self.path.endswith(('/preview','/drawn-plan'))
                if self.headers.get('Transfer-Encoding') or self.headers.get('Content-Type')!='application/json' or not 1<=length<=(32768 if planning else 2048):raise Rejected('请求类型或大小不合法')
                self.connection.settimeout(45 if planning else 6)
                d=json.loads(self.rfile.read(length),parse_constant=lambda _:(_ for _ in ()).throw(Rejected('非有限 JSON')))
                if not isinstance(d,dict):raise Rejected('需要 JSON 对象')
                kind=self.path.rsplit('/',1)[1].replace('-','_')
                if kind=='stop':
                    if set(d)!={'confirm_base_stop'} or d['confirm_base_stop'] is not True:raise Rejected('需要明确请求停止底盘')
                    return self.data(200,self.server.drive.stop())
                return self.data(200,getattr(self.server.drive,kind)(d))
            except (ValueError,TypeError,KeyError,OSError) as e:return self.data(409,dict(ok=False,error=str(e),motion_retry_allowed=False))
        if not upstream_route(self.path,method='POST'):return self.data(404,{'error':'No control or training endpoint'})
        try:
            if self.headers.get('Transfer-Encoding') or self.headers.get('Content-Type')!='application/json':raise ValueError('invalid content type')
            length=int(self.headers.get('Content-Length','0'))
            if not 1<=length<=8192:raise ValueError('invalid body size')
            self.connection.settimeout(65);body=self.rfile.read(length)
            data=json.loads(body)
            if self.path.startswith('/navigation/api/'):
                if not isinstance(data,dict) or length>4096:raise ValueError('invalid plan input')
                return self.proxy('navigation',self.path,body)
            if (not isinstance(data,dict) or set(data)!={'instruction','scene_revision'} or
                not isinstance(data['instruction'],str) or not 1<=len(data['instruction'])<=1000 or
                not isinstance(data['scene_revision'],str) or len(data['scene_revision'])>300):raise ValueError('invalid task draft fields')
            return self.proxy('semantic','/api/task-draft',body)
        except (ValueError,OSError):return self.data(400,{'error':'Invalid draft input','execution_enabled':False})


class Hub(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,port,gaussian_root,ports=None,allow_base_intents=False):
        super().__init__(('127.0.0.1',port),Handler)
        self.catalog=Catalog(gaussian_root);self.ports=ports or dict(mapping=8100,semantic=8120,navigation=8140)
        self.pool=ThreadPoolExecutor(max_workers=2);self.status_lock=threading.Lock();self.status_cache=None
        self.drive=RouteGateway(ROOT/'run/drive-audit.jsonl',enabled=allow_base_intents,
            contract_file=ROOT/'intent-contract.json')
        # A process restart must not clear the operator's navigation stop latch.
        # This software latch emits no hardware commands and never resumes a run.
        self.drive.inhibited=True
        self.motion_log=MotionLog(ROOT/'run/drive-audit.jsonl')
        self.tasks=TaskService(ROOT/'run/qwen-tasks',self.drive)

    def status(self):
        with self.status_lock:
            if self.status_cache and time.monotonic()-self.status_cache[0]<3:return self.status_cache[1]
            def check(item):
                which,port=item;conn=HTTPConnection('127.0.0.1',port,timeout=2)
                try:
                    conn.request('GET','/api/status');res=conn.getresponse();raw=res.read(1024*1024)
                    if res.status!=200:raise ValueError('unhealthy upstream')
                    data=json.loads(raw)
                    return which,dict(reachable=True,state=data.get('mapping',data).get('state','unknown'),
                        message=data.get('mapping',data).get('message',''),source_stamp=data.get('source_stamp'))
                except (OSError,ValueError,HTTPException):return which,dict(reachable=False,state='unreachable')
                finally:conn.close()
            value=dict(modules=dict(self.pool.map(check,self.ports.items())),control_enabled=self.drive.enabled,automatic_route_execution=True,server_time=time.time())
            self.status_cache=(time.monotonic(),value);return value

    def server_close(self):
        if self.drive.busy:self.drive.stop('监控服务退出，取消底盘路线')
        super().server_close();self.pool.shutdown(wait=False,cancel_futures=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--port',type=int,default=8130)
    p.add_argument('--gaussian-root',type=Path,default=ROOT.parent/'gaussian_reconstruction')
    p.add_argument('--allow-base-intents',action='store_true',help='Enable supervised base-only route preview/commit with bounded pulses and browser lease')
    args=p.parse_args();server=Hub(args.port,args.gaussian_root,allow_base_intents=args.allow_base_intents)
    def stop(*_):threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    print(f'APEX_MONITOR_HUB=http://127.0.0.1:{server.server_port}/',flush=True)
    try:server.serve_forever()
    finally:server.server_close()

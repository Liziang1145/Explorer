"""Read-only, exact-map-bound observation evidence. Never imports a robot driver."""
from pathlib import Path
import hashlib,json,re,threading,time
from evidence_retrieval import retrieve
from intent_gateway import Rejected

ROOT=Path(__file__).resolve().parent/'evidence'
class EvidenceStore:
    def __init__(self,root=ROOT):self.root=Path(root);self.lock=threading.RLock();self.cache={}
    def folder(self,scene):
        if not scene.get('evidence_directory'):return self.root/str(scene['map_epoch'])
        p=Path(scene['evidence_directory']).resolve()
        if not p.is_relative_to(Path('/home/apex/long_capture/sessions')) or p.name!='evidence':raise Rejected('证据路径不在采集会话目录中')
        return p
    def snapshot(self,scene):
        epoch=str(scene['map_epoch'])
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,90}',epoch):return None,None,'地图编号不合法'
        folder=self.folder(scene);p=folder/'graph.json'
        if not p.is_file():return None,None,'此地图尚未登记增强证据；不会套用其他地图的编号'
        with self.lock:
            key=(p.stat().st_mtime_ns,p.stat().st_size)
            if key!=self.cache.get('key') or p!=self.cache.get('path'):
                raw=p.read_bytes()
                if len(raw)>8*1024**2:raise Rejected('证据索引过大')
                g=json.loads(raw);self.cache=dict(key=key,path=p,graph=g,revision=hashlib.sha256(raw).hexdigest())
            g=self.cache['graph'];revision=self.cache['revision']
        for k in ('map_epoch','map_revision','scene_revision','frame'):
            if str(g.get(k))!=str(scene.get(k)):return None,None,f'证据与当前 {k} 不一致；增强证据已停用'
        if g.get('synthetic') is not False:return None,None,'不能把合成证据接入实景任务'
        return g,revision,None
    def binding(self,scene):
        g,rev,error=self.snapshot(scene)
        return dict(available=g is not None,revision=rev,message=error or '已绑定同一地图、语义版本与坐标系的历史证据',map_epoch=scene['map_epoch'],historical=True,current_target_observation=False)
    def context(self,instruction,scene):
        g,rev,error=self.snapshot(scene)
        if g is None:
            return dict(available=False,revision=None,message=error,evidence_ids=['meta_recording'],objects=[],observations=[],relations=[],open_observations=[],pairwise_geometry=[],spatial_topology={},current_observation_available=False)
        c=retrieve(instruction,graph=g);c.update(available=True,revision=rev)
        return c
    def view(self,scene,oid=None):
        g,rev,error=self.snapshot(scene)
        out=dict(binding=self.binding(scene),objects=[],relations=[],observations=[],open_observations=[],spatial_topology={},frame=scene['frame'],map_epoch=scene['map_epoch'])
        if g is None:return out
        if oid and oid not in {o['id'] for o in g['objects']}:raise Rejected('当前地图没有该物体')
        selected=[o for o in g['objects'] if not oid or o['id']==oid]
        fields=('id','label','label_zh','state','observations','center_m','last_seen_s','evidence_ids','review','bounds_kind','graspability','reachability')
        out['objects']=[{k:o.get(k) for k in fields} for o in selected]
        ids={o['id'] for o in selected};refs={e for o in selected for e in o.get('evidence_ids',[])}
        out['relations']=[r for r in g['relations'] if r['subject'] in ids or r['object'] in ids]
        out['observations']=[dict(o,image_url='/hub/api/evidence/image/'+o['id']+'?revision='+rev) for o in g['observations'] if o['id'] in refs]
        frames={o['frame_id'] for o in out['observations']}
        out['open_observations']=[{k:o.get(k) for k in ('id','name_zh','category','visual_evidence','semantic_status','frame_id')} for o in g.get('open_observations',[]) if not oid or o['frame_id'] in frames]
        out['spatial_topology']=g.get('spatial_topology',{})
        out['topology_image_url']=('/hub/api/evidence/topology.png?revision='+rev) if (self.folder(scene)/'topology_preview.png').is_file() else None
        out['limitations']=['历史证据不是当前观察','类别分歧不是已确认改名','几何邻近不证明支撑或可抓取','区域连接不是整车通行证明']
        return out
    def asset(self,scene,identifier,revision):
        g,rev,error=self.snapshot(scene)
        if g is None:raise Rejected(error)
        if revision!=rev:raise Rejected('图像证据版本已变化，请刷新')
        folder=self.folder(scene).resolve()
        if identifier=='topology.png':p=folder/'topology_preview.png';mime='image/png'
        else:
            o=next((o for o in g['observations'] if o['id']==identifier),None)
            if not o:raise Rejected('未登记图像证据')
            p=(folder/o['image']).resolve();mime='image/jpeg'
            if not p.is_relative_to(folder) or p.suffix.lower()!='.jpg':raise Rejected('非法图像路径')
        if not p.is_file() or p.stat().st_size>12*1024**2:raise Rejected('图像不可用')
        return p,mime

def validate_review(review,context):
    if not isinstance(review,dict) or set(review)!={'claims','missing_preconditions'}:raise Rejected('缺少模型证据审查字段')
    if not isinstance(review['claims'],list) or len(review['claims'])>6:raise Rejected('证据断言最多6项')
    known=set(context.get('evidence_ids',[]))
    for c in review['claims']:
        if not isinstance(c,dict) or set(c)!={'statement','status','evidence_ids'}:raise Rejected('证据断言字段错误')
        if not isinstance(c['statement'],str) or not 1<=len(c['statement'])<=700 or c['status'] not in ('historical','hypothesis','unknown'):raise Rejected('只能描述历史、候选或未知状态')
        refs=c['evidence_ids']
        if not isinstance(refs,list) or len(refs)>12 or any(not isinstance(x,str) or x not in known for x in refs):raise Rejected('模型引用了不存在的证据')
        if c['status']!='unknown' and not refs:raise Rejected('历史/候选断言必须引用证据')
    missing=review['missing_preconditions']
    if not isinstance(missing,list) or len(missing)>8 or any(not isinstance(x,str) or not 1<=len(x)<=400 for x in missing):raise Rejected('任务缺失前提格式错误')
    return review

def prerequisites(step,c):
    """Deterministic checks; model prose cannot mark a condition as satisfied."""
    rows=[]
    def add(code,status,text,blocking=False):rows.append(dict(code=code,status=status,description=text,blocking=blocking))
    skill=step['skill'];binding=c.get('evidence_binding',{})
    add('map_binding','met','地图/地点/接口版本将于预览和提交再次核对')
    if skill in ('navigate_to_object','grasp_object'):
        oid=step['object_id'];obj=next(o for o in c['scene']['objects'] if o['id']==oid)
        enhanced=next((o for o in c.get('evidence_context',{}).get('objects',[]) if o['id']==oid),{})
        conflict=enhanced.get('review',{}).get('status')=='category_conflict_candidate'
        add('evidence_binding','met' if binding.get('available') else 'unknown',binding.get('message','没有增强证据'))
        observing=skill=='navigate_to_object' and step.get('purpose')=='observe'
        add('target_identity','conflict' if conflict else 'candidate','类别存在分歧；导航只能作为观察候选区域' if conflict else f"历史识别 {obj['label']}；{obj.get('observations',0)} 次观测，不是人工真值",conflict and not observing)
        add('current_target_observation','unknown','尚无当前目标观测；到达候选区域不等于确认目标仍在')
        if not observing and c.get('evidence_review',{}).get('missing_preconditions'):add('declared_missing','missing','模型仍声明缺少任务条件：'+'；'.join(c['evidence_review']['missing_preconditions']),True)
        if skill=='grasp_object':add('grasp_calibration','missing','缺少已验收手眼关系、当前目标姿态与抓取方案',True)
    if skill in ('navigate_to_place','navigate_to_object'):
        fresh=c.get('robot_state',{}).get('navigation_fresh') is True
        add('localization','met' if fresh else 'missing','实时定位可用；预览和提交时仍会重新检查' if fresh else '当前缺少新鲜实时定位，暂不能预览或执行导航',not fresh)
        add('route_and_base','pending','复用既有矩形路线、障碍、停止锁存、零速反馈与控制权检查')
    if skill=='ask_user':add('clarification','missing',step['question'],True)
    return rows

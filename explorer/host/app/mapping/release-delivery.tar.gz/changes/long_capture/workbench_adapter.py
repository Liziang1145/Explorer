"""Workbench hooks for independent recording. Calls launch only on explicit POST."""
import json,re,sys
from pathlib import Path
sys.path.insert(0,'/home/apex/long_capture')
sys.path.insert(0,'/home/apex/research/map_navigation_pipeline_20261031')
import pipeline_manager
from session_status import list_sessions,describe,request_stop
ROOT=Path('/home/apex/long_capture/sessions')

def session(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{8}T\d{6}Z-[a-f0-9]{8}',value):raise ValueError('采集会话编号无效')
    p=(ROOT/value).resolve()
    if p.parent!=ROOT.resolve() or not (p/'session.json').is_file():raise ValueError('采集会话不存在')
    return p

def command(d):
    a=d.get('action')
    if a in ('long-check','long-scan'):
        seconds=d.get('seconds',3600);hz=d.get('rgbd_hz',5);derived=d.get('derived',True)
        if type(seconds) is not int or not 60<=seconds<=86400:raise ValueError('采集时长60–86400秒')
        if type(hz) not in (float,int) or not 1<=hz<=15:raise ValueError('RGB-D采样频率1–15Hz')
        if type(derived) is not bool:raise ValueError('定位选项无效')
        if a=='long-scan' and (d.get('coordinated') is not True or d.get('provisional') is not True):raise ValueError('请确认已协调传感器占用与工程标定条件')
        script='source /home/apex/mapping_native/env.sh; exec python3 /home/apex/long_capture/launch_long_capture.py --seconds '+str(seconds)+' --rgbd-hz '+str(hz)
        if derived or d.get('fisheye') is True:
            if not derived:raise ValueError('鱼眼累计着色需要定位分支')
            script=script.replace('/home/apex/long_capture/launch_long_capture.py','/home/apex/research/fisheye_mapping_20261030/launch.py')
        if not derived:script+=' --raw-only'
        if a=='long-scan':script+=' --start'
        return a,['/bin/bash','-c',script]
    if a in ('long-audit','long-export'):
        p=session(d.get('session'));state=describe(p)
        if any(b.get('alive') for b in state['branches'].values()):raise ValueError('请先正常停止采集并等候录包刷新')
        if a=='long-export':
            return a,['/bin/bash','-c','source /home/apex/mapping_native/env.sh; export PYTHONPATH=/usr/lib/python3/dist-packages:$PYTHONPATH; exec /home/apex/research/multicamera_calibration_20261030/.venv/bin/python /home/apex/research/fisheye_mapping_20261030/finish_session.py "$1" --now','dual-products',str(p)]
        file='audit_session.py' if a=='long-audit' else 'export_long_map.py'
        return a,['/bin/bash','-c','source /home/apex/mapping_native/env.sh; exec python3 /home/apex/long_capture/'+file+' "$1"','long-capture-job',str(p)]
    raise ValueError('未知独立采集操作')

def handle(h):
    from urllib.parse import urlsplit
    u=urlsplit(h.path)
    if not u.path.startswith('/api/v1/long-capture/'):return False
    if not h.session():h.hub_reply({'error':'请先登录工作台'},401);return True
    if u.query or h.headers.get('Sec-Fetch-Site')=='cross-site':h.hub_reply({'error':'请求不允许'},403);return True
    try:
        if h.command=='GET' and u.path=='/api/v1/long-capture/navigation':
            h.hub_reply(pipeline_manager.status());return True
        if h.command=='POST' and u.path in ('/api/v1/long-capture/navigation-build','/api/v1/long-capture/navigation-select','/api/v1/long-capture/semantic-build'):
            if h.headers.get('Origin') not in ('http://'+h.headers.get('Host',''),'https://'+h.headers.get('Host','')):raise ValueError('请从工作台提交')
            n=int(h.headers.get('Content-Length','0'))
            if not 0<n<=1024 or h.headers.get('Transfer-Encoding') or h.headers.get_content_type()!='application/json':raise ValueError('请求无效')
            d=json.loads(h.rfile.read(n))
            if set(d)!={'session'}:raise ValueError('请求字段无效')
            if u.path.endswith('navigation-build'):r=pipeline_manager.launch(d['session'])
            elif u.path.endswith('semantic-build'):r=pipeline_manager.launch_semantics(d['session'])
            else:r=pipeline_manager.http('/hub/api/maps/activate',dict(session=d['session'],automatic=False))
            h.hub_reply(r);return True
        if h.command=='GET' and u.path=='/api/v1/long-capture/status':
            from common import read_json
            h.hub_reply({'sessions':list_sessions(),'raw_independent':True,'auto_resume':False,'validation':read_json(ROOT.parent/'VALIDATION.json',{})});return True
        if h.command=='POST' and u.path=='/api/v1/long-capture/stop':
            if h.headers.get('Origin') not in ('http://'+h.headers.get('Host',''),'https://'+h.headers.get('Host','')):raise ValueError('请从工作台提交')
            n=int(h.headers.get('Content-Length','0'))
            if not 0<n<=4096 or h.headers.get('Transfer-Encoding') or h.headers.get_content_type()!='application/json':raise ValueError('请求无效')
            d=json.loads(h.rfile.read(n));h.hub_reply(request_stop(session(d.get('session'))));return True
        # Only a fixed exported PCD / manifest, never a generic filesystem reader.
        match=re.fullmatch(r'/api/v1/long-capture/export/(\d{8}T\d{6}Z-[a-f0-9]{8})/(\d{8}T\d{6}Z-[a-f0-9]{8})/(map\.pcd|manifest\.json)',u.path)
        if h.command=='GET' and match:
            p=session(match[1])/'map-source'/match[2]/match[3]
            if not p.is_file():raise ValueError('导出文件不存在')
            h.send_response(200);h.send_header('Content-Type','application/json' if p.suffix=='.json' else 'application/octet-stream');h.send_header('Content-Length',str(p.stat().st_size));h.end_headers()
            with p.open('rb') as f:
                while data:=f.read(65536):h.wfile.write(data)
            return True
        h.hub_reply({'error':'接口不存在'},404)
    except (ValueError,OSError,KeyError) as e:h.hub_reply({'error':str(e)},400)
    return True

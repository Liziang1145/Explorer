"""Authenticated same-origin mapping API. Fixed loopback service, no user URLs."""
import http.client,json,re
from urllib.parse import urlsplit,parse_qs

POST={'/navigation/api/plan','/navigation/api/replay','/navigation/api/seed','/semantic/api/task-draft'}
POST|={'/hub/api/drive/'+x for x in ('preview','drawn-plan','execute','stop','heartbeat','rearm')}
POST|={'/hub/api/tasks/'+x for x in ('draft','preview','execute','record-place','complete-step')}

def allowed(path,method):
 p=urlsplit(path)
 if p.scheme or p.netloc or len(path)>1024 or '%' in p.path or '\\' in path or '..' in p.path.split('/'):return False
 if method=='POST':return not p.query and p.path in POST
 if method!='GET':return False
 if p.path=='/api/preview':
  q=parse_qs(p.query);return set(q)=={'kind'} and q['kind'] in ([x] for x in ('camera','depth','cloud','yolo'))
 if p.path in ('/semantic/api/image/rgb','/semantic/api/image/overlay'):
  return not p.query or bool(re.fullmatch(r'v=\d{1,24}',p.query))
 if p.path=='/hub/api/evidence':return not p.query or bool(re.fullmatch(r'object_id=obj_\d{1,12}',p.query))
 if re.fullmatch(r'/hub/api/evidence/(image/obs_\d{6,12}|topology\.png)',p.path):return bool(re.fullmatch(r'revision=[a-f0-9]{64}',p.query))
 if p.query:return False
 if re.fullmatch(r'/hub/api/cloud/floor3-partial/(manifest\.json|color\.bin|geometry\.bin|colored\.ply)',p.path):return True
 if p.path.startswith('/hub/api/gaussian/'):return False
 if p.path in ('/api/status','/api/health','/api/map/live','/api/maps'):return True
 if re.fullmatch(r'/api/maps/[a-f0-9]{20}(/download)?',p.path):return True
 if p.path in {'/navigation/api/'+x for x in ('map','status','replays','last-plan')}:return True
 if p.path in {'/semantic/api/'+x for x in ('status','health','preview','map','semantic-layers','demo-layers','download/lidar.ply','download/map.json','download/map.ply')}:return True
 if p.path in {'/hub/api/'+x for x in ('status','health','scene','drive/status','drive/logs','tasks/status','evidence','gaussian/jobs')}:return True
 return bool(re.fullmatch(r'/hub/api/(tasks/[a-f0-9]{32}|evidence/(image/obs_\d{6,12}|topology\.png)|gaussian/jobs/[A-Za-z0-9-]+(/(preview\.json|scene\.splat|download\.ply|(input|render)/\d{6}\.png))?)',p.path))

def handle(h):
 if h.path.startswith('/api/v1/acceptance/'):
  from acceptance_proxy import handle as acceptance_handle
  return acceptance_handle(h)

 if h.path.startswith('/api/v1/calibration/'):
  from calibration_proxy import handle as calibration_handle
  return calibration_handle(h)

 if h.path.startswith('/api/v1/exploration/'):
  from exploration_proxy import handle as exploration_handle
  return exploration_handle(h)

 p=urlsplit(h.path)
 if p.path.startswith('/api/v1/vr-cloud/'):
  from vr_cloud_proxy import handle as vr_handle
  return vr_handle(h)
 if p.path.startswith('/api/v1/long-capture/'):
  from long_capture_adapter import handle as long_handle
  return long_handle(h)
 if p.path.startswith('/api/v1/cloud-static/'):
  from cloud_static import handle as static_handle
  return static_handle(h)
 if p.path.startswith('/api/v1/cloud-products/'):
  from cloud_products import handle as products_handle
  return products_handle(h)
 if p.path.startswith('/api/v1/cloud-history/'):
  from cloud_history import handle as history_handle
  return history_handle(h)
 own=p.path.startswith('/api/v1/mapping/')
 candidate=own or p.path.startswith(('/hub/api/','/navigation/api/','/semantic/api/','/api/maps','/api/map/')) or p.path in ('/api/status','/api/health','/api/preview')
 if not candidate:return False
 if not h.session():h.hub_reply({'error':'请先登录 AIPC 工作台'},401);return True
 if h.headers.get('Sec-Fetch-Site')=='cross-site':h.hub_reply({'error':'禁止跨站访问'},403);return True
 if own:
  from mapping_operations import serve
  serve(h);return True
 if not allowed(h.path,h.command):h.hub_reply({'error':'未开放的建图接口'},404);return True
 body=None
 if h.command=='POST':
  if h.headers.get('Origin') not in ('http://'+h.headers.get('Host',''),'https://'+h.headers.get('Host','')):
   h.hub_reply({'error':'请从工作台页面提交操作'},403);return True
  try:
   n=int(h.headers.get('Content-Length','0'))
   if not 0<n<=32768 or h.headers.get('Transfer-Encoding') or h.headers.get_content_type()!='application/json':raise ValueError()
   body=h.rfile.read(n);json.loads(body)
  except (ValueError,UnicodeError):h.hub_reply({'error':'JSON 请求无效或过大'},400);return True
 conn=http.client.HTTPConnection('127.0.0.1',8130,timeout=65);started=False
 try:
  conn.request(h.command,h.path,body,{'Content-Type':'application/json','Origin':'http://127.0.0.1:8130','Host':'127.0.0.1:8130'})
  r=conn.getresponse();n=int(r.getheader('Content-Length','-1'))
  if not 0<=n<=256*1024**2:raise ValueError('响应超出范围')
  h.send_response(r.status);started=True
  for k in ('Content-Type','Content-Disposition'):
   if r.getheader(k):h.send_header(k,r.getheader(k))
  h.send_header('Content-Length',str(n));h.send_header('Cache-Control','no-store');h.end_headers()
  while n:
   chunk=r.read(min(n,65536))
   if not chunk:break
   h.wfile.write(chunk);n-=len(chunk)
 except (OSError,ValueError,http.client.HTTPException):
  if not started:h.hub_reply({'error':'建图后台暂不可达，请查看服务状态'},502)
  else:h.close_connection=True
 finally:conn.close()
 return True

'use strict';
(()=>{
 const root=document.querySelector('.map-module');if(!root)return;
 const panel=document.createElement('section');panel.className='operation-card wide';panel.id='map-pipeline';
 panel.style.cssText='margin:16px 0;padding:18px;border:1px solid var(--border,#cad7e2);border-radius:12px;background:var(--card,#fff);color:var(--text,#23384d)';
 panel.innerHTML='<h2>原建图 → 导航与语义 · 彩色点云 → VR</h2><p data-active>读取场景绑定…</p><p>每次建图的首个有效底盘中心 O 为本场原点，出发车头方向为原始朝向。新地图中为 (0, 0)、0°。结束后直接复用原建图点云与轨迹生成导航地图（10 cm／最高5 Hz），同场 RGB-D 独立生成语义（2 Hz关键帧）供千问使用。VR全量和5 cm轻量彩色点云另行处理，互不等待；原始数据完整保留。生成与选中地图均不会让车移动。</p><div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center"><label>导航场景 <select data-scenes aria-label="导航场景"></select></label><button data-build>生成／重试导航地图</button><button data-semantic>生成／重试本场语义</button><button data-select>使用此场景</button><a href="/monitor-navigation.html">定位与导航</a><a href="/monitor-tasks.html">千问任务</a><button data-reload hidden>刷新为当前场景</button></div><p data-resource-summary></p><p data-progress></p><div data-branches style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px"><p data-nav-progress></p><p data-sem-progress></p><p data-vr-progress></p></div><p data-message role="status"></p>';
 root.prepend(panel);
 if(root.dataset.module==='navigation'){
   const active=panel.querySelector('[data-active]');
   const details=document.createElement('details');details.className='pipeline-details';const summary=document.createElement('summary');summary.textContent='切换地图 / 生成状态';details.append(summary);
   for(const node of [...panel.children])if(node!==active)details.append(node);
   panel.append(details);active.className='pipeline-active';
 }

 const placeId=document.getElementById('place-id'),placeLabel=document.getElementById('place-label');
 if(placeId?.value==='origin'){placeId.value='waypoint_1';if(placeLabel)placeLabel.value='自定义地点1';const b=document.getElementById('record-place');if(b)b.textContent='记录当前位置为自定义地点';}
 const el=s=>panel.querySelector(s),select=el('[data-scenes]');let busy=false,lastActive,rows=[],loaded=false;
 const names={ready:'导航地图已生成',building_navigation:'正在生成导航地图',failed:'生成失败',active:'已选中',awaiting_selection:'已生成，待切换',launch_failed:'启动失败',needs_review:'待复核',waiting_for_mapping_stop:'等待原建图结束',extracting_online_geometry:'提取导航轻量几何',queued:'已排队',waiting_for_rgbd_stop:'等待RGB-D结束',building_semantics:'YOLO与深度融合中',complete:'完成',dense_replay:'VR全量重放中',coloring_dense:'VR全量着色中',deriving_light_5cm:'派生VR轻量版',packaging_vr_dense_and_light:'VR分块打包中'};
 async function api(path,body){let r=await fetch('/api/v1/long-capture/'+path,{cache:'no-store',signal:AbortSignal.timeout(65000),...(body?{method:'POST',headers:{'Content-Type':'application/json','X-Hub-Client':'console'},body:JSON.stringify(body)}:{})});let d=await r.json();if(!r.ok)throw Error(d.error||r.status);return d;}
 function detail(){const row=rows.find(r=>r.session===select.value),p=row?.pipeline||{},v=p.validation;el('[data-build]').disabled=busy||!row?.geometry_ready||p.state==='building_navigation';el('[data-semantic]').disabled=busy||p.state!=='ready'||['building_semantics','queued','waiting_for_rgbd_stop'].includes(row?.semantic?.state);el('[data-select]').disabled=busy||p.state!=='ready'||!v?.origin_rectangle_clear||!row?.offline_passed;
 el('[data-progress]').textContent=row?`${row.session} · ${names[p.state]||(row.geometry_ready?'原建图录包就绪，可直接派生':'等待原建图录包关闭')} ${p.progress!==undefined?Math.round(p.progress*100)+'%':''}${p.error?' · '+p.error:''}${v?' · 配对 '+v.paired_frames+' 帧；起点车身检查 '+(v.origin_rectangle_clear?'通过':'待检查'):''}。语义对象按本场同源数据加载，未完成时不借用旧场景对象。`:'';
 const g=row?.geometry||{},m=row?.semantic||{},c=row?.color||{};
 el('[data-nav-progress]').textContent='导航几何（无颜色） · '+(names[g.state]||g.state||'尚未生成')+(g.points?' · '+g.points.toLocaleString()+' 点':'')+' · 不等待VR着色';
 el('[data-sem-progress]').textContent='语义 → 千问 · '+(names[m.state]||m.state||'等待导航几何')+(m.total?' · '+m.processed+'/'+m.total+' 帧':'')+(m.objects!==undefined?' · '+m.objects+' 个历史物体':'')+(m.error?' · '+m.error:'');
 el('[data-vr-progress]').textContent='VR全量＋5 cm轻量 · '+(names[c.state]||c.state||'待处理')+(c.error?' · '+c.error:'')+' · 不用于导航位姿'+(row?.resources?.backend?' · 着色后端 '+row.resources.backend:'');
 }
 async function refresh(){if(busy||document.hidden)return;try{const d=await api('navigation');rows=d.sessions;el('[data-resource-summary]').textContent=d.acceleration?.approved?'GPU着色已通过离线验证：最多2个ROCm工作进程，资源不足回退CPU；导航与语义各自排队，优先于VR后台处理。':'';const chosen=select.value;select.replaceChildren();for(const r of rows){let o=document.createElement('option');o.value=r.session;o.textContent=r.session+' · '+(names[r.pipeline?.state]||(r.geometry_ready?'可生成':'等待几何'));select.append(o);}if(rows.some(r=>r.session===chosen))select.value=chosen;else if(d.active)select.value=d.active.session;
 el('[data-active]').textContent=d.active?`当前导航与千问场景：${d.active.session} · 原点 (0, 0) m · 原始朝向 0°。当前车位需要实时定位，不自动假定在原点。`:'当前使用历史导航场景；选择一场新建图即可绑定其出发原点。';
 if(loaded&&lastActive!==d.active?.map_revision){el('[data-reload]').hidden=false;el('[data-message]').textContent='场景已切换。请刷新当前页载入新地图；旧路线和任务不能跨地图执行。';}lastActive=d.active?.map_revision;loaded=true;detail();}catch(e){el('[data-message]').textContent=e.message;}}
 async function act(action){busy=true;detail();el('[data-message]').textContent='正在提交…';try{const r=await api(action,{session:select.value});el('[data-message]').textContent=action==='navigation-build'?'原建图导航派生已启动，随后自动补算语义；不等待VR着色。':action==='semantic-build'?'本场语义独立处理已启动，完成后千问读取新版本；已有任务需重新生成。':'场景已选中，导航保持停止；请刷新地图并初始化当前车位。';if(action==='navigation-select')el('[data-reload]').hidden=false;}catch(e){el('[data-message]').textContent=e.message;}finally{busy=false;refresh();}}
 select.onchange=detail;el('[data-build]').onclick=()=>act('navigation-build');el('[data-semantic]').onclick=()=>act('semantic-build');el('[data-select]').onclick=()=>act('navigation-select');el('[data-reload]').onclick=()=>location.reload();refresh();setInterval(refresh,5000);
})();

"""Measured indoor floor model, used for height classification, never map XY warping."""
import numpy as np
from scipy.spatial import cKDTree

def fit_ground_plane(xyz, H, base, chassis_height=.44, reasons=None):
    # The sampling is only for estimating three plane coefficients. Every recorded
    # geometry frame is still processed for occupancy and preserved unmodified.
    stride=max(1,len(xyz)//1200000)
    p=np.asarray(xyz[::stride],dtype=float)@H[:3,:3].T+H[:3,3]
    valid=np.isfinite(p).all(1)
    if reasons is not None: valid &= reasons[::stride]==0
    p=p[valid]
    distance,idx=cKDTree(base[:,:2,3]).query(p[:,:2])
    seed=p[(distance<1.)&(np.abs(p[:,2]-(base[idx,2,3]-chassis_height))<.13)]
    # Equal spatial weight avoids the stationary start dominating the estimate.
    _,ix=np.unique(np.floor(seed/.04).astype(np.int32),axis=0,return_index=True)
    seed=seed[ix]
    if len(seed)<500: raise ValueError('Insufficient directly observed floor for navigation')
    rng=np.random.default_rng(31)
    sample=seed[rng.choice(len(seed),min(20000,len(seed)),replace=False)]
    A=np.c_[sample[:,:2],np.ones(len(sample))];best=None
    for _ in range(220):
        idx=rng.choice(len(sample),3,replace=False)
        try: c=np.linalg.solve(A[idx],sample[idx,2])
        except np.linalg.LinAlgError: continue
        if np.linalg.norm(c[:2])>np.tan(np.deg2rad(8)):continue
        mask=np.abs(A@c-sample[:,2])<.05;score=int(mask.sum())
        if best is None or score>best[0]:best=(score,c)
    if best is None:raise ValueError('No plausible floor plane')
    c=best[1];A=np.c_[seed[:,:2],np.ones(len(seed))]
    for _ in range(5):
        mask=np.abs(A@c-seed[:,2])<.06
        c=np.linalg.lstsq(A[mask],seed[mask,2],rcond=None)[0]
    err=np.abs(A@c-seed[:,2]);inliers=err<.06
    span=np.ptp(seed[inliers,:2],axis=0)
    if inliers.mean()<.55 or span.min()<.8 or np.linalg.norm(c[:2])>np.tan(np.deg2rad(8)):
        raise ValueError('Floor plane lacks support; do not publish navigation automatically')
    return c,dict(method='robust_observed_floor_seeded_by_chassis_height',coefficients_z_ax_by_c=c.tolist(),
        seed_points=len(seed),inlier_points=int(inliers.sum()),inlier_fraction=float(inliers.mean()),
        residual_p95_m=float(np.quantile(err[inliers],.95)),span_xy_m=span.tolist(),
        coordinate_tilt_deg=float(np.degrees(np.arctan(np.linalg.norm(c[:2])))),
        coordinate_frame_unchanged=True,not_physical_floor_slope_measurement=True)

def relative_height(points, plane):
    return points[:,2]-(points[:,:2]@plane[:2]+plane[2])

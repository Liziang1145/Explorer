"""Map publication orchestration. No robot commands; switch only through hub interlock."""
import argparse, hashlib, json, os, re, subprocess, time, fcntl
from pathlib import Path
from urllib.request import Request, build_opener, ProxyHandler
from urllib.error import HTTPError
ROOT=Path(__file__).resolve().parent
SESSIONS=Path('/home/apex/long_capture/sessions')
ACTIVE=Path('/home/apex/navigation_native/run/active-map.json')
PY='/home/apex/.local/opt/navigation-plan-venv/bin/python'
os.environ.setdefault('XDG_RUNTIME_DIR',f'/run/user/{os.getuid()}')
os.environ.setdefault('DBUS_SESSION_BUS_ADDRESS',f'unix:path=/run/user/{os.getuid()}/bus')

def read(p,default=None):
    try:return json.loads(Path(p).read_text())
    except (OSError,ValueError):return default

def atomic(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_name(p.name+'.'+str(os.getpid())+'.tmp')
    with tmp.open('w') as f:
        json.dump(d,f,ensure_ascii=False,allow_nan=False,indent=2);f.flush();os.fsync(f.fileno())
    tmp.replace(p)

def session(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{8}T\d{6}Z-[a-f0-9]{8}',value):raise ValueError('采集会话无效')
    p=(SESSIONS/value).resolve()
    if p.parent!=SESSIONS or not (p/'session.json').is_file():raise ValueError('采集会话不存在')
    return p

def http(path,body=None,port=8130):
    url=f'http://127.0.0.1:{port}'+path
    req=Request(url,None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json','Origin':f'http://127.0.0.1:{port}','X-Hub-Client':'console'})
    try:
        with build_opener(ProxyHandler({})).open(req,timeout=40) as r:return json.load(r)
    except HTTPError as e:
        try:message=json.loads(e.read(65536)).get('error',str(e))
        except Exception:message=str(e)
        raise ValueError(message) from None

def publication(value):
    s=session(value);state=read(s/'navigation-pipeline.json',{})
    if state.get('state')!='ready':raise ValueError('导航派生尚未通过文件和坐标检查')
    p=Path(state['release']).resolve()
    if p.parent!=s/'navigation' or not re.fullmatch('[a-f0-9]{16}',p.name):raise ValueError('导航产物路径无效')
    result=read(p/'pipeline-manifest.json');manifest=read(p/'manifest.json')
    if not result or not manifest or result['map_revision']!=state['map_revision']:raise ValueError('导航发布清单不一致')
    for name,expected in manifest['sha256'].items():
        if name not in ('map.npz','reference.npz','replay.npz','replay.json'):raise ValueError('不支持的地图文件')
        if hashlib.sha256((p/name).read_bytes()).hexdigest()!=expected:raise ValueError('地图文件校验失败')
    vehicle_hash=hashlib.sha256((p/'vehicle.json').read_bytes()).hexdigest()
    map_hash=hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest()
    revision=hashlib.sha256((map_hash+':'+vehicle_hash).encode()).hexdigest()
    if revision!=result['map_revision']:raise ValueError('车身配置或地图清单已改变')
    if not result['validation'].get('origin_rectangle_clear'):raise ValueError('出发点矩形车身检查未通过，需复核地图')
    checks=read(p/'offline-checks.json',{})
    if checks.get('pass') is not True:raise ValueError('离线定位／路线检查尚未通过；地图产物保留等待复核')
    return dict(schema='apex-active-map/1',session=s.name,map=str(p),vehicle_file=str(p/'vehicle.json'),map_epoch=result['map_epoch'],map_revision=revision,home=result['home'],capture_started_s=read(s/'session.json').get('started_unix_s',result['home']['recorded_s']),selected_s=time.time(),auto_motion=False)

def activate_locked(value,automatic=False):
    """Caller MUST hold RouteGateway.lock, revoke tokens and latch navigation first."""
    target=publication(value);old=read(ACTIVE)
    if old and old.get('map_revision')==target['map_revision']:return dict(active=old,changed=False)
    if automatic and old and old.get('session','')>target['session']:raise ValueError('较新的场景已经选中；旧场景完成不自动覆盖')
    atomic(ACTIVE,target)
    try:
        subprocess.run(['systemctl','--user','restart','aipc-navigation-plan.service'],check=True,timeout=30)
        deadline=time.monotonic()+25
        while True:
            try:
                n=http('/navigation/api/status',port=8140)
                if n['map_revision']==target['map_revision'] and n['live'] is None:break
            except Exception:pass
            if time.monotonic()>deadline:raise ValueError('新地图服务未就绪，已回滚原地图选择')
            time.sleep(.3)
    except Exception:
        if old:atomic(ACTIVE,old)
        else:ACTIVE.unlink(missing_ok=True)
        subprocess.run(['systemctl','--user','restart','aipc-navigation-plan.service'],timeout=30)
        raise
    atomic(session(value)/'navigation-publication.json',dict(state='active',active=target,motion_sent=False,localization='requires_initialization'))
    return dict(active=target,changed=True,motion_sent=False,localization='requires_initialization')

def launch(value):
    s=session(value)
    if not (s/'derived-bag/bag/metadata.yaml').is_file():raise ValueError('原建图派生录包尚未关闭，不等待彩色点云')
    unit='map-nav-'+s.name.lower()
    if subprocess.run(['systemctl','--user','is-active','--quiet',unit]).returncode==0:return dict(state='running',unit=unit)
    r=subprocess.run(['systemd-run','--user','--collect','--unit='+unit,'-p','Nice=5','-p','CPUWeight=200','-p','CPUQuota=200%','-p','Environment=OPENBLAS_NUM_THREADS=2','/bin/bash','-c','source /home/apex/mapping_native/env.sh; exec '+PY+' '+str(ROOT/'pipeline_manager.py')+' --run '+s.name],capture_output=True,text=True)
    if r.returncode:raise ValueError(r.stderr.strip())
    return dict(state='started',unit=unit,motion_sent=False)

def launch_semantics(value):
    s=session(value);p=read(s/'navigation-pipeline.json',{})
    if p.get('state')!='ready':raise ValueError('请先生成本场导航地图与轨迹')
    unit='map-semantic-'+s.name.lower()
    if subprocess.run(['systemctl','--user','is-active','--quiet',unit]).returncode==0:return dict(state='running',unit=unit)
    import shlex
    cmd=['/home/apex/.local/opt/vision-yolo-venv/bin/python',str(ROOT/'semantic_pipeline.py'),str(s),p['release'],'--wait']
    r=subprocess.run(['systemd-run','--user','--collect','--unit='+unit,'-p','Nice=10','-p','CPUWeight=50','-p','CPUQuota=200%','-p','MemoryHigh=4G','-p','MemoryMax=6G','-p','Environment=OPENBLAS_NUM_THREADS=2','-p','Environment=OMP_NUM_THREADS=2',*cmd],capture_output=True,text=True)
    if r.returncode:raise ValueError(r.stderr.strip())
    atomic(s/'semantic-pipeline.json',dict(state='queued',unit=unit,navigation_independent=True,raw_preserved=True))
    return dict(state='started',unit=unit,motion_sent=False)

def run(value,activate=True):
    with (ROOT/'navigation-processing.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        return run_locked(value,activate)

def run_locked(value,activate=True):
    s=session(value)
    from navigation_geometry import extract
    try:
        extract(s)
        subprocess.run([PY,str(ROOT/'build_pipeline.py'),str(s)],check=True)
    except Exception as e:
        atomic(s/'navigation-publication.json',dict(state='validation_failed',error=str(e),motion_sent=False,raw_preserved=True));raise
    # Independently scheduled; semantic failure never prevents nav validation.
    try:launch_semantics(value)
    except Exception as e:atomic(s/'semantic-pipeline.json',dict(state='launch_failed',error=str(e),raw_preserved=True))
    try:subprocess.run([PY,str(ROOT/'validate_release.py'),str(s)],check=True)
    except Exception as e:
        atomic(s/'navigation-publication.json',dict(state='validation_failed',error=str(e),motion_sent=False,raw_preserved=True));raise
    if not activate:
        atomic(s/'navigation-publication.json',dict(state='awaiting_selection',offline_only=True,motion_sent=False));return
    try:http('/hub/api/maps/activate',dict(session=value,automatic=True))
    except Exception as e:atomic(s/'navigation-publication.json',dict(state='awaiting_selection',error=str(e),motion_sent=False))

def status():
    rows=[]
    for s in sorted(SESSIONS.glob('*'),reverse=True):
        if not (s/'session.json').is_file():continue
        if not re.fullmatch(r'\d{8}T\d{6}Z-[a-f0-9]{8}',s.name):continue
        pipeline=read(s/'navigation-pipeline.json',{})
        checks=read(Path(pipeline['release'])/'offline-checks.json',{}) if pipeline.get('release') else {}
        rows.append(dict(session=s.name,geometry_ready=(s/'derived-bag/bag/metadata.yaml').exists(),geometry=read(s/'navigation-geometry-progress.json',{}),semantic=read(s/'semantic-pipeline.json',{}),color=read(s/'dual-products-progress.json',{}),resources=read(s/'color-resource-policy.json',{}),products=read(s/'colored-products.json',{}),pipeline=pipeline,offline_passed=checks.get('pass',False),publication=read(s/'navigation-publication.json',{})))
    return dict(active=read(ACTIVE),sessions=rows,acceleration=read('/home/apex/research/fisheye_mapping_20261030/gpu-parallel-benchmark.json',{}),automatic_motion=False,origin_policy='first_valid_chassis_O_pose',heading_policy='mapping_start_chassis_forward')

if __name__=='__main__':
    p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group(required=True);g.add_argument('--launch');g.add_argument('--run');g.add_argument('--semantic');p.add_argument('--offline',action='store_true');g.add_argument('--status',action='store_true');a=p.parse_args()
    if a.launch:print(json.dumps(launch(a.launch),ensure_ascii=False))
    elif a.run:run(a.run,activate=not a.offline)
    elif a.semantic:print(json.dumps(launch_semantics(a.semantic),ensure_ascii=False))
    else:print(json.dumps(status(),ensure_ascii=False))

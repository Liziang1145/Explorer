"""Recorded RGB-D -> same-online-trajectory objects -> map-bound Qwen evidence.

No ROS publishing or robot I/O. Durable per-frame caches; bad frames are recorded,
not a reason to stop raw acquisition, navigation, or the independent VR branch.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2');os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import argparse,hashlib,json,math,sys,time,zlib,shutil,fcntl
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/apex/semantic_mapping')
from fusion_core import load_calibration,PoseBuffer,fuse_frame,GateError
from instance_quality import dense_component
from lidar_semantics import ObjectMemory
from navigation_geometry import atomic,digest

MODEL=Path('/home/apex/vision_yolo/models/yolo26m-seg.pt')
LABELS={'chair':'椅子','bench':'长凳','dining table':'桌子','cup':'杯子','bottle':'瓶子','tv':'显示屏','laptop':'笔记本电脑','keyboard':'键盘','mouse':'鼠标','book':'书','potted plant':'盆栽','sink':'水槽','refrigerator':'冰箱','backpack':'背包','suitcase':'箱子'}

def paired_frames(s,hz):
    rows=[json.loads(x) for x in (s/'rgbd/index.jsonl').read_text().splitlines() if x.strip()]
    offsets={};depths={};stamps={}
    for e in sorted({r['stream_epoch'] for r in rows}):
        rr=[r for r in rows if r['stream_epoch']==e]
        offsets[e]=float(np.percentile([r['received_unix_ns']/1e9-r['meta']['device_timestamp_us']/1e6 for r in rr],5))
        depths[e]=sorted([r for r in rr if r['kind']=='depth'],key=lambda r:r['meta']['device_timestamp_us'])
        stamps[e]=np.array([r['meta']['device_timestamp_us']/1e6 for r in depths[e]])
    pairs=[];last=-math.inf;used=set();rejected=0;camera_count=0;sampled_out=0
    for c in sorted([r for r in rows if r['kind']=='camera'],key=lambda r:r['received_unix_ns']):
        camera_count+=1;e=c['stream_epoch'];tc=c['meta']['device_timestamp_us']/1e6+offsets[e]
        if hz and tc-last<1/hz-1e-5:sampled_out+=1;continue
        ts=stamps[e]
        if not len(ts):rejected+=1;continue
        j=int(np.searchsorted(ts,tc-offsets[e]));j=min([max(0,j-1),min(j,len(ts)-1)],key=lambda k:abs(ts[k]+offsets[e]-tc))
        d=depths[e][j];td=ts[j]+offsets[e]
        if abs(tc-td)>.05 or (e,d['index']) in used:rejected+=1;continue
        pairs.append((c,d,tc,float(td)));last=tc;used.add((e,d['index']))
    return pairs,dict(recorded_rgb_frames=camera_count,selected_pairs=len(pairs),rate_sampled_frames=sampled_out,rejected_pairs=rejected,semantic_hz=hz,device_to_host_offset=offsets,hardware_sync=False,point_limit=None,frame_limit=None)

def read_verified(s,rec):
    root=(s/'rgbd').resolve();p=(root/rec['file']).resolve()
    if not p.is_relative_to(root):raise ValueError('RGB-D path escapes session')
    b=p.read_bytes()
    if hashlib.sha256(b).hexdigest()!=rec['sha256']:raise ValueError('RGB-D checksum mismatch')
    return b

def pose_window(history,stamps,tc,td,epoch):
    lo=max(0,int(np.searchsorted(stamps,min(tc,td)))-1);hi=min(len(history),int(np.searchsorted(stamps,max(tc,td)))+2)
    p=PoseBuffer(epoch)
    for r in history[lo:hi]:p.add(r['stamp'],r['position'],r['quaternion'],epoch)
    return p

def transform_scene(scene,H,map_revision,scene_revision,observations):
    import itertools
    def tx(p):return (np.asarray(p)@H[:3,:3].T+H[:3,3]).tolist()
    objects=[]
    for raw in scene['objects']:
        o=dict(raw);o['center_m']=tx(raw['center_m']);b=raw['bounds_m']
        corners=np.asarray([tx(p) for p in itertools.product(*[(b[i],b[i+3]) for i in range(3)])])
        o['bounds_m']=np.r_[corners.min(0),corners.max(0)].tolist();o['label_zh']=LABELS.get(o['label'],o['label'])
        o['evidence_ids']=['obs_'+f for f in o['evidence_frames'] if 'obs_'+f in observations]
        o['review']={'status':'unreviewed','note':'YOLO与深度的历史候选；不是人工确认'};objects.append(o)
    by_id={o['id']:o for o in objects};relations=[]
    for raw in scene['relations']:
        a=by_id[raw['subject']];b=by_id[raw['object']]
        gap=np.maximum(0,np.maximum(np.asarray(a['bounds_m'][:2])-b['bounds_m'][3:5],np.asarray(b['bounds_m'][:2])-a['bounds_m'][3:5]))
        relations.append(dict(raw,gap_xy_m=float(np.linalg.norm(gap))))
    return dict(schema='semantic-evidence-graph/1',map_epoch=scene['map_epoch'],map_revision=map_revision,scene_revision=scene_revision,frame='nav_map_candidate',synthetic=False,recorded_end_s=scene['source_stamp'],objects=objects,relations=relations,observations=list(observations.values()),open_observations=[],visibility_evidence=[],spatial_topology={},limitations=scene['limitations'])

def run(s,release,hz=2.,validation_frames=0):
    import cv2
    cv2.setNumThreads(1)
    s=Path(s);release=Path(release);manifest=json.loads((release/'manifest.json').read_text());pipeline=json.loads((release/'pipeline-manifest.json').read_text())
    geometry=Path(manifest['geometry_source']);epoch=str(manifest['map_epoch'])
    if Path(manifest['capture_session']).resolve()!=s.resolve():raise ValueError('Navigation/session mismatch')
    branch=json.loads((s/'rgbd/status.json').read_text())
    if branch.get('state')!='stopped':raise ValueError('RGB-D未正常结束，保留已有地图等待补算')
    pairs,policy=paired_frames(s,hz)
    cfg=s/'config';cal=load_calibration(cfg/'calibration',json.loads((cfg/'body_from_lidar.json').read_text()),allow_provisional=True)
    identity=hashlib.sha256(json.dumps(dict(index=digest(s/'rgbd/index.jsonl'),poses=digest(geometry/'poses.jsonl'),model=digest(MODEL),calibration=cal.provenance,policy=policy,code=digest(__file__),map_revision=pipeline['map_revision']),sort_keys=True).encode()).hexdigest()
    out=s/('semantic-validation' if validation_frames else 'semantic-products')/identity[:16];out.mkdir(parents=True,exist_ok=True)
    state=s/('semantic-validation-progress.json' if validation_frames else 'semantic-pipeline.json')
    if not validation_frames and (out/'complete.json').exists():
        done=json.loads((out/'complete.json').read_text());atomic(state,done);return done
    history=[json.loads(x) for x in (geometry/'poses.jsonl').read_text().splitlines()];stamps=np.array([r['stamp'] for r in history])
    # ObjectMemory's per-object history is bounded; do not impose a total object cap.
    memory=ObjectMemory(epoch,max_objects=float('inf'));cache=out/'frames';cache.mkdir(exist_ok=True)
    model=None;classes=None;good=bad=instances=0;started=time.monotonic();processed=[];errors=[]
    work=pairs[:validation_frames] if validation_frames else pairs
    for number,(c,d,tc,td) in enumerate(work):
        key=f'{c["index"]:09d}';record=cache/(key+'.json');arrays=cache/(key+'.npz')
        try:
            if record.exists() and arrays.exists():
                rec=json.loads(record.read_text());a=np.load(arrays);fused={k:a[k] for k in a.files};fused['metadata']=rec['metadata'];classes=rec['classes']
            else:
                pb=pose_window(history,stamps,tc,td,epoch);pb.at(tc,epoch,.25);pb.at(td,epoch,.25)
                color=cv2.imdecode(np.frombuffer(read_verified(s,c),np.uint8),cv2.IMREAD_COLOR)
                dep=np.frombuffer(zlib.decompress(read_verified(s,d)),dtype='<u2').reshape(d['meta']['height'],d['meta']['width'])
                if color is None:raise ValueError('RGB decode failed')
                if model is None:
                    os.environ.update(YOLO_OFFLINE='true',YOLO_AUTOINSTALL='false',YOLO_CONFIG_DIR='/home/apex/vision_yolo/settings')
                    import torch
                    torch.set_num_threads(2)
                    from ultralytics import YOLO
                    model=YOLO(str(MODEL),task='segment')
                classes=[dict(id=int(k),name=v) for k,v in model.names.items()]
                prediction=model.predict(color,device='cpu',imgsz=640,conf=.45,retina_masks=True,verbose=False)[0]
                detections=[]
                if prediction.masks is not None:
                    for i,(mask,box) in enumerate(zip(prediction.masks.data.cpu().numpy(),prediction.boxes)):
                        detections.append(dict(mask=mask>.5,class_id=int(box.cls.item()),confidence=float(box.conf.item()),instance_id=i))
                fused=fuse_frame(dep,color[:,:,::-1],detections,cal,pb,epoch=epoch,color_stamp_s=tc,depth_stamp_s=td,now_s=max(tc,td),allow_approximate_sync=True,depth_scale_mm=d['meta'].get('scale_mm',1.),stride=4,max_pose_gap_s=.25,frame_id=key)
                if fused['metadata']['state']!='fused':raise ValueError('; '.join(fused['metadata']['blocking_reasons']))
                keep=np.zeros(len(fused['points_map']),bool)
                for iid in set(fused['instance_ids'].tolist()):
                    if iid<0:continue
                    ids=np.flatnonzero((fused['instance_ids']==iid)&~fused['dynamic'])
                    if len(ids):keep[ids[dense_component(fused['points_map'][ids])]]=True
                fused={k:(fused[k][keep] if k!='metadata' else fused[k]) for k in ['points_map','class_ids','instance_ids','dynamic','metadata']}
                tmp=arrays.with_suffix('.tmp')
                with tmp.open('wb') as f:np.savez_compressed(f,**{k:v for k,v in fused.items() if k!='metadata'})
                tmp.replace(arrays);rec=dict(metadata=fused['metadata'],classes=classes,rgb=c,depth=d,coordinate_source=str(geometry));atomic(record,rec)
            if td<=memory.last_stamp:raise ValueError('Non-increasing semantic depth time')
            assigned=memory.update(fused,key);instances+=len(assigned);good+=1;processed.append((key,c,tc))
        except (ValueError,OSError,KeyError,GateError,zlib.error) as e:
            bad+=1;errors.append(dict(frame=key,error=str(e)));atomic(cache/(key+'.error.json'),errors[-1])
        if number%10==0 or number==len(work)-1:
            atomic(state,dict(state='building_semantics',processed=number+1,total=len(work),accepted_frames=good,rejected_frames=bad,objects=len(memory.objects),seconds=time.monotonic()-started,policy=policy,geometry_source=str(geometry),raw_preserved=True,navigation_independent=True));print('semantic',number+1,len(work),good,len(memory.objects),flush=True)
    if not good:raise ValueError('没有通过同源位姿/深度检查的语义帧；原点导航保持独立')
    if bad/max(1,len(work))>.2:raise ValueError('超过20%所选语义帧失败，保留候选，待复核后发布')
    scene=memory.document(classes or [],identity,float(stamps[-1]));scene.update(incomplete=False,semantic_available=True,source_session=str(s),geometry_source=str(geometry),model_sha256=digest(MODEL),policy=policy,historical=True)
    for o in scene['objects']:o['bounds_kind']='robust_connected_RGBD_visible_surface_not_full_object'
    scene['limitations']+=['来自记录RGB-D与同场在线FAST-LIO轨迹；非实时物体位置','RGB-D按设备时间配对，设备至主机时间偏移为估计，未硬件同步','鱼眼仅补充VR着色；本版物体语义由RGB-D提供','多帧确认不代表人工真值；抓取仍需当前观察及独立标定']
    evidence=out/'evidence';evidence.mkdir(exist_ok=True);scene['evidence_directory']=str(evidence)
    atomic(out/'scene.json',scene);refs={f for o in scene['objects'] for f in o['evidence_frames']};observations={}
    for key,c,tc in processed:
        if key not in refs:continue
        dst=evidence/(key+'.jpg')
        if not dst.exists():
            img=cv2.imdecode(np.frombuffer(read_verified(s,c),np.uint8),cv2.IMREAD_COLOR)
            cv2.imwrite(str(dst),cv2.resize(img,(640,360)),[cv2.IMWRITE_JPEG_QUALITY,85])
        oid='obs_'+key;observations[oid]=dict(id=oid,frame_id=key,image=dst.name,stamp_s=tc,source='recorded_RGBD',source_rgb=c['file'],source_sha256=c['sha256'],calibration_status='engineering_calibration',hardware_time_sync_verified=False)
    graph=transform_scene(scene,np.array(manifest['transform_nav_from_saved']),pipeline['map_revision'],digest(out/'scene.json'),observations)
    atomic(evidence/'graph.json',graph)
    # Atomic scene switch follows complete evidence; no transient mixed graph/scene.
    if not validation_frames:atomic(release/'scene.json',scene)
    done=dict(state='complete',session=s.name,release=str(release),product=str(out),objects=len(scene['objects']),confirmed_objects=sum(o['state']=='confirmed' for o in scene['objects']),relations=len(scene['relations']),accepted_frames=good,rejected_frames=bad,seconds=time.monotonic()-started,policy=policy,map_revision=pipeline['map_revision'],scene_revision=digest(out/'scene.json'),validation_only=bool(validation_frames),raw_preserved=True,motion_sent=False)
    atomic(out/'complete.json',done);atomic(state,done);return done

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('session');p.add_argument('release');p.add_argument('--hz',type=float,default=2.);p.add_argument('--validation-frames',type=int,default=0);p.add_argument('--wait',action='store_true');a=p.parse_args()
    if not 0<=a.hz<=15 or a.validation_frames<0:p.error('invalid rate/count')
    try:
        if a.wait:
            sys.path.insert(0,'/home/apex/long_capture')
            from session_status import describe
            while True:
                branch=describe(Path(a.session))['branches'].get('rgbd',{})
                if not branch.get('alive'):
                    if branch.get('state')!='stopped':raise ValueError('RGB-D需要恢复；导航不受影响')
                    break
                atomic(Path(a.session)/'semantic-pipeline.json',dict(state='waiting_for_rgbd_stop',raw_preserved=True));time.sleep(5)
        atomic(Path(a.session)/('semantic-validation-progress.json' if a.validation_frames else 'semantic-pipeline.json'),dict(state='queued',reason='waiting_for_semantic_slot',raw_preserved=True))
        with (Path(__file__).parent/'semantic-processing.lock').open('w') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            print(json.dumps(run(a.session,a.release,a.hz,a.validation_frames),ensure_ascii=False))
    except Exception as e:
        atomic(Path(a.session)/('semantic-validation-progress.json' if a.validation_frames else 'semantic-pipeline.json'),dict(state='needs_review',error=str(e),raw_preserved=True,navigation_independent=True,motion_sent=False));raise

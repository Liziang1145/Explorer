"""Exercise actual navigation consumers against saved data; never opens motor APIs."""
import sys,json,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'navigation_native'),'/home/apex/navigation_native','/home/apex/mapping_dashboard']
from nav_server import Workbench
from nav_core import save_json
s=Path(sys.argv[1]);p=Path(json.loads((s/'navigation-pipeline.json').read_text())['release'])
w=Workbench(p,vehicle_file=p/'vehicle.json');out=dict(source=str(p),hardware_commands_sent=False,localization=[],routes=[])
for f in (w.replays[0],w.replays[-1]):
 start=time.monotonic();r=w.command('replay',dict(map_epoch=w.map.meta['map_epoch'],map_revision=w.revision,id=f['id']))
 expected=np.asarray(f['recorded_map_from_body']);candidate=np.asarray(r['diagnostic_candidate'])
 out['localization'].append(dict(scan=f['id'],accepted=r['accepted'],overlap=r['overlap_20cm'],rmse_m=r['inlier_rmse_m'],distance_from_recorded_m=float(np.linalg.norm(candidate[:3,3]-expected[:3,3])),seconds=time.monotonic()-start,not_external_ground_truth=True))
history=w.base_history;distance=np.linalg.norm(history[:,:2,3],axis=1)
ids=np.argsort(distance)[::-1][::max(1,len(history)//40)]
for j in ids:
 goal=history[j,:2,3].tolist()
 if not w.rectangle.clear_pose([*goal,float(np.arctan2(history[j,1,0],history[j,0,0]))]):continue
 try:
  r=w.rectangle.plan([0.,0.],goal,0.,max_seconds=12)
  out['routes'].append(dict(goal=goal,success=True,result=r));break
 except ValueError as e:out['routes'].append(dict(goal=goal,success=False,error=str(e)))
 if len(out['routes'])>=4:break
out['pass']=all(r['accepted'] for r in out['localization']) and any(r['success'] for r in out['routes'])
save_json(p/'offline-checks.json',out)
summary=out|dict(routes=[{k:v for k,v in row.items() if k!='result'}|({'length_m':row['result']['length_m']} if 'result' in row else {}) for row in out['routes']])
print(json.dumps(summary,ensure_ascii=False))
if not out['pass']:raise SystemExit('Offline localization / route checks need review')

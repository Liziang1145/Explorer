"""Wait only for existing mapping output; independent of all VR consumers."""
import sys,time,json
from pathlib import Path
sys.path.insert(0,'/home/apex/long_capture')
from session_status import describe
from navigation_geometry import atomic
from pipeline_manager import run

def wait_geometry(s):
    while True:
        d=describe(s);branch=d['branches'].get('derived-bag',{})
        if branch.get('state')=='stopped' and not branch.get('alive'):return
        if branch.get('state') in ('needs_review','interrupted','missing_status'):
            raise ValueError('原建图录包需要恢复；不影响原始录制或VR处理')
        atomic(s/'navigation-publication.json',dict(state='waiting_for_mapping_stop',color_dependency=False,motion_sent=False))
        time.sleep(5)

if __name__=='__main__':
    s=Path(sys.argv[1])
    try:wait_geometry(s);run(s.name)
    except Exception as e:
        atomic(s/'navigation-publication.json',dict(state='needs_review',error=str(e),raw_preserved=True,motion_sent=False));raise

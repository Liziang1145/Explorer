"""Saved dense geometry -> immutable, map-scoped navigation release. No actuator IO."""
import argparse, csv, fcntl, hashlib, json, math, os, shutil, sys, time
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.ndimage import label

NAV=Path('/home/apex/navigation_native')
sys.path[:0]=[str(NAV),'/home/apex/mapping_dashboard']
from nav_core import digest, save_json, transform, voxel, SavedMap
from vehicle_frame import VehicleFrame, yaw_deg, reference_revision
from rectangle_plan import footprint_cells, RectanglePlanner
from offline_nav import GridMap
from ground_model import fit_ground_plane, relative_height

ROOT=Path(__file__).resolve().parent
DEFAULT_VEHICLE=NAV/'measurements/chassis_reference_v2_20261026.json'

def pose_matrix(row):
    q=np.asarray(row['quaternion'],float);p=np.asarray(row['position'],float)
    if q.shape!=(4,) or p.shape!=(3,) or not np.isfinite(np.r_[q,p,row['stamp']]).all() or abs(np.linalg.norm(q)-1)>.01:
        raise ValueError('Invalid recorded pose')
    T=np.eye(4);T[:3,:3]=Rotation.from_quat(q).as_matrix();T[:3,3]=p
    return T

def origin_transform(first_pose,vehicle):
    """O at start = XY zero, chassis forward = yaw zero; Z remains ground-referenced."""
    initial_base=vehicle.map_base(pose_matrix(first_pose))
    H=np.linalg.inv(initial_base)
    H[2,3]+=vehicle.meta['raw']['chassis_top_ground_height_m']
    return H

def write_state(folder,**d):
    save_json(folder/'navigation-pipeline.json',dict(updated_s=time.time(),motion_sent=False,raw_preserved=True,**d))

def build(session):
    s=Path(session).resolve();src=s/'navigation-geometry-v1';meta=json.loads((s/'session.json').read_text())
    if not (src/'ready.json').is_file():raise ValueError('原建图导航几何尚未就绪；不依赖全量着色')
    poses=[json.loads(x) for x in (src/'poses.jsonl').read_text().splitlines() if x.strip()]
    stamps=np.asarray([r['stamp'] for r in poses]);Ts=np.asarray([pose_matrix(r) for r in poses])
    if len(poses)<3 or np.any(np.diff(stamps)<=0):raise ValueError('Recorded pose timestamps not strictly increasing')
    frozen=s/'config/navigation_vehicle.json'
    if not frozen.exists():shutil.copy2(DEFAULT_VEHICLE,frozen)
    v=VehicleFrame(frozen)
    if digest(s/'config/body_from_lidar.json')!=v.meta['body_from_lidar']['source_sha256']:
        raise ValueError('Body/LiDAR calibration does not match frozen vehicle transform')
    # Dense replay filter indices belong to a different point/pose stream.
    reason_file=src/'reasons.npy'
    inputs=[src/'ready.json',src/'geometry_frames.jsonl',src/'poses.jsonl',frozen,Path(__file__),ROOT/'ground_model.py']
    if reason_file.is_file(): inputs.append(reason_file)
    identity=hashlib.sha256(('|'.join(digest(p) for p in inputs)+'pipeline-v3-online-geometry').encode()).hexdigest()
    out=s/'navigation'/identity[:16]
    if (out/'pipeline-manifest.json').is_file():
        d=json.loads((out/'pipeline-manifest.json').read_text());write_state(s,state='ready',**d);return out
    stage=out.with_name(out.name+'.building');stage.mkdir(parents=True,exist_ok=True)
    write_state(s,state='building_navigation',progress=0,release=str(out))
    H=origin_transform(poses[0],v);base=H@Ts@v.body_base
    if np.max(np.degrees(np.arccos(np.clip(base[:,2,2],-1,1))))>15:raise ValueError('Trajectory tilt exceeds flat-floor navigation assumption')
    # Preserve source coordinates; only the navigation view is transformed.
    adapter=stage/'source';(adapter/'audit').mkdir(parents=True,exist_ok=True);(adapter/'config').mkdir(exist_ok=True)
    shutil.copy2(s/'config/body_from_lidar.json',adapter/'config/body_from_lidar.json')
    save_json(adapter/'session.json',dict(source_session=str(s),map_epoch=str(meta['map_epoch']),frame='camera_init'))
    with (adapter/'audit/trajectory.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['stamp_ns','x','y','z','qx','qy','qz','qw'])
        for r in poses:w.writerow([int(round(r['stamp']*1e9)),*r['position'],*r['quaternion']])
    frames=[json.loads(x) for x in (src/'geometry_frames.jsonl').read_text().splitlines() if x.strip()]
    xyz=np.load(src/'xyz.npy',mmap_mode='r');res=.10
    if xyz.ndim!=2 or xyz.shape[1]!=3:raise ValueError('Invalid registered geometry')
    reasons=np.load(reason_file,mmap_mode='r') if reason_file.is_file() else None
    if reasons is not None and reasons.shape!=(len(xyz),): raise ValueError('Static filter / source length mismatch')
    plane,ground_report=fit_ground_plane(xyz,H,base,v.meta['raw']['chassis_top_ground_height_m'],reasons)
    save_json(stage/'ground-model.json',ground_report)
    lo=np.floor((base[:,:2,3].min(0)-12)/res)*res;hi=np.ceil((base[:,:2,3].max(0)+12)/res)*res
    width,height=np.ceil((hi-lo)/res).astype(int);shape=(height,width)
    floor_hits=np.zeros(shape,np.uint32);hit=np.zeros((11,*shape),np.uint32);miss=np.zeros_like(hit)
    references=[];replays={};replay_meta=[];valid_frames=0;skipped=0;floor_values=[]
    def indices(p):
        c=np.floor((p[:,:2]-lo)/res).astype(int)
        return c,(c[:,0]>=0)&(c[:,0]<width)&(c[:,1]>=0)&(c[:,1]<height)
    for i,fr in enumerate(frames):
        j0=int(np.searchsorted(stamps,fr['stamp']));j=min((max(0,j0-1),min(len(stamps)-1,j0)),key=lambda k:abs(stamps[k]-fr['stamp']))
        if abs(stamps[j]-fr['stamp'])>.06:skipped+=1;continue
        origin=transform(np.asarray([v.body_lidar[:3,3]]),H@Ts[j])[0]
        raw=xyz[fr['start']:fr['end']]
        # Exclude recorded dynamic/isolated candidates as occupancy endpoints.
        # Removed returns do not open rays behind themselves.
        if reasons is not None:raw=raw[reasons[fr['start']:fr['end']]==0]
        points=transform(raw,H)
        dist=np.linalg.norm(points-origin,axis=1)
        points=points[np.isfinite(points).all(1)&(dist>.35)&(dist<12)]
        # Navigation-only derived 10 cm voxel evidence. Dense/colored assets are untouched.
        _,ids=np.unique(np.floor(points/res).astype(np.int32),axis=0,return_index=True);points=points[ids]
        c,inside=indices(points);z=relative_height(points,plane)
        floor=inside&(np.abs(z)<.10)
        floor_hits.ravel()[np.unique(c[floor,1]*width+c[floor,0])]+=1
        near=np.linalg.norm(points[:,:2]-base[j,:2,3],axis=1)<1
        floor_values.extend(z[near&(np.abs(z)<.15)].tolist())
        vz=np.floor((z-.10)/res).astype(int);ok=inside&(vz>=0)&(vz<len(hit))
        ids=np.unique((vz[ok]*height+c[ok,1])*width+c[ok,0]);hit.ravel()[ids]+=1
        delta=points-origin;distance=np.linalg.norm(delta,axis=1);clear=[]
        for step in np.arange(.25,min(12.,distance.max(initial=0)),.15):
            good=distance>step+.12
            if not good.any():continue
            sample=origin+delta[good]*(step/distance[good,None]);cc,ii=indices(sample)
            zz=np.floor((relative_height(sample,plane)-.10)/res).astype(int);ii&=(zz>=0)&(zz<len(hit))
            clear.append((zz[ii]*height+cc[ii,1])*width+cc[ii,0])
        if clear:miss.ravel()[np.setdiff1d(np.unique(np.concatenate(clear)),ids,assume_unique=True)]+=1
        ref=points[(z>-.15)&(z<3.5)]
        if i in {len(frames)//4,3*len(frames)//4}:
            key=f'scan_{i:06d}';local=transform(points,np.linalg.inv(H@Ts[j]))
            replays[key]=voxel(local,.12,6000);replay_meta.append(dict(id=key,stamp_s=fr['stamp'],recorded_map_from_body=(H@Ts[j]).tolist(),excluded_from_reference=True))
        else:references.append(ref.astype('float32'))
        if len(references)>80:
            refs=np.concatenate(references);_,ix=np.unique(np.floor(refs/.12).astype(np.int32),axis=0,return_index=True);references=[refs[ix]]
        valid_frames+=1
        if i%100==0:write_state(s,state='building_navigation',progress=round((i+1)/len(frames),4),frames=valid_frames,release=str(out));print(i,len(frames),flush=True)
    if valid_frames<3 or not references or len(floor_values)<100:raise ValueError('Insufficient paired pose / ground observations')
    if skipped/max(1,len(frames))>.1:raise ValueError('Too many unpaired geometry frames')
    score=3*hit.astype(np.int64)-miss
    occupied=((hit>=3)&(score>=6)).any(0);unresolved=((hit>0)&(score>-3)&~((hit>=3)&(score>=6))).any(0)
    ray_bands=np.array([(miss[a:b]>=2).any(0) for a,b in [(0,3),(3,7),(7,11)]])
    cells=np.full(shape,-1,np.int16);cells[(floor_hits>=2)&ray_bands.all(0)&~unresolved]=0;cells[occupied]=100
    sensor_cells=cells.copy();visits=np.zeros(shape,np.uint32)
    # Historical footprint is temporal traversal evidence, never a guarantee of current clearance.
    for j,T in enumerate(base):
        p=np.r_[T[:2,3],math.atan2(T[1,0],T[0,0])];prev=base[max(0,j-1)]
        q=np.r_[prev[:2,3],math.atan2(prev[1,0],prev[0,0])];da=(p[2]-q[2]+math.pi)%(2*math.pi)-math.pi
        if j and (stamps[j]-stamps[j-1]>.25 or np.linalg.norm(p[:2]-q[:2])>.25 or abs(da)>.3):q=p.copy();da=0
        n=max(1,int(np.ceil((np.linalg.norm(p[:2]-q[:2])+.45*abs(da))/.025)))
        for a in np.linspace(0,1,n+1):
            r=np.r_[q[:2]+a*(p[:2]-q[:2]),q[2]+a*da];yy,xx=footprint_cells(shape,lo,res,r);visits[yy,xx]+=1
    cells[visits>0]=0
    refs=np.concatenate(references);_,ids=np.unique(np.floor(refs/.12).astype(np.int32),axis=0,return_index=True);refs=refs[ids]
    np.savez_compressed(stage/'map.npz',cells=cells,trajectory=(H@Ts)[::10,:3,3],ground=floor_hits>0,ray_bands=ray_bands,hit_votes=hit,free_votes=miss,unresolved=unresolved,traversal_samples=visits,sensor_cells=sensor_cells)
    np.savez_compressed(stage/'reference.npz',points=refs);np.savez_compressed(stage/'replay.npz',**replays);save_json(stage/'replay.json',replay_meta)
    epoch=str(meta['map_epoch']);GridMap(int(width),int(height),res,*lo,'nav_map_candidate',epoch,cells.ravel().tolist()).save_map_server_files(stage)
    home=dict(id='origin',label='建图出发原点',xy=[0.,0.],yaw_deg=0.,recorded_s=float(stamps[0]),source='first_valid_recorded_chassis_pose',reference_point='chassis_O',original_heading=True)
    traversal=dict(source='recorded_chassis_footprint',source_trajectory_sha256=digest(adapter/'audit/trajectory.csv'),current_free_space_guaranteed=False,swept_cells=int((visits>0).sum()),occupied_conflicts=int(((visits>0)&(sensor_cells==100)).sum()),conflicts_file='map.npz:sensor_cells')
    manifest=dict(schema='apex-plan-map/1',map_epoch=epoch,frame='nav_map_candidate',source_frame='camera_init',source_session=str(out/'source'),capture_session=str(s),geometry_source=str(src),geometry_policy=json.loads((src/'ready.json').read_text()),source_session_sha256=digest(adapter/'session.json'),trajectory_sha256=digest(adapter/'audit/trajectory.csv'),width=int(width),height=int(height),resolution_m=res,origin_xy_m=lo.tolist(),transform_nav_from_saved=H.tolist(),gravity=dict(source='initial_chassis_measured_mount',level_floor_assumption=False),floor=ground_report|dict(fit_p95_m=float(np.quantile(np.abs(floor_values),.95)),manually_verified=False),height_band_m=[.10,1.20],default_radius_m=.55,planning_model='rectangle_se2_offline_v1',history_traversal=traversal,home=home,semantic_scene_file=str(out/'scene.json'),counts=dict(free=int((cells==0).sum()),occupied=int((cells==100).sum()),unknown=int((cells==-1).sum()),reference_points=len(refs),map_scans=valid_frames,heldout_scans=len(replays)),ground_model=ground_report,static_filter=dict(applied=reasons is not None,source=str(reason_file) if reasons is not None else None),motion_authorized=False,vehicle_calibrated=False,warnings=['每场地图使用首个有效底盘O位姿为出发原点，车头方向为0度。','10 cm栅格仅导航派生；原始几何与全量彩色保留。','当前车位需要实时重定位；默认原点不代表车辆当前在原点。','历史通过证据不是永久无障碍承诺；实时障碍检查仍启用。'],sha256={n:digest(stage/n) for n in ('map.npz','reference.npz','replay.npz','replay.json')})
    save_json(stage/'manifest.json',manifest)
    # Do not reuse labels from another recording or another replay coordinate system.
    scene=dict(schema='semantic-scene/1',map_epoch=epoch,frame_id='camera_init',objects=[],relations=[],source_stamp=float(stamps[-1]),synthetic=False,incomplete=False,revision=identity,semantic_available=False,limitations=['同场RGB-D语义独立处理中；原点/地点导航不等待着色或语义。'])
    save_json(stage/'scene.json',scene)
    shutil.copy2(frozen,stage/'vehicle.json')
    save_json(stage/'traversal-report.json',traversal)
    m=SavedMap(stage);planner=RectanglePlanner(m.cells,lo,res)
    # Verify actual map/pose loader contracts rather than declaring a successful file write sufficient.
    _,history=v.load_history(m.meta|dict(source_session=str(adapter)))
    if np.linalg.norm(history[0,:2,3])>1e-6 or abs(yaw_deg(history[0]))>1e-6:raise ValueError('Start O not normalized')
    validation=dict(origin_xy_m=history[0,:2,3].tolist(),origin_yaw_deg=yaw_deg(history[0]),map_loads=True,paired_frames=valid_frames,skipped_frames=skipped,free_components=int(label(m.cells==0)[1]),heldout_scans=len(replays),live_localization_tested=False,motion_sent=False)
    validation['origin_rectangle_clear']=planner.clear_pose([0.,0.,0.])
    save_json(stage/'validation.json',validation)
    result=dict(session=s.name,release=str(out),map_epoch=epoch,map_revision=reference_revision(m.revision,v),home=home,semantic='pending_same_source_objects',navigation='ready_for_localization',validation=validation,identity=identity)
    save_json(stage/'pipeline-manifest.json',result)
    stage.rename(out);write_state(s,state='ready',**result)
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('session');a=ap.parse_args();s=Path(a.session)
    with (s/'navigation-build.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        try:print(build(s))
        except Exception as e:write_state(s,state='failed',error=str(e));raise

"""Navigation-only geometry from the existing online FAST-LIO recording.

Reads closed MCAP only; never replays ROS, colors points, or opens sensors.
Per-frame voxelization preserves rays and all poses while bounding processing.
"""
import json, hashlib, os, shutil, time
from pathlib import Path
import numpy as np

def atomic(path, value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.'+str(os.getpid())+'.tmp')
    with tmp.open('w') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    tmp.replace(path)

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def source_identity(s):
    bag=s/'derived-bag/bag'
    return dict(metadata_sha256=digest(bag/'metadata.yaml'),segments=[dict(name=p.name,bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns) for p in sorted(bag.glob('*.mcap'))])

def sample_cloud(points,voxel_m=.1):
    points=np.asarray(points,dtype='<f4');points=points[np.isfinite(points).all(1)]
    if not len(points):return points
    # Retain an observed endpoint, not a voxel centroid in unobserved space.
    _,ids=np.unique(np.floor(points/voxel_m).astype(np.int64),axis=0,return_index=True)
    return points[np.sort(ids)]

def extract(s,voxel_m=.1,max_hz=5.):
    s=Path(s);out=s/'navigation-geometry-v1';state=s/'navigation-geometry-progress.json'
    branch=json.loads((s/'derived-bag/status.json').read_text())
    if branch.get('state')!='stopped' or branch.get('forced') or branch.get('exit_code') not in (0,None):
        raise ValueError('原建图派生录包未正常关闭；保留原始数据等待恢复')
    identity=source_identity(s)
    if (out/'ready.json').exists():
        info=json.loads((out/'ready.json').read_text())
        if info['source_identity']!=identity:raise ValueError('原建图来源已改变，不能复用旧导航几何')
        return out
    import rosbag2_py
    from rclpy.serialization import deserialize_message
    from sensor_msgs.msg import PointCloud2
    from nav_msgs.msg import Odometry
    stage=s/'navigation-geometry-v1.building'
    if stage.exists():stage.rename(s/('navigation-geometry-interrupted-'+str(time.time_ns())))
    stage.mkdir();reader=rosbag2_py.SequentialReader()
    reader.open(rosbag2_py.StorageOptions(uri=str(s/'derived-bag/bag'),storage_id='mcap'),rosbag2_py.ConverterOptions('',''))
    reader.set_filter(rosbag2_py.StorageFilter(topics=['/cloud_registered','/Odometry']))
    frames=seen=n=raw_points=pose_count=0;last=-float('inf');last_pose=-float('inf');started=time.monotonic()
    with (stage/'xyz.raw').open('wb') as xyz,(stage/'geometry_frames.jsonl').open('w') as journal,(stage/'poses.jsonl').open('w') as poses:
        while reader.has_next():
            topic,data,_=reader.read_next()
            if topic=='/Odometry':
                m=deserialize_message(data,Odometry);t=m.header.stamp.sec+m.header.stamp.nanosec/1e9
                if m.header.frame_id!='camera_init' or m.child_frame_id!='body' or t<=last_pose:raise ValueError('在线位姿坐标系/时间异常')
                p=m.pose.pose.position;q=m.pose.pose.orientation
                poses.write(json.dumps(dict(stamp=t,position=[p.x,p.y,p.z],quaternion=[q.x,q.y,q.z,q.w]))+'\n');last_pose=t;pose_count+=1;continue
            m=deserialize_message(data,PointCloud2);t=m.header.stamp.sec+m.header.stamp.nanosec/1e9;seen+=1
            if m.header.frame_id!='camera_init':raise ValueError('在线点云坐标系异常')
            if t<last:raise ValueError('在线点云时间回退')
            if t-last<1/max_hz-1e-5:continue
            fields={f.name:f for f in m.fields}
            if any(fields[k].datatype!=7 for k in ('x','y','z')):raise ValueError('PointCloud2 xyz must be float32')
            dt=np.dtype(dict(names=['x','y','z'],formats=['>f4' if m.is_bigendian else '<f4']*3,offsets=[fields[k].offset for k in ('x','y','z')],itemsize=m.point_step))
            cloud=np.ndarray((m.height,m.width),dtype=dt,buffer=bytes(m.data),strides=(m.row_step,m.point_step)).ravel()
            raw_points+=len(cloud);p=sample_cloud(np.column_stack([cloud[k] for k in ('x','y','z')]),voxel_m)
            if not len(p):continue
            xyz.write(p.tobytes());journal.write(json.dumps(dict(stamp=t,start=n,end=n+len(p),source_frame=seen))+'\n');n+=len(p);frames+=1;last=t
            if frames%100==0:atomic(state,dict(state='extracting_online_geometry',frames=frames,points=n,source_frames=seen,seconds=time.monotonic()-started))
    if frames<3 or pose_count<3:raise ValueError('原建图点云或位姿不足')
    if source_identity(s)!=identity:raise ValueError('读取时原建图录包发生变化')
    src=np.memmap(stage/'xyz.raw',dtype='<f4',mode='r',shape=(n,3))
    dst=np.lib.format.open_memmap(stage/'xyz.npy',mode='w+',dtype='<f4',shape=(n,3))
    for i in range(0,n,100000):dst[i:i+100000]=src[i:i+100000]
    dst.flush();del src,dst;(stage/'xyz.raw').unlink()
    info=dict(schema='navigation-geometry/1',source='online_FAST_LIO_derived_bag',source_identity=identity,points=n,registered_cloud_frames=frames,source_cloud_frames=seen,source_points_in_selected_frames=raw_points,poses=pose_count,voxel_m=voxel_m,max_geometry_hz=max_hz,frame='camera_init',trajectory_source='online_recorded_odometry',color_dependency=False,dense_replay_required=False,point_limit=None,frame_limit=None,seconds=time.monotonic()-started,raw_preserved=True)
    atomic(stage/'ready.json',info);stage.rename(out);atomic(state,dict(state='complete',**info));return out

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('session');a=p.parse_args();print(extract(a.session))

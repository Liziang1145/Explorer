"""Offline contracts: decoupling, timestamp pairing, evidence transforms, rejection."""
import sys,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch,Mock
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import navigation_geometry as geometry
import semantic_pipeline as semantic
import pipeline_manager as manager

class Contracts(unittest.TestCase):
 def test_voxel_keeps_observations_and_removes_nonfinite(self):
  x=np.array([[.01,.01,.01],[.08,.03,.06],[.2,0,0],[np.nan,1,2]])
  out=geometry.sample_cloud(x,.1)
  self.assertEqual(len(out),2)
  for p in out:self.assertTrue(any(np.array_equal(p,q.astype('<f4')) for q in x))
 def test_pairs_never_cross_camera_restart_or_reuse_depth(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=Path(tmp);(s/'rgbd').mkdir();rows=[]
   for epoch in [0,1]:
    for kind,t,index in [('camera',1.,0),('depth',1.01,0),('camera',1.02,1),('camera',2.,2)]:
     rows.append(dict(kind=kind,index=index,stream_epoch=epoch,received_unix_ns=int((100+epoch*10+t)*1e9),meta={'device_timestamp_us':int(t*1e6)}))
   (s/'rgbd/index.jsonl').write_text('\n'.join(json.dumps(r) for r in rows))
   pairs,policy=semantic.paired_frames(s,0)
   self.assertEqual(len(pairs),2);self.assertEqual(policy['recorded_rgb_frames'],6)
   self.assertTrue(all(c['stream_epoch']==d['stream_epoch'] and abs(tc-td)<=.05 for c,d,tc,td in pairs))
 def test_nav_coordinates_transform_bounds_and_evidence(self):
  H=np.array([[0,-1,0,10],[1,0,0,20],[0,0,1,0],[0,0,0,1]])
  s=dict(map_epoch='a',source_stamp=1,limitations=[],relations=[],objects=[dict(id='obj_000001',label='chair',center_m=[1,2,3],bounds_m=[0,1,2,2,3,4],evidence_frames=['001'])])
  graph=semantic.transform_scene(s,H,'map-rev','scene-rev',{'obs_001':{'id':'obs_001'}})
  self.assertEqual(graph['objects'][0]['center_m'],[8,21,3])
  self.assertEqual(graph['objects'][0]['bounds_m'],[7,20,2,9,22,4])
  self.assertEqual(graph['scene_revision'],'scene-rev')
 def test_no_extrapolation_to_camera_frames(self):
  h=[dict(stamp=100.,position=[0,0,0],quaternion=[0,0,0,1]),dict(stamp=100.1,position=[1,0,0],quaternion=[0,0,0,1])]
  p=semantic.pose_window(h,np.array([100,100.1]),101,101,'a')
  with self.assertRaises(semantic.GateError):p.at(101,'a')
 def test_semantic_failure_does_not_cancel_navigation(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=Path(tmp)
   with patch.object(manager,'session',return_value=s),patch.object(geometry,'extract'),patch.object(manager,'launch_semantics',side_effect=RuntimeError('injected semantic failure')),patch.object(manager.subprocess,'run',return_value=Mock(returncode=0)) as run:
    manager.run('test',activate=False)
   calls=[c.args[0] for c in run.call_args_list]
   self.assertTrue(any('validate_release.py' in str(c) for c in calls))
   self.assertFalse(any('stop' in str(c) for c in calls))
   self.assertEqual(json.loads((s/'semantic-pipeline.json').read_text())['state'],'launch_failed')
 def test_color_failure_cannot_enter_navigation_path(self):
  source=(Path(__file__).parent/'pipeline_manager.py').read_text()
  self.assertNotIn('dense-color-v1',source)
  self.assertNotIn('dual_color.py',source)
  self.assertIn('extract(s)',source)

if __name__=='__main__':unittest.main(verbosity=2)

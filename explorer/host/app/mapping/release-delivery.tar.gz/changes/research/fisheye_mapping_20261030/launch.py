"""Extend independent long capture with raw fisheye + isolated color consumer."""
import argparse,json,shutil,sys,time,subprocess,shlex,hashlib
from pathlib import Path
sys.path.insert(0,'/home/apex/long_capture')
import launch_long_capture as base
from common import atomic_json
from record_fisheye import check
ROOT=Path(__file__).resolve().parent
CAL=Path('/home/apex/research/multicamera_calibration_20261030')
PY=str(CAL/'.venv/bin/python')
old_commands=base.commands;old_budget=base.budget_gib
base.budget_gib=lambda seconds,hz,derived:old_budget(seconds,hz,derived)+round(seconds*5*1.0/1024*1.25,1)

def commands(folder,seconds,hz,derived):
 out=old_commands(folder,seconds,hz,derived)
 shutil.copy2('/home/apex/navigation_native/measurements/chassis_reference_v2_20261026.json',folder/'config/navigation_vehicle.json')
 for src,name in [('exports/camera2_intrinsics_v1/intrinsics.json','fisheye_intrinsics.json'),('exports/camera2_extrinsic_review_v1/extrinsics_candidate.json','fisheye_extrinsics.json')]:shutil.copy2(CAL/src,folder/'config'/name)
 out['raw-fisheye']=[PY,str(ROOT/'record_fisheye.py'),'--session',str(folder)]
 out['fisheye-color']=[PY,str(ROOT/'accumulate.py'),'--session',str(folder),'--geometry-only']
 return out

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--start',action='store_true');p.add_argument('--seconds',type=int,default=3600);p.add_argument('--rgbd-hz',type=float,default=5);a=p.parse_args()
 if not 60<=a.seconds<=86400 or not 1<=a.rgbd_hz<=15:p.error('invalid duration/rate')
 intr=json.loads((CAL/'exports/camera2_intrinsics_v1/intrinsics.json').read_text());check(intr)
 base.commands=commands
 if a.start:
  folder=base.start(a.seconds,a.rgbd_hz,True)
  atomic_json(ROOT/'active.json',dict(session=str(folder),relative_session=str(folder.relative_to(Path('/home/apex'))),started=time.time(),automatic_motion=False))
  meta=json.loads((folder/'session.json').read_text());meta['config_sha256']={str(p.relative_to(folder/'config')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (folder/'config').rglob('*') if p.is_file()};meta['full_color_policy']='every RGB frame; depth-camera priority, fisheye fill; durable postprocess';atomic_json(folder/'session.json',meta)
  meta['colored_product_policy']={'schema':'dual-colored-cloud/v1','dense_output_voxel_m':None,'dense_point_filter_num':1,'light_voxel_m':.05,'raw_preserved':True,'processing_failure_stops_raw':False,'point_limit':None,'frame_limit':None};atomic_json(folder/'session.json',meta)
  # Independent navigation watcher starts before any expensive VR replay.
  navcmd='source /home/apex/mapping_native/env.sh; exec /home/apex/.local/opt/navigation-plan-venv/bin/python /home/apex/research/map_navigation_pipeline_20261031/finish_navigation.py '+shlex.quote(str(folder))
  nr=subprocess.run(['systemd-run','--user','--collect','--unit=map-finish-'+folder.name.lower(),'-p','Nice=5','-p','CPUWeight=200','-p','CPUQuota=200%','-p','Environment=OPENBLAS_NUM_THREADS=2','/bin/bash','-c',navcmd],capture_output=True,text=True)
  if nr.returncode:atomic_json(folder/'navigation-publication.json',dict(state='launch_failed',error=nr.stderr,raw_preserved=True))
  meta['navigation_product_policy']={'source':'online_FAST_LIO_derived_bag','voxel_m':.10,'max_geometry_hz':5,'semantic_hz':2,'color_dependency':False,'point_limit':None,'frame_limit':None};atomic_json(folder/'session.json',meta)
  cmd='source /home/apex/mapping_native/env.sh; exec '+shlex.join([PY,str(ROOT/'finish_session.py'),str(folder)])
  r=subprocess.run(['systemd-run','--user','--unit=dual-process-'+folder.name.lower(),'--collect','-p','Nice=15','-p','CPUWeight=20','-p','IOWeight=20','-p','MemoryHigh=12G','-p','CPUQuota=400%','/bin/bash','-c',cmd],capture_output=True,text=True)
  if r.returncode:atomic_json(folder/'dual-processing.json',dict(state='needs_review',error=r.stderr,raw_independent=True))
 else:print(json.dumps(base.preflight(a.seconds,a.rgbd_hz,True),ensure_ascii=False,indent=2))

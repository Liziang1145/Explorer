"""Offline full observations + 5 cm product. Never controls acquisition or robot.

Raw bags are immutable; derived products are independently resumable. Memory is
bounded by geometry chunks and spatial hash partitions, not acquisition duration.
"""
import os,sys,json,time,subprocess,hashlib,shutil
from pathlib import Path
import numpy as np
from dual_color import atomic,PLY,CHUNK
ROOT=Path(__file__).resolve().parent

def header(n,valid=True):
 return ('ply\nformat binary_little_endian 1.0\nelement vertex '+str(n)+'\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\n'+('property uchar color_valid\n' if valid else '')+'end_header\n').encode()

def extract(s,replay,out):
 if (out/'ready.json').exists():return
 import rosbag2_py
 from rclpy.serialization import deserialize_message
 from sensor_msgs.msg import PointCloud2
 from nav_msgs.msg import Odometry
 out.mkdir(exist_ok=True);(out/'updates').mkdir(exist_ok=True)
 reader=rosbag2_py.SequentialReader();reader.open(rosbag2_py.StorageOptions(uri=str(replay/'bag'),storage_id='mcap'),rosbag2_py.ConverterOptions('',''))
 reader.set_filter(rosbag2_py.StorageFilter(topics=['/cloud_registered','/Odometry']))
 n=frames=invalid=0
 with (out/'xyz.raw').open('wb') as raw,(out/'geometry_frames.jsonl').open('w') as idx,(out/'poses.jsonl').open('w') as poses:
  while reader.has_next():
   topic,data,_=reader.read_next()
   if topic=='/Odometry':
    m=deserialize_message(data,Odometry);p=m.pose.pose.position;q=m.pose.pose.orientation
    if m.header.frame_id!='camera_init' or m.child_frame_id!='body':raise ValueError('unexpected pose frame')
    poses.write(json.dumps(dict(stamp=m.header.stamp.sec+m.header.stamp.nanosec/1e9,position=[p.x,p.y,p.z],quaternion=[q.x,q.y,q.z,q.w]))+'\n');continue
   m=deserialize_message(data,PointCloud2)
   if m.header.frame_id!='camera_init':raise ValueError('unexpected cloud frame')
   fields={x.name:x for x in m.fields};dt=np.dtype(dict(names=['x','y','z'],formats=['>f4' if m.is_bigendian else '<f4']*3,offsets=[fields[k].offset for k in ('x','y','z')],itemsize=m.point_step))
   a=np.ndarray((m.height,m.width),dtype=dt,buffer=bytes(m.data),strides=(m.row_step,m.point_step)).ravel();xyz=np.column_stack([a[k] for k in ('x','y','z')]);good=np.isfinite(xyz).all(1);invalid+=int((~good).sum());xyz=xyz[good].astype('<f4')
   raw.write(xyz.tobytes());idx.write(json.dumps(dict(stamp=m.header.stamp.sec+m.header.stamp.nanosec/1e9,start=n,end=n+len(xyz)))+'\n');n+=len(xyz);frames+=1
 if not n:raise RuntimeError('empty replay')
 src=np.memmap(out/'xyz.raw',dtype='<f4',mode='r',shape=(n,3));dst=np.lib.format.open_memmap(out/'xyz.npy',mode='w+',dtype='<f4',shape=(n,3))
 for i in range(0,n,CHUNK):dst[i:i+CHUNK]=src[i:i+CHUNK]
 dst.flush();del src,dst;(out/'xyz.raw').unlink()
 for name,dtype,shape,value in [('rgb.npy','u1',(n,3),145),('source.npy','u1',(n,),0),('quality.npy','<f4',(n,),-1)]:
  a=np.lib.format.open_memmap(out/name,mode='w+',dtype=dtype,shape=shape)
  for i in range(0,n,CHUNK):a[i:i+CHUNK]=value
  a.flush();del a
 atomic(out/'ready.json',dict(points=n,registered_cloud_frames=frames,invalid_points=invalid,geometry_source=str(replay/'bag'),voxel_m=None,dense_observations=True,point_filter_num=1,raw_geometry_untouched=True))

def colored_ply(out):
 target=out/'colored_only.ply'
 if target.exists():return target
 source=np.load(out/'source.npy',mmap_mode='r');xyz=np.load(out/'xyz.npy',mmap_mode='r');rgb=np.load(out/'rgb.npy',mmap_mode='r');n=int(sum(np.count_nonzero(source[i:i+CHUNK]) for i in range(0,len(source),CHUNK)))
 dt=np.dtype([('xyz','<f4',(3,)),('rgb','u1',(3,))]);tmp=target.with_suffix('.tmp')
 with tmp.open('wb') as f:
  f.write(header(n,False))
  for i in range(0,len(source),CHUNK):
   mask=source[i:i+CHUNK]>0;a=np.empty(int(mask.sum()),dt);a['xyz']=xyz[i:i+CHUNK][mask];a['rgb']=rgb[i:i+CHUNK][mask];f.write(a.tobytes())
 tmp.replace(target);return target

def light_product(full,out):
 if (out/'complete.json').exists():return
 out.mkdir(exist_ok=True);parts=out/'partitions';parts.mkdir(exist_ok=True)
 xyz=np.load(full/'xyz.npy',mmap_mode='r');rgb=np.load(full/'rgb.npy',mmap_mode='r');src=np.load(full/'source.npy',mmap_mode='r');score=np.load(full/'quality.npy',mmap_mode='r')
 dt=np.dtype([('key','<i8',(3,)),('xyz','<f4',(3,)),('rgb','u1',(3,)),('source','u1'),('score','<f4')])
 # Disk partitions retain every candidate before selecting one observed point per voxel.
 if not (parts/'ready.json').exists():
  for p in parts.glob('*.bin'):p.unlink()
  handles=[(parts/f'{j:03d}.bin').open('wb') for j in range(256)]
  try:
   for i in range(0,len(xyz),CHUNK):
    p=xyz[i:i+CHUNK];key=np.floor(p/.05).astype(np.int64);bucket=(key[:,0]*73856093^key[:,1]*19349663^key[:,2]*83492791)&255
    a=np.empty(len(p),dt);a['key']=key;a['xyz']=p;a['rgb']=rgb[i:i+CHUNK];a['source']=src[i:i+CHUNK];a['score']=score[i:i+CHUNK]
    for b in np.unique(bucket):handles[b].write(a[bucket==b].tobytes())
  finally:
   for h in handles:h.close()
  atomic(parts/'ready.json',dict(input_points=len(xyz)))
 count=0;counts=np.zeros(4,np.int64)
 with (out/'records.bin').open('wb') as f:
  for p in sorted(parts.glob('*.bin')):
   a=np.fromfile(p,dtype=dt)
   if not len(a):continue
   k=a['key'];order=np.lexsort((-a['score'],-a['source'].astype(int),k[:,2],k[:,1],k[:,0]));a=a[order];k=a['key'];keep=np.r_[True,np.any(k[1:]!=k[:-1],axis=1)];a=a[keep]
   v=np.empty(len(a),PLY);v['xyz']=a['xyz'];v['rgb']=a['rgb'];v['source']=a['source'];f.write(v.tobytes());count+=len(v);counts+=np.bincount(v['source'],minlength=4)
 records=np.memmap(out/'records.bin',dtype=PLY,mode='r');colored=int(counts[1:].sum());dt15=np.dtype([('xyz','<f4',(3,)),('rgb','u1',(3,))])
 with (out/'map_color.ply').open('wb') as f,(out/'colored_only.ply').open('wb') as c:
  f.write(header(count));c.write(header(colored,False))
  for i in range(0,count,CHUNK):
   a=records[i:i+CHUNK];f.write(a.tobytes());b=a[a['source']>0];v=np.empty(len(b),dt15);v['xyz']=b['xyz'];v['rgb']=b['rgb'];c.write(v.tobytes())
 shutil.copyfile(out/'records.bin',out/'preview.bin')
 info=dict(map_points=count,colored_points=colored,rgb_points=int(counts[2:].sum()),depth_verified_points=int(counts[3]),fisheye_only_points=int(counts[1]),uncolored_points=int(counts[0]),voxel_m=.05,preview_points=count,preview_is_sample=False,source=str(full),state='complete',time=time.time())
 atomic(out/'health.json',info);atomic(out/'complete.json',info)
 shutil.rmtree(parts);(out/'records.bin').unlink()

def main():
 import argparse
 p=argparse.ArgumentParser();p.add_argument('session',type=Path);a=p.parse_args();s=a.session
 replay=s/'dense-replay-v1';full=s/'dense-color-v1';light=s/'exports/dual-light-5cm-v2';light.parent.mkdir(exist_ok=True)
 state=s/'dual-products-progress.json'
 try:
  atomic(state,dict(state='dense_replay',raw_independent=True,time=time.time()))
  if not (replay/'complete.json').exists():subprocess.run([sys.executable,str(ROOT/'dense_replay.py'),str(s),str(replay)],check=True)
  atomic(state,dict(state='extracting_all_observations',time=time.time()));extract(s,replay,full)
  # VR-only branch: navigation and semantics consume online geometry independently.
  # Never launch/rebuild navigation from dense replay coordinates here.
  atomic(state,dict(state='coloring_dense',time=time.time()))
  if not (full/'complete.json').exists():subprocess.run([sys.executable,str(ROOT/'run_coloring.py'),str(s)],check=True)
  colored_ply(full);atomic(state,dict(state='deriving_light_5cm',time=time.time()));light_product(full,light)
  f=json.loads((full/'complete.json').read_text());l=json.loads((light/'complete.json').read_text());r=json.loads((full/'ready.json').read_text())
  manifest=dict(schema='dual-colored-cloud/v1',purpose='VR_visualization',geometry_estimator='offline_dense_replay_not_navigation_pose_source',session=s.name,state='complete',frame='camera_init',meters_per_unit=1,raw_preserved=True,point_limit=None,frame_limit=None,color_priority='depth-verified RGB > RGB with LiDAR occlusion > fisheye',dense=dict(folder=str(full),voxel_m=None,point_filter_num=1,geometry_points=f['map_points'],colored_points=f['colored_points'],all_valid_observations=True,repeated_observations_preserved=True,frames=r['registered_cloud_frames'],colored_ply=str(full/'colored_only.ply'),geometry_ply=str(full/'map_color.ply')),light=dict(folder=str(light),voxel_m=.05,derived_from='dense',geometry_points=l['map_points'],colored_points=l['colored_points'],colored_ply=str(light/'colored_only.ply'),geometry_ply=str(light/'map_color.ply')),preview_is_not_product=True,accuracy_claim=False,time=time.time())
  atomic(s/'colored-products.json',manifest);atomic(ROOT/'latest-products.json',manifest)
  atomic(state,dict(state='packaging_vr_dense_and_light',manifest=str(s/'colored-products.json'),time=time.time()))
  subprocess.run([sys.executable,'/home/apex/research/vr_cloud_stream_20261030/package_products.py',str(s/'colored-products.json')],check=True)
  subprocess.run(['systemctl','--user','restart','aipc-vr-cloud.service'],check=True)
  atomic(state,dict(state='complete',manifest=str(s/'colored-products.json'),time=time.time()))
 except Exception as e:atomic(state,dict(state='needs_review',error=str(e),raw_preserved=True,time=time.time()));raise
if __name__=='__main__':main()

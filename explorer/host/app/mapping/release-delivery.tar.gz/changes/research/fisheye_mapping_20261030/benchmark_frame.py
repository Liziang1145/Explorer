"""Actual recorded RGB/fisheye frame, two-pass visibility and color comparison."""
import json,time,sys,hashlib
from pathlib import Path
import numpy as np
import dual_color as color
from color_gpu import project as accelerated
import torch
s=Path(sys.argv[1]);root=Path(__file__).resolve().parent;out=root/'gpu-frame-validation';out.mkdir(exist_ok=True);(out/'updates').mkdir(exist_ok=True)
source=np.load(s/'dense-color-v1/xyz.npy',mmap_mode='r')
if not (out/'xyz.npy').exists():np.save(out/'xyz.npy',source[:5000000])
tasks,_=color.build_tasks(s,s/'dense-color-v1/poses.jsonl');color.init_worker(s,out);color.CHUNK=1000000
cpu=color.project;rows=[]
for kind in ['rgb','fish']:
 task=next(t for t in tasks if t['kind']==kind and not t.get('error'))
 results={}
 for name,fn in [('cpu',cpu),('gpu',accelerated)]:
  color.project=fn;torch.cuda.synchronize();start=time.perf_counter();r=color.process(task);torch.cuda.synchronize();r['wall_s']=time.perf_counter()-start
  if not r['accepted']:raise ValueError(r)
  p=Path(r['update_file']);dest=p.with_name(kind+'-'+name+'.bin');p.rename(dest);r['sha256']=hashlib.sha256(dest.read_bytes()).hexdigest();r['file']=str(dest);results[name]=r
 a=np.fromfile(results['cpu']['file'],dtype=color.UP);b=np.fromfile(results['gpu']['file'],dtype=color.UP)
 equivalent=len(a)==len(b) and np.array_equal(a['id'],b['id']) and np.array_equal(a['rgb'],b['rgb']) and np.array_equal(a['source'],b['source']) and np.allclose(a['score'],b['score'],atol=1e-6)
 rows.append(dict(kind=kind,points=min(len(source),5000000),cpu_seconds=results['cpu']['wall_s'],gpu_seconds=results['gpu']['wall_s'],speedup=results['cpu']['wall_s']/results['gpu']['wall_s'],hits=len(a),equivalent=equivalent))
result=dict(scope='one_frame_5M_real_points_including_decode_occlusion_color_and_write',rows=rows,peak_allocated_bytes=torch.cuda.max_memory_allocated(),approved=all(r['equivalent'] and r['speedup']>1.1 for r in rows),physical_commands=0)
color.atomic(root/'gpu-frame-benchmark.json',result);print(json.dumps(result,indent=2))

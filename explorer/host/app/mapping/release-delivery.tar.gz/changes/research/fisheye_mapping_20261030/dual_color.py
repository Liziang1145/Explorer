"""All recorded RGB frames, disk-backed geometry, bounded chunks, RGB-D priority.
No sensor/control calls. No point-count or frame-count truncation. Resume journal.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,json,sqlite3,time,zlib,math,concurrent.futures,hashlib,sys
from pathlib import Path
import numpy as np
import cv2
from color_core import pose_at,camera_pose
CHUNK=100000
UP=np.dtype([('id','<u8'),('rgb','u1',(3,)),('source','u1'),('score','<f4')])
PLY=np.dtype([('xyz','<f4',(3,)),('rgb','u1',(3,)),('source','u1')])

def atomic(p,v):
 p=Path(p);q=p.with_suffix('.tmp');q.write_text(json.dumps(v,ensure_ascii=False,indent=2));q.replace(p)

def project(xyz,wc,model):
 c=(xyz-wc[:3,3])@wc[:3,:3];r=np.linalg.norm(c,axis=1)
 if model['type']=='fish':
  theta=np.arctan2(np.linalg.norm(c[:,:2],axis=1),c[:,2]);ids=np.flatnonzero((r>.35)&(theta<np.radians(80)))
  v=c[ids];t=theta[ids];d=np.array(model['D']).ravel();t2=t*t;td=t*(1+d[0]*t2+d[1]*t2**2+d[2]*t2**3+d[3]*t2**4)
  xy=v[:,:2]*np.divide(td,np.linalg.norm(v[:,:2],axis=1),out=np.zeros(len(v)),where=np.linalg.norm(v[:,:2],axis=1)>1e-12)[:,None]
  K=np.array(model['K']);uv=xy*np.array([K[0,0],K[1,1]])+np.array([K[0,2],K[1,2]])
  good=(np.linalg.norm(uv-[688,688],axis=1)<630);quality=np.cos(t)**2/(1+.05*r[ids]);depth=r[ids]
 else:
  ids=np.flatnonzero((c[:,2]>.1)&(np.abs(c[:,0])<c[:,2]*2)&(np.abs(c[:,1])<c[:,2]*2))
  v=c[ids];x,y=(v[:,:2]/v[:,2,None]).T;k1,k2,p1,p2,k3,k4,k5,k6=np.pad(np.array(model['D']), (0,8-len(model['D'])))
  r2=x*x+y*y;rad=(1+k1*r2+k2*r2**2+k3*r2**3)/(1+k4*r2+k5*r2**2+k6*r2**3)
  xy=np.column_stack((x*rad+2*p1*x*y+p2*(r2+2*x*x),y*rad+p1*(r2+2*y*y)+2*p2*x*y))
  K=np.array(model['K']);uv=xy*np.array([K[0,0],K[1,1]])+np.array([K[0,2],K[1,2]])
  good=np.ones(len(ids),bool);quality=(v[:,2]/r[ids])**2/(1+.05*r[ids]);depth=v[:,2]
 good &= np.isfinite(uv).all(axis=1)&(uv[:,0]>=1)&(uv[:,1]>=1)&(uv[:,0]<model['width']-2)&(uv[:,1]<model['height']-2)
 return ids[good],uv[good],depth[good],quality[good]

def depth_visibility(xyz,wd,depth,dk):
 c=(xyz-wd[:3,3])@wd[:3,:3];z=c[:,2];safe=np.maximum(z,.001)
 u=np.rint(c[:,0]/safe*dk['fx']+dk['cx']).astype(int);v=np.rint(c[:,1]/safe*dk['fy']+dk['cy']).astype(int)
 valid=(z>.1)&(u>=0)&(v>=0)&(u<depth.shape[1])&(v<depth.shape[0]);observed=np.zeros(len(xyz));observed[valid]=depth[v[valid],u[valid]]
 known=valid&(observed>.2)&(observed<8)
 # Measured nearer surface vetoes a map point behind it; missing depth uses LiDAR z-buffer.
 visible=~known|(z<=observed+.08+.025*observed)
 agrees=known&(np.abs(z-observed)<=.08+.025*observed)
 return visible,agrees

G={}
def geometry_chunks(task,n):
 for lo,hi in task.get('ranges',[(0,n)]):
  for start in range(lo,hi,CHUNK):yield start,min(hi,start+CHUNK)

_cpu_project=project
def init_worker(session,out):
 global project,CHUNK
 if os.environ.get('APEX_COLOR_GPU')=='1':
  from color_gpu import project as accelerated
  project=accelerated;CHUNK=1000000
 cv2.setNumThreads(1);s=Path(session);cfg=s/'config'
 G.update(s=s,out=Path(out),xyz=np.load(Path(out)/'xyz.npy',mmap_mode='r'),intr=json.loads((cfg/'fisheye_intrinsics.json').read_text()),factory=json.loads((cfg/'calibration/factory-camera-parameters.json').read_text()))

def process(task):
 t0=time.time();file=G['out']/'updates'/f'{task["job"]:08d}.bin';tmp=file.with_suffix('.tmp')
 try:
  if task.get('error'):raise ValueError(task['error'])
  model=task['model'];wc=np.array(task['wc']);image=cv2.imread(str(G['s']/task['image']))
  if image is None or image.shape[:2]!=(model['height'],model['width']):raise ValueError('image_dimensions_or_decode')
  sharp=float(cv2.Laplacian(cv2.cvtColor(image,cv2.COLOR_BGR2GRAY),cv2.CV_64F).var());weight=max(.05,min(1,sharp/100))/(1+task['speed']*.5+task['omega']*.2)
  depth=None;depth_error=None
  if task.get('depth'):
   try:depth=np.frombuffer(zlib.decompress((G['s']/task['depth']).read_bytes()),dtype='<u2').reshape(480,848).astype(np.float32)*task['depth_scale'];wd=np.array(task['wd'])
   except Exception as e:depth_error=str(e)
  xyz=G['xyz'];h,w=model['height'],model['width'];zbuf=np.full(((h+1)//2,(w+1)//2),np.inf,np.float32)
  # Global image-space visibility across every geometry chunk, not per-chunk occlusion.
  for start,end in geometry_chunks(task,len(xyz)):
   ids,uv,z,q=project(xyz[start:end],wc,model);pix=np.floor(uv/2).astype(int);np.minimum.at(zbuf,(pix[:,1],pix[:,0]),z)
  zbuf=cv2.erode(zbuf,np.ones((3,3),np.uint8));hits=verified=0
  with tmp.open('wb') as f:
   for start,end in geometry_chunks(task,len(xyz)):
    ids,uv,z,q=project(xyz[start:end],wc,model);pix=np.floor(uv/2).astype(int);good=z<=zbuf[pix[:,1],pix[:,0]]+.04+.01*z
    ids,uv,q=ids[good],uv[good],q[good];source=np.full(len(ids),1 if task['kind']=='fish' else 2,np.uint8)
    if depth is not None:
     visible,agree=depth_visibility(xyz[start+ids],wd,depth,G['factory']['depth_intrinsic']);source[agree]=3
     ids,uv,q,source=ids[visible],uv[visible],q[visible],source[visible];verified+=int(sum(source==3))
    for k in range(0,len(ids),16000):
     v=uv[k:k+16000].astype(np.float32);rgb=cv2.remap(image,v[:,0:1],v[:,1:2],cv2.INTER_LINEAR).reshape(-1,3)[:,::-1]
     a=np.empty(len(v),UP);a['id']=start+ids[k:k+len(v)];a['rgb']=rgb;a['source']=source[k:k+len(v)];a['score']=q[k:k+len(v)]*weight;f.write(a.tobytes());hits+=len(v)
  tmp.replace(file)
  return dict(job=task['job'],kind=task['kind'],index=task['index'],accepted=True,hits=hits,depth_verified=verified,depth_error=depth_error,depth_pair=task.get('depth'),depth_pair_skew_s=task.get('depth_pair_skew_s'),seconds=time.time()-t0,update_file=str(file))
 except Exception as e:
  if os.environ.get('APEX_COLOR_GPU')=='1':
   print('GPU frame fallback: '+str(e),file=sys.stderr,flush=True)
   globals()['project']=_cpu_project;os.environ['APEX_COLOR_GPU']='0'
   return process(task)
  if tmp.exists():tmp.unlink()
  return dict(job=task['job'],kind=task['kind'],index=task['index'],accepted=False,error=str(e),seconds=time.time()-t0)

def build_tasks(s,pose_file=None):
 cfg=s/'config';intr=json.loads((cfg/'fisheye_intrinsics.json').read_text());ext=json.loads((cfg/'fisheye_extrinsics.json').read_text());body=json.loads((cfg/'body_from_lidar.json').read_text())
 fac=json.loads((cfg/'calibration/factory-camera-parameters.json').read_text());rgbext=json.loads((cfg/'calibration/extrinsics.json').read_text())
 pose_file=pose_file or (s/'registered-full/poses.jsonl' if (s/'registered-full/complete.json').exists() else s/'fisheye-color/poses.jsonl')
 poses=[json.loads(x) for x in pose_file.read_text().splitlines()];history=[(r['stamp'],r['position'],r['quaternion']) for r in poses]
 fish=[json.loads(x) for x in (s/'raw-fisheye/index.jsonl').read_text().splitlines()];rgbd=[json.loads(x) for x in (s/'rgbd/index.jsonl').read_text().splitlines()]
 colors=[r for r in rgbd if r['kind']=='camera'];depths=[r for r in rgbd if r['kind']=='depth'];offsets={}
 for epoch in set(r['stream_epoch'] for r in rgbd):
  values=[r['received_unix_ns']/1e9-r['meta']['device_timestamp_us']/1e6 for r in rgbd if r['stream_epoch']==epoch];offsets[epoch]=float(np.percentile(values,5))
 dep_by_epoch={e: sorted([r for r in depths if r['stream_epoch']==e],key=lambda r:r['meta']['device_timestamp_us']) for e in offsets}
 dep_ts={e:np.array([r['meta']['device_timestamp_us']/1e6 for r in d]) for e,d in dep_by_epoch.items()}
 def world(t,T):
  j=np.searchsorted([r[0] for r in history],t);p,rot,v,w=pose_at(history[max(0,j-1):j+1],t);return camera_pose(p,rot,body,T),v,w
 Kc=fac['color_intrinsic'];model_rgb=dict(type='rgb',K=[[Kc['fx'],0,Kc['cx']],[0,Kc['fy'],Kc['cy']],[0,0,1]],D=fac['color_distortion_opencv'],width=Kc['width'],height=Kc['height'])
 model_fish=dict(type='fish',K=intr['K'],D=intr['D'],width=1376,height=1376)
 cd=np.eye(4);cd[:3,:3]=np.array(fac['depth_to_color_rotation_flat']).reshape(3,3);cd[:3,3]=np.array(fac['depth_to_color_translation_mm'])/1000
 tasks=[]
 for kind,records in [('rgb',colors),('fish',fish)]:
  for r in records:
   task=dict(job=len(tasks),kind=kind,index=r['index'],image=('rgbd/' if kind=='rgb' else 'raw-fisheye/')+r['file'],model=model_rgb if kind=='rgb' else model_fish)
   try:
    t=r['sampled_at'] if kind=='fish' else r['meta']['device_timestamp_us']/1e6+offsets[r['stream_epoch']]
    wc,v,w=world(t,np.array(ext['T_camera_lidar'] if kind=='fish' else rgbext['T_target_from_source']));task.update(wc=wc.tolist(),speed=v,omega=w,time=t)
    if kind=='rgb':
     epoch=r['stream_epoch'];ts=dep_ts[epoch];nearest=int(np.argmin(abs(ts-r['meta']['device_timestamp_us']/1e6)))
     d=dep_by_epoch[epoch][nearest];skew=float(abs(ts[nearest]-r['meta']['device_timestamp_us']/1e6));task['depth_pair_skew_s']=skew
     if skew<=.05:
      try:
       wdc,_,_=world(ts[nearest]+offsets[epoch],np.array(rgbext['T_target_from_source']));task.update(depth='rgbd/'+d['file'],depth_scale=d['meta'].get('scale_mm',1)/1000,wd=(wdc@cd).tolist())
      except ValueError:task['depth_reason']='depth_pose_unavailable'
     else:task['depth_reason']='depth_device_time_skew'
   except Exception as e:task['error']=str(e)
   tasks.append(task)
 return tasks,dict(fisheye_frames=len(fish),rgb_frames=len(colors),depth_frames=len(depths),total_color_frames=len(tasks),device_to_host_offset=offsets,hardware_sync=False,pose_gap_max_s=.25,quality_policy='motion/blur downweight; no motion frame rejection',priority='depth-verified RGB > RGB with LiDAR occlusion > fisheye',point_limit=None,frame_limit=None)

def prepare(s,out):
 out.mkdir(exist_ok=True);(out/'updates').mkdir(exist_ok=True)
 if (out/'ready.json').exists():return
 geometry=s/'registered-full/map.sqlite3' if (s/'registered-full/complete.json').exists() else s/'fisheye-color/map.sqlite3'
 db=sqlite3.connect(f'file:{geometry}?mode=ro',uri=True);n=db.execute('select count(*) from points').fetchone()[0]
 xyz=np.lib.format.open_memmap(out/'xyz.npy',mode='w+',dtype='<f4',shape=(n,3));cur=db.execute('select x,y,z from points order by id');offset=0
 while rows:=cur.fetchmany(CHUNK):xyz[offset:offset+len(rows)]=rows;offset+=len(rows)
 xyz.flush();db.close()
 for name,dtype,shape,value in [('rgb.npy','u1',(n,3),145),('source.npy','u1',(n,),0),('quality.npy','<f4',(n,),-1)]:
  a=np.lib.format.open_memmap(out/name,mode='w+',dtype=dtype,shape=shape);a[:]=value;a.flush()
 atomic(out/'ready.json',dict(points=n,geometry_source=str(geometry.relative_to(s)),voxel_m=.03,raw_geometry_untouched=True))

def export(out):
 xyz=np.load(out/'xyz.npy',mmap_mode='r');rgb=np.load(out/'rgb.npy',mmap_mode='r');source=np.load(out/'source.npy',mmap_mode='r');n=len(xyz);step=max(1,math.ceil(n/150000));counts=np.zeros(4,np.int64)
 target=out/'map_color.ply';temp=target.with_suffix('.tmp')
 with temp.open('wb') as f,(out/'preview.tmp').open('wb') as v:
  f.write(f'ply\nformat binary_little_endian 1.0\ncomment color_valid: 0 none, 1 fisheye, 2 RGB, 3 depth-verified RGB\nelement vertex {n}\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nproperty uchar color_valid\nend_header\n'.encode())
  for i in range(0,n,CHUNK):
   stop=min(n,i+CHUNK);a=np.empty(stop-i,PLY);a['xyz']=xyz[i:stop];a['rgb']=rgb[i:stop];a['source']=source[i:stop];f.write(a.tobytes());v.write(a[np.arange(i,stop)%step==0].tobytes());counts+=np.bincount(source[i:stop],minlength=4)
 temp.replace(target);(out/'preview.tmp').replace(out/'preview.bin')
 ready=json.loads((out/'ready.json').read_text())
 return dict(map_points=n,colored_points=int(counts[1:].sum()),rgb_points=int(counts[2:].sum()),depth_verified_points=int(counts[3]),fisheye_only_points=int(counts[1]),uncolored_points=int(counts[0]),preview_points=(n+step-1)//step,voxel_m=ready.get('voxel_m',.03),full_raw_preserved=True,preview_is_sample=step>1)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('session',type=Path);ap.add_argument('--workers',type=int,default=4);ap.add_argument('--output',default='dual-color-full');a=ap.parse_args();s=a.session
 if Path(a.output).name!=a.output:raise ValueError('output must be a local directory name')
 out=s/a.output;prepare(s,out)
 ready=json.loads((out/'ready.json').read_text());dense=ready.get('dense_observations',False)
 tasks,manifest=build_tasks(s,out/'poses.jsonl' if dense else None)
 if dense:
  frames=[json.loads(x) for x in (out/'geometry_frames.jsonl').read_text().splitlines()];times=np.array([x['stamp'] for x in frames])
  for t in tasks:
   if 'time' in t:
    lo,hi=np.searchsorted(times,[t['time']-.4,t['time']+.4]);t['ranges']=[(frames[lo]['start'],frames[hi-1]['end'])] if hi>lo else []
  manifest.update(dense_observations=True,output_voxel_m=None,temporal_association_half_window_s=.4,geometry_policy='all finite deskewed observations, including repeated surfaces')
 atomic(out/'manifest.json',manifest);atomic(out/'tasks.json',tasks)
 completed={};journal=out/'frames.jsonl'
 if journal.exists():
  for line in journal.read_text().splitlines():
   try:r=json.loads(line);completed[r['job']]=r
   except json.JSONDecodeError:raise RuntimeError('incomplete journal: repair trailing record before resume')
 rgb=np.load(out/'rgb.npy',mmap_mode='r+');source=np.load(out/'source.npy',mmap_mode='r+');quality=np.load(out/'quality.npy',mmap_mode='r+');begin=time.time()
 todo=iter(t for t in tasks if t['job'] not in completed);running={};done=len(completed);accepted=sum(r['accepted'] for r in completed.values());last_export=0
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers,initializer=init_worker,initargs=(str(s),str(out))) as pool,journal.open('a') as log:
  def submit():
   t=next(todo,None)
   if t is None:return False
   running[pool.submit(process,t)]=t['job'];return True
  for _ in range(a.workers):submit()
  while running:
   finished,_=concurrent.futures.wait(running,return_when=concurrent.futures.FIRST_COMPLETED)
   for fut in finished:
    job=running.pop(fut);r=fut.result();updates=0
    if r['accepted']:
     f=Path(r['update_file'])
     with f.open('rb') as stream:
      while chunk:=stream.read(CHUNK*UP.itemsize):
       x=np.frombuffer(chunk,UP);ids=x['id'];priority=x['source'];q=x['score'];take=(priority>source[ids])|((priority==source[ids])&(q>quality[ids]));ids=ids[take];rgb[ids]=x['rgb'][take];source[ids]=priority[take];quality[ids]=q[take];updates+=len(ids)
     rgb.flush();source.flush();quality.flush();accepted+=1
    r['updates']=updates;log.write(json.dumps(r)+'\n');log.flush();os.fsync(log.fileno())
    if r.get('update_file'):Path(r['update_file']).unlink(missing_ok=True)
    done+=1;atomic(out/'progress.json',dict(state='processing',done=done,total=len(tasks),accepted=accepted,rejected=done-accepted,elapsed_s=time.time()-begin,last=r));submit()
   if not dense and time.time()-last_export>45:
    summary=export(out);atomic(out/'health.json',dict(**summary,session=s.name,time=time.time(),state='processing',frames_colored=accepted,frame_skips=done-accepted,frames_processed=done,frames_total=len(tasks),last_error=None));last_export=time.time()
 summary=export(out);atomic(out/'health.json',dict(**summary,session=s.name,time=time.time(),state='stopped',frames_colored=accepted,frame_skips=done-accepted,frames_processed=done,frames_total=len(tasks),last_error=None,hardware_sync=False,candidate_extrinsics=True));atomic(out/'complete.json',dict(**manifest,**summary,done=done,accepted=accepted,rejected=done-accepted,elapsed_s=time.time()-begin));atomic(out/'progress.json',dict(state='complete',done=done,total=len(tasks),accepted=accepted,rejected=done-accepted,elapsed_s=time.time()-begin));print(json.dumps(summary),flush=True)
if __name__=='__main__':main()

"""Optional ROCm projection backend; same color/occlusion decisions stay on CPU.
Float64 math preserves the calibrated CPU projection, including ROI boundaries.
"""
import numpy as np
_torch=None
def project(xyz,wc,model):
    global _torch
    if _torch is None:
        import torch
        if not torch.cuda.is_available() or not torch.version.hip:raise RuntimeError('ROCm unavailable')
        _torch=torch
    t=_torch;device='cuda'
    with t.inference_mode():
        p=t.as_tensor(np.asarray(xyz),device=device,dtype=t.float64)
        pose=t.as_tensor(np.asarray(wc),device=device,dtype=t.float64)
        c=(p-pose[:3,3])@pose[:3,:3];r=t.linalg.vector_norm(c,dim=1)
        if model['type']=='fish':
            theta=t.atan2(t.linalg.vector_norm(c[:,:2],dim=1),c[:,2]);ids=t.nonzero((r>.35)&(theta<np.radians(80))).flatten()
            v=c[ids];angle=theta[ids];d=t.as_tensor(np.array(model['D']).ravel(),device=device,dtype=t.float64);a2=angle*angle
            ad=angle*(1+d[0]*a2+d[1]*a2**2+d[2]*a2**3+d[3]*a2**4)
            length=t.linalg.vector_norm(v[:,:2],dim=1);xy=v[:,:2]*t.where(length>1e-12,ad/length,t.zeros_like(length))[:,None]
            quality=t.cos(angle)**2/(1+.05*r[ids]);depth=r[ids]
        else:
            ids=t.nonzero((c[:,2]>.1)&(t.abs(c[:,0])<c[:,2]*2)&(t.abs(c[:,1])<c[:,2]*2)).flatten();v=c[ids]
            x,y=(v[:,:2]/v[:,2,None]).T
            d=np.pad(np.array(model['D']),(0,8-len(model['D'])));k1,k2,p1,p2,k3,k4,k5,k6=d
            r2=x*x+y*y;rad=(1+k1*r2+k2*r2**2+k3*r2**3)/(1+k4*r2+k5*r2**2+k6*r2**3)
            xy=t.stack((x*rad+2*p1*x*y+p2*(r2+2*x*x),y*rad+p1*(r2+2*y*y)+2*p2*x*y),dim=1)
            quality=(v[:,2]/r[ids])**2/(1+.05*r[ids]);depth=v[:,2]
        K=np.asarray(model['K']);uv=xy*t.tensor([K[0,0],K[1,1]],device=device)+t.tensor([K[0,2],K[1,2]],device=device)
        good=t.ones(len(ids),dtype=t.bool,device=device)
        if model['type']=='fish':good &= t.linalg.vector_norm(uv-t.tensor([688,688],device=device),dim=1)<630
        good &= t.isfinite(uv).all(dim=1)&(uv[:,0]>=1)&(uv[:,1]>=1)&(uv[:,0]<model['width']-2)&(uv[:,1]<model['height']-2)
        return tuple(a.cpu().numpy() for a in (ids[good],uv[good],depth[good],quality[good]))

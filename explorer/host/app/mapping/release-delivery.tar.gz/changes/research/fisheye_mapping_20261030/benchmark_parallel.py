import os,sys,json,time,multiprocessing,concurrent.futures
from pathlib import Path
import numpy as np
import dual_color as color

def main():
 s=Path(sys.argv[1]);root=Path(__file__).resolve().parent;out=root/'gpu-frame-validation'
 tasks,_=color.build_tasks(s,s/'dense-color-v1/poses.jsonl')
 chosen=[next(t for t in tasks if t['kind']==kind and not t.get('error')) for kind in ['rgb','fish','rgb','fish','rgb','fish','rgb','fish']]
 rows=[];reference={}
 for backend,workers in [('cpu',4),('rocm',1),('rocm',2)]:
  os.environ['APEX_COLOR_GPU']='1' if backend=='rocm' else '0'
  color.CHUNK=1000000
  with concurrent.futures.ProcessPoolExecutor(max_workers=workers,mp_context=multiprocessing.get_context('spawn'),initializer=color.init_worker,initargs=(str(s),str(out))) as pool:
   # Warm each worker; exclude import/driver initialization from steady throughput.
   warm=[dict(chosen[i],job=8000+i) for i in range(workers)]
   list(pool.map(color.process,warm))
   start=time.perf_counter();results=list(pool.map(color.process,[dict(t,job=9000+j) for j,t in enumerate(chosen)]));seconds=time.perf_counter()-start
  good=all(r['accepted'] for r in results);same=True
  for j,r in enumerate(results):
   if not r['accepted']:same=False;continue
   a=np.fromfile(r['update_file'],dtype=color.UP)
   if backend=='cpu':reference[j]=a.copy()
   else:
    b=reference[j];same &= len(a)==len(b) and np.array_equal(a['id'],b['id']) and np.array_equal(a['rgb'],b['rgb']) and np.array_equal(a['source'],b['source']) and np.allclose(a['score'],b['score'],atol=1e-6)
  rows.append(dict(backend=backend,workers=workers,frames=len(results),points_per_frame=5000000,seconds=seconds,frames_per_second=len(results)/seconds,accepted=good,equivalent=same))
 baseline=rows[0]['seconds'];best=min([r for r in rows if r['accepted'] and r['equivalent']],key=lambda r:r['seconds'])
 report=dict(scope='8_real_frames_5M_points_each_complete_coloring_steady_state',rows=rows,recommended_backend=best['backend'],recommended_workers=best['workers'],speedup_vs_cpu4=baseline/best['seconds'],approved=best['backend']=='rocm' and baseline/best['seconds']>1.1,physical_commands=0)
 color.atomic(root/'gpu-parallel-benchmark.json',report);print(json.dumps(report,indent=2))
if __name__=='__main__':main()

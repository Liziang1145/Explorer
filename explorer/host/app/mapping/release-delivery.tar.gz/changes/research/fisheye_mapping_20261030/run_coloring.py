"""Resource-aware VR color dispatcher; failures never propagate to raw/nav jobs."""
import fcntl,hashlib,json,os,subprocess,sys,time
from pathlib import Path
from dual_color import atomic
ROOT=Path(__file__).resolve().parent
NATIVE=Path('/home/apex/rocm-services-20261102/native_launcher.sh')

def resources():
    m={r.split(':')[0]:int(r.split()[1])*1024 for r in Path('/proc/meminfo').read_text().splitlines() if r.startswith(('MemAvailable:','MemTotal:'))}
    return dict(available_memory=m['MemAvailable'],cpu_count=len(os.sched_getaffinity(0)),load_1m=os.getloadavg()[0])

def main(s):
    s=Path(s);r=resources();workers=max(1,min(4,(r['cpu_count']-4)//4,int(max(0,r['available_memory']-8*1024**3)/(2*1024**3))))
    if r['load_1m']>r['cpu_count']*.75:workers=1
    policy=dict(**r,cpu_workers=workers,nice=15,raw_navigation_independent=True,gpu_workers=1,geometry_chunk_points=1000000,backend='cpu',fallback_reason=None,time=time.time())
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    lock=(ROOT/'offline-gpu.lock').open('w');gpu=False
    try:
        approved=json.loads((ROOT/'gpu-benchmark.json').read_text())
        throughput=json.loads((ROOT/'gpu-parallel-benchmark.json').read_text())
        if not throughput.get('approved'):raise ValueError('GPU throughput not validated')
        if not approved.get('approved') or approved['kernel_sha256']!=hashlib.sha256((ROOT/'color_gpu.py').read_bytes()).hexdigest():raise ValueError('GPU backend not validated')
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if r['available_memory']<8*1024**3:raise ValueError('host memory reserve')
        probe=subprocess.run(['/bin/sh',str(NATIVE),'-c',"import torch,json; assert torch.version.hip and torch.cuda.is_available(); print(json.dumps({'free':torch.cuda.mem_get_info()[0],'name':torch.cuda.get_device_name(0)}))"],capture_output=True,text=True,timeout=25)
        if probe.returncode:raise ValueError('ROCm probe failed')
        device=json.loads(probe.stdout.strip().splitlines()[-1])
        if device['name']!=approved['gpu']:raise ValueError('GPU differs from benchmark device')
        if device['free']<1536*1024**2:raise ValueError('GPU memory reserve')
        policy['gpu']=device;policy['backend']='rocm';env['APEX_COLOR_GPU']='1';gpu=True
        policy['gpu_workers']=min(2,int(throughput['recommended_workers'])) if device['free']>=4*1024**3 else 1
        policy['measured_speedup_vs_cpu4']=throughput['speedup_vs_cpu4']
    except (OSError,ValueError,KeyError,subprocess.TimeoutExpired) as e:
        policy['fallback_reason']=str(e)
        fcntl.flock(lock,fcntl.LOCK_UN)
    atomic(s/'color-resource-policy.json',policy)
    cmd=(['/bin/sh',str(NATIVE)] if gpu else [sys.executable])+[str(ROOT/'dual_color.py'),str(s),'--output','dense-color-v1','--workers',str(policy['gpu_workers'] if gpu else workers)]
    result=subprocess.run(cmd,env=env)
    if result.returncode and gpu:
        # Completed frame journal is reusable; never discard raw or accepted updates.
        fcntl.flock(lock,fcntl.LOCK_UN);env.pop('APEX_COLOR_GPU',None)
        policy.update(backend='cpu_fallback',fallback_reason='GPU worker exited; continuing saved frame journal');atomic(s/'color-resource-policy.json',policy)
        result=subprocess.run([sys.executable,str(ROOT/'dual_color.py'),str(s),'--output','dense-color-v1','--workers',str(workers)],env=env)
    lock.close()
    if result.returncode:raise SystemExit(result.returncode)

if __name__=='__main__':main(sys.argv[1])

"""Saved-data projection benchmark including CPU/GPU transfers; no sensors."""
import argparse,json,time,sys,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.append('/home/apex/research/fisheye_mapping_20261030')
from dual_color import project as cpu,build_tasks,atomic
from color_gpu import project as gpu
import torch

def main():
 p=argparse.ArgumentParser();p.add_argument('session');a=p.parse_args();s=Path(a.session);out=s/'dense-color-v1'
 xyz=np.load(out/'xyz.npy',mmap_mode='r');tasks,meta=build_tasks(s,out/'poses.jsonl')
 rows=[]
 for kind in ['rgb','fish']:
  task=next(t for t in tasks if t['kind']==kind and not t.get('error'))
  for count in [100000,1000000]:
   pts=np.asarray(xyz[:count]);pose=np.array(task['wc']);model=task['model'];baseline=cpu(pts,pose,model);candidate=gpu(pts,pose,model)
   indices_match=np.array_equal(baseline[0],candidate[0]);error=max([float(np.max(np.abs(x-y),initial=0)) for x,y in zip(baseline[1:],candidate[1:])]) if indices_match else None
   times={}
   for name,fn in [('cpu',cpu),('gpu',gpu)]:
    runs=[]
    for _ in range(5):
     start=time.perf_counter();fn(pts,pose,model);torch.cuda.synchronize();runs.append(time.perf_counter()-start)
    times[name]=float(np.median(runs))
   rows.append(dict(kind=kind,points=len(pts),visible=len(baseline[0]),indices_match=indices_match,max_numeric_difference=error,seconds=times,speedup=times['cpu']/times['gpu']))
 result=dict(gpu=torch.cuda.get_device_name(0),torch=torch.__version__,hip=torch.version.hip,kernel_sha256=hashlib.sha256((ROOT/'color_gpu.py').read_bytes()).hexdigest(),peak_allocated_bytes=torch.cuda.max_memory_allocated(),rows=rows,approved=all(r['indices_match'] and r['max_numeric_difference']<1e-5 for r in rows) and all(r['speedup']>1.1 for r in rows if r['points']==1000000),scope='projection_only_including_transfers_not_full_pipeline',hardware_commands_sent=False)
 atomic(ROOT/'gpu-benchmark.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()
